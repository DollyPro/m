<?php
require '../php/get.php';
session_start();
#check user
if ( isset($_SESSION['name']) && isset($_SESSION['password']) ){
	
	$name =$_SESSION['name'];
	$my_password =$_SESSION['password'];
	
	if ( !( $response =check_user( $name, $my_password ) ) ){
		$response['error']= '100000';
		die();
	}
	
	if ( !( $response['error']==0 ) ){

		unset($_SESSION['name']);
		unset($_SESSION['password']);
		$response['error'] ='10100';
		$response['sign-out'] ='true';
		die();

	}
	
	$data =$response['data'];
	$row = $data ->fetch_assoc();
	$user = $row['c_ID'];

	
	$authnication_user_branch=htmlentities($row['c_Branch']);
	
	$authnication_user_view_account=htmlentities($row['c_ViewAccount']);
	$authnication_user_insert_account=htmlentities($row['c_InsertAccount']);
	$authnication_user_update_account=htmlentities($row['c_UpdateAccount']);
	$authnication_user_delete_account=htmlentities($row['c_DeleteAccount']);
	
	$authnication_user_view_stock=htmlentities($row['c_ViewStock']);
	$authnication_user_insert_stock=htmlentities($row['c_InsertStock']);
	$authnication_user_update_stock=htmlentities($row['c_UpdateStock']);
	$authnication_user_delete_stock=htmlentities($row['c_DeleteStock']);
	$authnication_user_cost=htmlentities($row['c_Cost']);
	$authnication_user_all_items=htmlentities($row['c_AllItems']);
	
	$authnication_user_view_sale=htmlentities($row['c_ViewSale']);
	$authnication_user_insert_sale=htmlentities($row['c_InsertSale']);
	$authnication_user_update_sale=htmlentities($row['c_UpdateSale']);
	$authnication_user_delete_sale=htmlentities($row['c_DeleteSale']);
	
	$authnication_user_view_r_sale=htmlentities($row['c_ViewRSale']);
	$authnication_user_insert_r_sale=htmlentities($row['c_InsertRSale']);
	$authnication_user_update_r_sale=htmlentities($row['c_UpdateRSale']);
	$authnication_user_delete_r_sale=htmlentities($row['c_DeleteRSale']);
	
	$authnication_user_view_purchase=htmlentities($row['c_ViewPurchase']);
	$authnication_user_insert_purchase=htmlentities($row['c_InsertPurchase']);
	$authnication_user_update_purchase=htmlentities($row['c_UpdatePurchase']);
	$authnication_user_delete_purchase=htmlentities($row['c_DeletePurchase']);
	
	$authnication_user_view_r_purchase=htmlentities($row['c_ViewRPurchase']);
	$authnication_user_insert_r_purchase=htmlentities($row['c_InsertRPurchase']);
	$authnication_user_update_r_purchase=htmlentities($row['c_UpdateRPurchase']);
	$authnication_user_delete_r_purchase=htmlentities($row['c_DeleteRPurchase']);
	
	$authnication_user_view_income=htmlentities($row['c_ViewIncome']);
	$authnication_user_insert_income=htmlentities($row['c_InsertIncome']);
	$authnication_user_update_income=htmlentities($row['c_UpdateIncome']);
	$authnication_user_delete_income=htmlentities($row['c_DeleteIncome']);
	
	$authnication_user_view_outcome=htmlentities($row['c_ViewOutcome']);
	$authnication_user_insert_outcome=htmlentities($row['c_InsertOutcome']);
	$authnication_user_update_outcome=htmlentities($row['c_UpdateOutcome']);
	$authnication_user_delete_outcome=htmlentities($row['c_DeleteOutcome']);
	
	$authnication_user_view_receipt=htmlentities($row['c_ViewReceipt']);
	$authnication_user_insert_receipt=htmlentities($row['c_InsertReceipt']);
	$authnication_user_update_receipt=htmlentities($row['c_UpdateReceipt']);
	$authnication_user_delete_receipt=htmlentities($row['c_DeleteReceipt']);
	
	$authnication_user_view_payment=htmlentities($row['c_ViewPayment']);
	$authnication_user_insert_payment=htmlentities($row['c_InsertPayment']);
	$authnication_user_update_payment=htmlentities($row['c_UpdatePayment']);
	$authnication_user_delete_payment=htmlentities($row['c_DeletePayment']);
	
	$authnication_user_all_branches=htmlentities($row['c_AllBranches']);
	$authnication_user_journal=htmlentities($row['c_Journal']);
	$authnication_user_loss_profit=htmlentities($row['c_LossProfit']);
	$authnication_user_users=htmlentities($row['c_Users']);
	$authnication_user_backup=htmlentities($row['c_BackUp']);
	$authnication_user_restore=htmlentities($row['c_Restore']);

	
}else{
	$response['error'] ='10101';
	$response['sign-out'] ='true';
	die();
}

if ( !( isset($_GET['payment']) || isset($_GET['income']) || isset($_GET['invoice']) ) ){
	die();
}
#payment
if (isset($_GET['payment'])){

	$id = $_GET['payment'];

	
	if ( !($response =select_payment( $id )) ){
		$response['error'] ='12201';
		die();
	}
		
	if ( !( $response['error'] ==0 ) ){
		die();
	}

	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$branch =htmlentities($row['c_Branch']);
	$account_name =htmlentities($row['c_AccountName']);
	$second_account_name =htmlentities($row['c_SecondAccountName']);
	$type =htmlentities($row['c_Type']);
	$ammount =htmlentities($row['c_Ammount']);
	$date =htmlentities($row['c_Date']);
	$memo =htmlentities($row['c_Memo']);
	
	if ($type=='Receipt'){
		if ( !($authnication_user_view_receipt=='true') ){
			die('Not Authnicated');
		}
	}

	if ($type=='Payment'){
		if ( !($authnication_user_view_payment=='true') ){
			die('Not Authnicated');
		}
	}
	
	
	$from_to_label = 'To';
	if ($type=='Receipt'){
	}
	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die();
		}
	}
	
	if ( !($response =select_branch( $branch )) ){
		$response['error'] ='12201';
		die();
	}
	
	if ( !( $response['error'] ==0 ) ){
		die();
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$branch_name = htmlentities($row['c_Name']);
	$branch_address1 = htmlentities($row['c_Address1']);
	$branch_address2 = htmlentities($row['c_Address2']);
	$branch_contact1 = htmlentities($row['c_Contact1']);
	$branch_contact2 = htmlentities($row['c_Contact2']);
	
	$response['error'] ='0';
	$response['data']=
			'<div class="main-container">
			
			<div class="branch-info">
				<h1>'.$branch_name.'</h1>
				<h5>'.$branch_address1.'</h5>
				<h5>'.$branch_address2.'</h5>
				<h5>'.$branch_contact1.'</h5>
				<h5>'.$branch_contact2.'</h5>
			</div>
			
			<div class="invoice-info">
				<h3>'.$type.'</h3>
				<h5>Amount: '.$ammount.'</h5>
				<h5>Account: '.$account_name.'</h5>
				<h5>Date: '.$date.'</h5>
			</div>
			
			<div class="total-info">
				<h2>'.$type.' Ammount</h2>
				<h2 class="total">'.$ammount.'</h2>
			</div>
			
			</div>
			';
}
#income
if (isset($_GET['income'])){

	$id = $_GET['income'];

	if ( !($response =select_invoice( $id )) ){
		$response['error'] ='12201';
		die();
	}
		
	if ( !( $response['error'] ==0 ) ){
		die();
	}
	
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$branch =htmlentities($row['c_Branch']);
	$account_name =htmlentities($row['c_AccountName']);
	$second_account_name =htmlentities($row['c_SecondAccountName']);
	$type =htmlentities($row['c_Type']);
	$total =htmlentities($row['c_Total']);
	$date =htmlentities($row['c_Date']);
	$memo =htmlentities($row['c_Memo']);	
	
	if ($type!='Income' && $type!='Outcome' ){
		die();
	}
	
	if ($type=='Income'){
		if ( !($authnication_user_view_income=='true') ){
			die('Not Authnicated');
		}
	}
	
	if ($type=='Outcome'){
		if ( !($authnication_user_view_outcome=='true') ){
			die('Not Authnicated');
		}
	}

	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die();
		}
	}
	
	if ( !($response =select_branch( $branch )) ){
		$response['error'] ='12201';
		die();
	}
	
	if ( !( $response['error'] ==0 ) ){
		die();
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$branch_name = htmlentities($row['c_Name']);
	$branch_address1 = htmlentities($row['c_Address1']);
	$branch_address2 = htmlentities($row['c_Address2']);
	$branch_contact1 = htmlentities($row['c_Contact1']);
	$branch_contact2 = htmlentities($row['c_Contact2']);
	
	$response['error'] ='0';
	$response['data']=
			'<div class="main-container">
			
			<div class="branch-info">
				<h1>'.$branch_name.'</h1>
				<h5>'.$branch_address1.'</h5>
				<h5>'.$branch_address2.'</h5>
				<h5>'.$branch_contact1.'</h5>
				<h5>'.$branch_contact2.'</h5>
			</div>
			
			<div class="invoice-info">
				<h3>'.$type.'</h3>
				<h5>Total: '.$total.'</h5>
				<h5>Account: '.$account_name.'</h5>
				<h5>Date: '.$date.'</h5>
			</div>
			
			<div class="total-info">
				<h2>'.$type.' Total</h2>
				<h2 class="total">'.$total.'</h2>
			</div>
			
			</div>
			';
}

if (isset($_GET['invoice'])){
	
	$id =$_GET['invoice'];

	if ( !($response =select_invoice( $id )) ){
		$response ='13201';
		die();
	}
	
	if ( !( $response['error']==0 ) ){
		die();
	}
	
	
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();

	$type =htmlentities($row['c_Type']);
	$branch =htmlentities($row['c_Branch']);
	$account_name =htmlentities($row['c_AccountName']);
	$invoice_from =htmlentities($row['c_SecondAccountName']);
	$total =htmlentities($row['c_Total']);
	$discount =htmlentities($row['c_Discount']);
	$net =$total-$discount;
	$memo =htmlentities($row['c_Memo']);
	$date =htmlentities($row['c_Date']);
	
	$net =$total - $discount;
	
		if ($type=='Sale'){
		if ( !($authnication_user_view_sale=='true') ){
			die('Not Authnicated');
		}
	}
	
	if ($type=='R Sale'){
		if ( !($authnication_user_view_r_sale=='true') ){
			die('Not Authnicated');
		}
	}

	if ($type=='Purchase'){
		if ( !($authnication_user_view_purchase=='true') ){
			die('Not Authnicated');
		}
	}
	
	if ($type=='R Purchase'){
		if ( !($authnication_user_view_r_purchase=='true') ){
			die('Not Authnicated');
		}
	}
	
	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die();
		}
	}
	
	if ($type != 'Sale' && $type != 'R Sale' && $type != 'Purchase' && $type != 'R Purchase'){
		$response['error']='13202';
		die();
	}

	if ( !( $response =select_invoice_items($id) ) ){
		$response['error']='13203';
		die();
	}
	
	if ( !( $response['error']==0 ) ){
		die();
	}
	
	$data =$response['data'];
	$items ='';
	while ( $row =$data ->fetch_assoc() ){
		
		$item_id =htmlentities($row['c_StockID']);
		$item_name =htmlentities($row['c_StockName']);
		$item_qty =htmlentities($row['c_Qty']);
		$item_price =htmlentities($row['c_Price']);
		$item_discount =htmlentities($row['c_Discount']);
		$item_ammount = ($item_price*$item_qty)-( ($item_price*$item_qty)*($item_discount/100) );
		
		$items .='
			<tr>
				<td>'.$item_name.'</td>
				<td>'.$item_price.'</td>
				<td>'.$item_qty.'</td>
				<td>'.$item_discount.'</td>
				<td>'.$item_ammount.'</td>
			</tr>
		';
		
	}

	if ( !($response =select_branch( $branch )) ){
		$response['error'] ='12201';
		die();
	}
	
	if ( !( $response['error'] ==0 ) ){
		die();
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$branch_name = htmlentities($row['c_Name']);
	$branch_address1 = htmlentities($row['c_Address1']);
	$branch_address2 = htmlentities($row['c_Address2']);
	$branch_contact1 = htmlentities($row['c_Contact1']);
	$branch_contact2 = htmlentities($row['c_Contact2']);

	$response['error'] ='0';
	$response['data']=
			'<div class="main-container">
			
			<div class="branch-info">
				<h1>'.$branch_name.'</h1>
				<h5>'.$branch_address1.'</h5>
				<h5>'.$branch_address2.'</h5>
				<h5>'.$branch_contact1.'</h5>
				<h5>'.$branch_contact2.'</h5>
			</div>
			
			<div class="invoice-info">
				<h3>'.$type.'</h3>
				<h5>Total: '.$total.'</h5>
				<h5>Discount: '.$discount.'</h5>
				<h5>Net: '.$net.'</h5>
				<h5>Account: '.$account_name.'</h5>
				<h5>Date: '.$date.'</h5>
			</div>
			
			<div class="total-info">
				<h2>'.$type.' Net</h2>
				<h2 class="total">'.$net.'</h2>
			</div>
			
			<div class="items-info">
				<table>
				<th style="width:60%;">Item</th>
				<th style="width:10%;">Amount</th>
				<th style="width:10%;">Qty.</th>
				<th style="width:10%;">Disc.%</th>
				<th style="width:10%;">Total</th>
				'.$items.'
				</table>
			</div>
			
			</div>
			';
}

?>
<!doctype html>
<html>
<header>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="../css/report_invoice.css">

</header>
<title>Print</title>
<body onload="window.print();">

<?php 	
die ($response['data']);
?>

<script>
alert();
</script>

</body>
</html>