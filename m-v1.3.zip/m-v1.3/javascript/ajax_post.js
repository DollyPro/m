/*t_accounts*/
function insert_account()
{
	
	if ( $('#account_name').val()=='' ){
		$('#account_name').css( 'border-bottom', '1px dashed red' );
		return ;
	}
	
	var branch =$('#account_branch').val();
	var name =$('#account_name').val();
	var type =$('#account_type').val();
	var opening_balance =$('#account_opening_balance').val();
	var	contact =$('#account_contact').val();
	var address =$('#account_address').val();
	var my_location =$('#account_location').val();
	var	memo =$('#account_memo').val(); 
	
	loader_show();
	
	$.ajax({
		
		url:'php/ajax_post_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'insert_account', branch, name, type, opening_balance, contact, address, my_location, memo },
		success:function(response){
 
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			

			$('.page-number').val('0');
			$('.items-body').html('');
			
			cancel_modal();
			
			accounts_body();

		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
};
function update_account()
{
	
	if ( $('#account_name').val()=='' ){
		$('#account_name').css( 'border-bottom', '1px dashed red' );
		return ;
	}
	
	var id =$('#account_id').val();
	var name = $('#account_name').val();
	var opening_balance =$('#account_opening_balance').val();
	var	contact =$('#account_contact').val();
	var address =$('#account_address').val();
	var my_location =$('#account_location').val();
	var	memo =$('#account_memo').val(); 

	loader_show();
	
	$.ajax({
		
		url:'php/ajax_post_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'update_account', name, opening_balance, contact, address, my_location, memo, id },
		success:function(response){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			
			cancel_modal();
			
			refresh_account( id,'' );
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}
function delete_account()
{
	
	if ( !( $('.item-container .selected').length==1 ) ){
		alert('Select Account');
		return;
	}
	var name =$('.item-container .selected').data('name');
	var id =$('.item-container .selected').data('id');
	var activity =$('.item-container .selected').data('activity');
	var type =$('.item-container .selected').data('type');
	
	if (type =='Basic' ){
		alert('Basic Account');
		return;
	}
	
	if ( activity ){
		alert('Contains Activity');
		return;
	}
	
	if ( !( confirm( 'Delete '+ name +' ?' ) ) ){
		return;
	}
	
	loader_show();
	
	$.ajax({
		
		url:'php/ajax_post_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'delete_account', id },
		success:function(response){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}else{
				
				$('.item-container .selected').remove();
				$('.item-container .item').first().addClass('selected');
			
			}
			
			cancel_modal();
			
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}
/* t_payments */
function insert_payment()
{
	
	if ( !( $('#payment_ammount').val()>0 ) ){
		$('#payment_ammount').css( 'border-bottom', '1px dashed red' );
		return ;
	}
	
	var account_name =$('.item-container .selected').data('name');

	var account =$('#payment_account_id').val();
	var second_account =$('#payment_second_account').val();
	var type =$('#payment_type').val();
	var ammount =$('#payment_ammount').val();
	var	memo =$('#payment_memo').val(); 
	
	loader_show();
	
	$.ajax({
		
		url:'php/ajax_post_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'insert_payment', account, second_account, type, ammount, memo },
		success:function(response){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}

			
			cancel_modal();
			
			refresh_account( account, second_account );
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
};
function update_payment()
{
	
	if ( !( $('#payment_ammount').val()>0 ) ){
		$('#payment_ammount').css( 'border-bottom', '1px dashed red' );
		return ;
	}
	
	var account_name =$('.item-container .selected').data('account-name');


	var id =$('#payment_id').val();
	var ammount =$('#payment_ammount').val();
	var address =$('#payment_address').val();
	var	memo =$('#payment_memo').val(); 
	
	loader_show();

	$.ajax({
		
		url:'php/ajax_post_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'update_payment', ammount, memo, id },
		success:function(response){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}

			
			cancel_modal();
			
			var title =document.title;
			
			if (title =='M.Accounts'){		
				accounts_body();
			}
			if (title =='M.Stock'){
				products_body();
			}
			if (title =='M.Payments'){
				refresh_payment( id );
			}
			if (title =='M.Invoices'){
				invoices_body();
			}
			if (title =='M.Journal'){				
				$('.search-input').val( account_name );
				$('.page-search').val( account_name );
				$('.page-number').val('0');
				$('.items-body').html('');
				journal_body();
			}			
		
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
};
function delete_payment()
{
	
	if ( !( $('.item-container .selected').length==1 ) ){
		alert('Select Payment');
		return;
	}
	var account_name =$('.item-container .selected').data('account-name');
	var id =$('.item-container .selected').data('id');
	var type =$('.item-container .selected').data('type');
	
	if ( !( confirm( 'Delete a '+ type +' from '+account_name+' ?' ) ) ){
		return;
	}
	
	loader_show();
	
	$.ajax({
		
		url:'php/ajax_post_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'delete_payment', id },
		success:function(response){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}else{
			
				$('.item-container .item').each(function(){
					if ( $(this).data('id') == id ){
						$(this).remove();
					}
				});	
				$('.item-container .item').first().addClass('selected');
			
			}
			
			cancel_modal();
			
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}
/* t_invoices */
function insert_invoice()
{
	
	var item_id =0;
	var qty =0;
	var price =0;
	var item_discount =0;
	var item_ammount =0;
	var purchase_id =0;
	
	var invoice_total =0;
	var invoice_discount =0;
	var invoice_net =0;
	
	var stop ='false';

	var items =[];
	
	var i =0;
	
	if ( !( $('.invoice-item').length >0 ) ){
		stop ='true';
		$('.invoice-items').css( 'background-color', 'rgb(255,114,111)' );
		setTimeout( function(){ $('.invoice-items').css( 'background-color', '' ); } ,250 );
	}
	
	
	$('.invoice-item').each(function(){
		
		item_id =$(this).children('.item-id').val();
		purchase_id =$(this).children('.purchase-id').val();

		qty =$(this).children('section').children('.item-qty').val();
		price =$(this).children('section').children('.item-price').val();
		item_discount =$(this).children('section').children('.item-discount').val();
		
		item_ammount = (qty*price)  - ( (qty*price) * (item_discount/100) ) ;

		items[i] ={
			id: item_id,
			purchase_id: purchase_id,
			qty: qty,
			price: price,
			discount: item_discount
		};

		i++;
		
		if ( !( item_ammount>0 ) ){
			$(this).css( 'background-color', 'rgb(255,114,111)' );
			stop ='true';
		}else{
			$(this).css( 'background-color', '' );
		}		

	});

	items =JSON.stringify( items );

	if (stop =='true'){
		return;
	}
		
	var account_name =$('.item-container .selected').data('name');

	var account =$('#invoice_account_id').val();
	var second_account =$('#invoice-second-account').val();
	var type =$('#invoice_type').val();
	var	memo =$('#invoice_memo').val(); 
	var discount =$('#invoice_discount').val();

	if ( $('#invoice_auto_payment').prop('checked')==true ){
		var auto_payment ='true';
	}else{
		var auto_payment ='false';
	}

	loader_show();

	$.ajax({
		
		url:'php/ajax_post_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'insert_invoice', account, second_account, type, memo, discount, auto_payment, items },
		success:function(response){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			cancel_modal();
			
			refresh_account( account, second_account );
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

	});
	
};
function update_invoice()
{
	
	var item_id =0;
	var qty =0;
	var price =0;
	var item_discount =0;
	var item_ammount =0;
	
	var invoice_total =0;
	var invoice_discount =0;
	var invoice_net =0;
	
	var stop ='false';

	var items =[];
	
	var i =0;
	
	if ( !( $('.invoice-item').length >0 ) ){
		stop ='true';
		$('.invoice-items').css( 'background-color', 'rgb(255,114,111)' );
		setTimeout( function(){ $('.invoice-items').css( 'background-color', '' ); } ,250 );
	}
	
	
	$('.invoice-item').each(function(){
		
		item_id =$(this).children('.item-id').val();
		
		
		qty =$(this).children('section').children('.item-qty').val();
		price =$(this).children('section').children('.item-price').val();
		item_discount =$(this).children('section').children('.item-discount').val();
		
		item_ammount = (qty*price) - ( (qty*price) * (item_discount/100) ) ;

		items[i] ={
			id: item_id,
			qty: qty,
			price: price,
			discount: item_discount
		};

		i++;
		
		if ( !( item_ammount>0 ) ){
			$(this).css( 'background-color', 'rgb(255,114,111)' );
			stop ='true';
		}else{
			$(this).css( 'background-color', '' );
		}		

	});

	items =JSON.stringify( items );

	if (stop =='true'){
		return;
	}

	

	var account_name =$('#invoice_account_name').val();
	var id =$('#invoice_id').val();
	var	memo =$('#invoice_memo').val(); 
	var discount =$('#invoice_discount').val();
	var	active =''; 
	
	loader_show();


	$.ajax({
		
		url:'php/ajax_post_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'update_invoice', id, memo, discount, items },
		success:function(response){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}

			
			cancel_modal();
			
			var title =document.title;
			
			if (title =='M.Accounts'){		
				accounts_body();
			}
			if (title =='M.Stock'){
				products_body();
			}
			if (title =='M.Payments'){
				payments_body();
			}
			if (title =='M.Invoices'){
				refresh_invoice( id );
			}
			if (title =='M.Journal'){
				$('.search-input').val( account_name );
				$('.page-search').val( account_name );
				$('.page-number').val('0');
				$('.items-body').html('');
				journal_body();
			}
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

	});
	
};
function insert_income()
{
	
	if ( !( $('#income_ammount').val()>0 ) ){
		$('#income_ammount').css( 'border-bottom', '1px dashed red' );
		return ;
	}
	
	var account_name =$('.item-container .selected').data('name');

	var account =$('#income_account_id').val();
	var second_account =$('#income-second-account').val();
	var ammount =$('#income_ammount').val();
	var	memo =$('#income_memo').val(); 
	var	active =''; 
	var type =$('#invoice_type').val();
	
	loader_show();
	
	$.ajax({
		
		url:'php/ajax_post_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'insert_income', account, second_account, ammount, memo, type },
		success:function(response){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			cancel_modal();
			
			refresh_account( account, second_account );
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
};
function update_income()
{
	
	if ( !( $('#income_ammount').val()>0 ) ){
		$('#income_ammount').css( 'border-bottom', '1px dashed red' );
		return ;
	}
	
	var account_name =$('.item-container .selected').data('account-name');


	var id =$('#income_id').val();
	var ammount =$('#income_ammount').val();
	var	memo =$('#income_memo').val(); 

	loader_show();
	
	$.ajax({
		
		url:'php/ajax_post_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'update_income', ammount, memo, id },
		success:function(response){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}

			
			cancel_modal();
			
			var title =document.title;
			
			if (title =='M.Accounts'){		
				accounts_body();
			}
			if (title =='M.Stock'){
				products_body();
			}
			if (title =='M.Payments'){
				payments_body();
			}
			if (title =='M.Invoices'){
				refresh_invoice( id );
			}
			if (title =='M.Journal'){
				$('.search-input').val( account_name );
				$('.page-search').val( account_name );
				$('.page-number').val('0');
				$('.items-body').html('');
				journal_body();
			}
	
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
};
function delete_invoice()
{
	
	if ( !( $('.item-container .selected').length==1 ) ){
		alert('Select Invoice');
		return;
	}
	var account_name =$('.item-container .selected').data('account-name');
	var id =$('.item-container .selected').data('id');
	var type =$('.item-container .selected').data('type');
	
	if ( !( confirm( 'Delete a '+ type +' from '+account_name+' ?' ) ) ){
		return;
	}
	
	loader_show();
	
	$.ajax({
		
		url:'php/ajax_post_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'delete_invoice', id },
		success:function(response){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}else{
			
				$('.item-container .item').each(function(){
					if ( $(this).data('id') == id && ( $(this).data('type')=='Income' || $(this).data('type')=='Outcome' || $(this).data('type')=='Sale' || $(this).data('type')=='R Sale' || $(this).data('type')=='Purchase' || $(this).data('type')=='R Purchase' ) ){
						$(this).remove();
					}
				});
				$('.item-container .item').first().addClass('selected');
				
			}
			
			cancel_modal();
			
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}
/* t_stock */
function insert_product()
{
	
	if ( $('#product_name').val()=='' ){
		$('#product_name').css( 'border-bottom', '1px dashed red' );
		return ;
	}
	
	var branch =$('#product_branch').val();
	var name =$('#product_name').val();
	
	var	opening_qty =$('#product_opening_qty').val(); 
	var	cost =$('#product_opening_cost').val(); 
	var	price =$('#product_price').val(); 
	
	var	category1 =$('#product_category1').val(); 
	var	category2 =$('#product_category2').val(); 
	var	category3 =$('#product_category3').val(); 
	var	category4 =$('#product_category4').val(); 
	var	category5 =$('#product_category5').val(); 
	var	category6 =$('#product_category6').val(); 
	var	category7 =$('#product_category7').val(); 
	var	category8 =$('#product_category8').val(); 
	var	minimum =$('#product_minimum').val(); 
	var	maximum =$('#product_maximum').val(); 
	var	memo =$('#product_memo').val(); 
	
	loader_show();
	
	$.ajax({
		
		url:'php/ajax_post_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'insert_product', branch, name, opening_qty, cost, price, minimum, maximum, category1, category2, category3, category4, category5, category6, category7, category8, memo },
		success:function(response){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			
			var title =document.title;
			
			if (title =='M.Accounts'){		
				$('.invoice-stock-search').click();
				cancel_modal();
			}
			if (title =='M.Stock'){
				$('.page-number').val('0');
				$('.items-body').html('');
				
				cancel_modal();
				
				products_body();
			}
			if (title =='M.Payments'){
				payments_body();
			}
			if (title =='M.Invoices'){
				$('.invoice-stock-search').click();
				cancel_modal();
			}
			if (title =='M.Journal'){
				$('.invoice-stock-search').click();
				cancel_modal();
			}
			

		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
};
function update_product()
{

	if ( $('#product_name').val()=='' ){
		$('#product_name').css( 'border-bottom', '1px dashed red' );
		return ;
	}
	
	var id =$('#product_id').val();
	var name =$('#product_name').val();
	
	var	opening_qty =$('#product_opening_qty').val(); 
	var	cost =$('#product_opening_cost').val(); 
	var	price =$('#product_price').val(); 
	
	var	category1 =$('#product_category1').val(); 
	var	category2 =$('#product_category2').val(); 
	var	category3 =$('#product_category3').val(); 
	var	category4 =$('#product_category4').val(); 
	var	category5 =$('#product_category5').val(); 
	var	category6 =$('#product_category6').val(); 
	var	category7 =$('#product_category7').val(); 
	var	category8 =$('#product_category8').val(); 
	var	minimum =$('#product_minimum').val(); 
	var	maximum =$('#product_maximum').val(); 
	var	memo =$('#product_memo').val(); 

	
	loader_show();
	
	$.ajax({
		
		url:'php/ajax_post_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'update_product', name, opening_qty, cost, price, minimum, maximum, category1, category2, category3, category4, category5, category6, category7, category8, memo, id },
		success:function(response){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}

			
			cancel_modal();
			
			refresh_product( id );
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
};
function delete_product()
{
	if ( !( $('.item-container .selected').length==1 ) ){
		alert('Select Account');
		return;
	}
	var name =$('.item-container .selected').data('name');
	var id =$('.item-container .selected').data('id');
	var activity =$('.item-container .selected').data('activity');
	
	
	if ( activity ){
		alert('Contains Activity');
		return;
	}
	
	if ( !( confirm( 'Delete '+ name +' ?' ) ) ){
		return;
	}
	
	loader_show();
	
	$.ajax({
		
		url:'php/ajax_post_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'delete_product', id },
		success:function(response){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}else{
				
				$('.item-container .selected').remove();
				$('.item-container .item').first().addClass('selected');
		
			}
			
			cancel_modal();
			
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}
 /* t_journal */
 function delete_journal()
{
	if ( !( $('.item-container .selected').length==1 ) ){
		alert('Select Entry');
		return;
	}

	var type =$('.item-container .selected').data('type');
	
	if ( type == 'Payment' || type == 'Receipt' ){
		delete_payment();
		return;
	}
	
	if ( type == 'Income' || type == 'Outcome' ){
		delete_invoice();
		return;
	}
	
	if ( type == 'Sale' || type == 'R Sale' || type == 'Purchase' || type == 'R Purchase'  ){
		delete_invoice();
		return;
	}
	
}
/* t_users */
function insert_user()
{
	
	
	if ( !( $('#user_name').val()!='' ) ){
		$('#user_name').css( 'border-bottom', '1px dashed red' );
		return ;
	}else{
		$('#user_name').css( 'border-bottom', 'none' );
	}
	
	if ( !( $('#user_password').val()!='' ) ){
		$('#user_password').css( 'border-bottom', '1px dashed red' );
		return ;
	}else{
		$('#user_password').css( 'border-bottom', 'none' );
	}
	
	var user_name =$('#user_name').val();
	var user_password =$('#user_password').val();
	var user_branch =$('#user_branch').val();

	
	if ( $('#user_view_account').prop('checked')==true ){
		var user_view_account ='true';
	}else{
		var user_view_account ='false';
	}
	
	if ( $('#user_insert_account').prop('checked')==true ){
		var user_insert_account ='true';
	}else{
		var user_insert_account ='false';
	}
	
	if ( $('#user_update_account').prop('checked')==true ){
		var user_update_account ='true';
	}else{
		var user_update_account ='false';
	}
	
	if ( $('#user_delete_account').prop('checked')==true ){
		var user_delete_account ='true';
	}else{
		var user_delete_account ='false';
	}

	if ( $('#user_export_accounts').prop('checked')==true ){
		var user_export_accounts ='true';
	}else{
		var user_export_accounts ='false';
	}

	if ( $('#user_view_stock').prop('checked')==true ){
		var user_view_stock ='true';
	}else{
		var user_view_stock ='false';
	}
	
	if ( $('#user_insert_stock').prop('checked')==true ){
		var user_insert_stock ='true';
	}else{
		var user_insert_stock ='false';
	}
	
	if ( $('#user_update_stock').prop('checked')==true ){
		var user_update_stock ='true';
	}else{
		var user_update_stock ='false';
	}
	
	if ( $('#user_delete_stock').prop('checked')==true ){
		var user_delete_stock ='true';
	}else{
		var user_delete_stock ='false';
	}
	
	if ( $('#user_cost').prop('checked')==true ){
		var user_cost ='true';
	}else{
		var user_cost ='false';
	}
	
	if ( $('#user_all_items').prop('checked')==true ){
		var user_all_items ='true';
	}else{
		var user_all_items ='false';
	}
	
	if ( $('#user_export_stock').prop('checked')==true ){
		var user_export_stock ='true';
	}else{
		var user_export_stock ='false';
	}
	
	
	if ( $('#user_view_sale').prop('checked')==true ){
		var user_view_sale ='true';
	}else{
		var user_view_sale ='false';
	}
	
	if ( $('#user_insert_sale').prop('checked')==true ){
		var user_insert_sale ='true';
	}else{
		var user_insert_sale ='false';
	}
	
	if ( $('#user_update_sale').prop('checked')==true ){
		var user_update_sale ='true';
	}else{
		var user_update_sale ='false';
	}
	
	if ( $('#user_delete_sale').prop('checked')==true ){
		var user_delete_sale ='true';
	}else{
		var user_delete_sale ='false';
	}


	if ( $('#user_view_r_sale').prop('checked')==true ){
		var user_view_r_sale ='true';
	}else{
		var user_view_r_sale ='false';
	}
	
	if ( $('#user_insert_r_sale').prop('checked')==true ){
		var user_insert_r_sale ='true';
	}else{
		var user_insert_r_sale ='false';
	}
	
	if ( $('#user_update_r_sale').prop('checked')==true ){
		var user_update_r_sale ='true';
	}else{
		var user_update_r_sale ='false';
	}
	
	if ( $('#user_delete_r_sale').prop('checked')==true ){
		var user_delete_r_sale ='true';
	}else{
		var user_delete_r_sale ='false';
	}


	if ( $('#user_view_purchase').prop('checked')==true ){
		var user_view_purchase ='true';
	}else{
		var user_view_purchase ='false';
	}
	
	if ( $('#user_insert_purchase').prop('checked')==true ){
		var user_insert_purchase ='true';
	}else{
		var user_insert_purchase ='false';
	}
	
	if ( $('#user_update_purchase').prop('checked')==true ){
		var user_update_purchase ='true';
	}else{
		var user_update_purchase ='false';
	}
	
	if ( $('#user_delete_purchase').prop('checked')==true ){
		var user_delete_purchase ='true';
	}else{
		var user_delete_purchase ='false';
	}
	
	
	if ( $('#user_view_r_purchase').prop('checked')==true ){
		var user_view_r_purchase ='true';
	}else{
		var user_view_r_purchase ='false';
	}
	
	if ( $('#user_insert_r_purchase').prop('checked')==true ){
		var user_insert_r_purchase ='true';
	}else{
		var user_insert_r_purchase ='false';
	}
	
	if ( $('#user_update_r_purchase').prop('checked')==true ){
		var user_update_r_purchase ='true';
	}else{
		var user_update_r_purchase ='false';
	}
	
	if ( $('#user_delete_r_purchase').prop('checked')==true ){
		var user_delete_r_purchase ='true';
	}else{
		var user_delete_r_purchase ='false';
	}

	
	if ( $('#user_view_income').prop('checked')==true ){
		var user_view_income ='true';
	}else{
		var user_view_income ='false';
	}
	
	if ( $('#user_insert_income').prop('checked')==true ){
		var user_insert_income ='true';
	}else{
		var user_insert_income ='false';
	}
	
	if ( $('#user_update_income').prop('checked')==true ){
		var user_update_income ='true';
	}else{
		var user_update_income ='false';
	}
	
	if ( $('#user_delete_income').prop('checked')==true ){
		var user_delete_income ='true';
	}else{
		var user_delete_income ='false';
	}


	if ( $('#user_view_outcome').prop('checked')==true ){
		var user_view_outcome ='true';
	}else{
		var user_view_outcome ='false';
	}
	
	if ( $('#user_insert_outcome').prop('checked')==true ){
		var user_insert_outcome ='true';
	}else{
		var user_insert_outcome ='false';
	}
	
	if ( $('#user_update_outcome').prop('checked')==true ){
		var user_update_outcome ='true';
	}else{
		var user_update_outcome ='false';
	}
	
	if ( $('#user_delete_outcome').prop('checked')==true ){
		var user_delete_outcome ='true';
	}else{
		var user_delete_outcome ='false';
	}


	if ( $('#user_view_receipt').prop('checked')==true ){
		var user_view_receipt ='true';
	}else{
		var user_view_receipt ='false';
	}
	
	if ( $('#user_insert_receipt').prop('checked')==true ){
		var user_insert_receipt ='true';
	}else{
		var user_insert_receipt ='false';
	}
	
	if ( $('#user_update_receipt').prop('checked')==true ){
		var user_update_receipt ='true';
	}else{
		var user_update_receipt ='false';
	}
	
	if ( $('#user_delete_receipt').prop('checked')==true ){
		var user_delete_receipt ='true';
	}else{
		var user_delete_receipt ='false';
	}


	if ( $('#user_view_payment').prop('checked')==true ){
		var user_view_payment ='true';
	}else{
		var user_view_payment ='false';
	}
	
	if ( $('#user_insert_payment').prop('checked')==true ){
		var user_insert_payment ='true';
	}else{
		var user_insert_payment ='false';
	}
	
	if ( $('#user_update_payment').prop('checked')==true ){
		var user_update_payment ='true';
	}else{
		var user_update_payment ='false';
	}
	
	if ( $('#user_delete_payment').prop('checked')==true ){
		var user_delete_payment ='true';
	}else{
		var user_delete_payment ='false';
	}


	if ( $('#user_all_branches').prop('checked')==true ){
		var user_all_branches ='true';
	}else{
		var user_all_branches ='false';
	}

	if ( $('#user_journal').prop('checked')==true ){
		var user_journal ='true';
	}else{
		var user_journal ='false';
	}
	
	if ( $('#user_export_journal').prop('checked')==true ){
		var user_export_journal ='true';
	}else{
		var user_export_journal ='false';
	}
	
	if ( $('#user_loss_profit').prop('checked')==true ){
		var user_loss_profit ='true';
	}else{
		var user_loss_profit ='false';
	}
	
	if ( $('#user_users').prop('checked')==true ){
		var user_users ='true';
	}else{
		var user_users ='false';
	}
	
	if ( $('#user_backup').prop('checked')==true ){
		var user_backup ='true';
	}else{
		var user_backup ='false';
	}
	
	if ( $('#user_restore').prop('checked')==true ){
		var user_restore ='true';
	}else{
		var user_restore ='false';
	}
	
	
	user ={
		
		user_name:user_name,
		user_password:user_password,
		user_branch:user_branch,
		
		user_view_account:user_view_account,
		user_insert_account:user_insert_account,
		user_update_account:user_update_account,
		user_delete_account:user_delete_account,
		user_export_accounts:user_export_accounts,
		
		
		user_view_stock:user_view_stock,
		user_insert_stock:user_insert_stock,
		user_update_stock:user_update_stock,
		user_delete_stock:user_delete_stock,
		user_cost:user_cost,
		user_all_items:user_all_items,
		user_export_stock:user_export_stock,

		user_view_sale:user_view_sale,
		user_insert_sale:user_insert_sale,
		user_update_sale:user_update_sale,
		user_delete_sale:user_delete_sale,
		
		user_view_r_sale:user_view_r_sale,
		user_insert_r_sale:user_insert_r_sale,
		user_update_r_sale:user_update_r_sale,
		user_delete_r_sale:user_delete_r_sale,
		
		user_view_purchase:user_view_purchase,
		user_insert_purchase:user_insert_purchase,
		user_update_purchase:user_update_purchase,
		user_delete_purchase:user_delete_purchase,
		
		user_view_r_purchase:user_view_r_purchase,
		user_insert_r_purchase:user_insert_r_purchase,
		user_update_r_purchase:user_update_r_purchase,
		user_delete_r_purchase:user_delete_r_purchase,
		
		user_view_income:user_view_income,
		user_insert_income:user_insert_income,
		user_update_income:user_update_income,
		user_delete_income:user_delete_income,
		
		user_view_outcome:user_view_outcome,
		user_insert_outcome:user_insert_outcome,
		user_update_outcome:user_update_outcome,
		user_delete_outcome:user_delete_outcome,
		
		user_view_receipt:user_view_receipt,
		user_insert_receipt:user_insert_receipt,
		user_update_receipt:user_update_receipt,
		user_delete_receipt:user_delete_receipt,
		
		user_view_payment:user_view_payment,
		user_insert_payment:user_insert_payment,
		user_update_payment:user_update_payment,
		user_delete_payment:user_delete_payment,
		
		user_all_branches:user_all_branches,
		user_journal:user_journal,
		user_export_journal:user_export_journal,

		user_loss_profit:user_loss_profit,
		user_users:user_users,
		user_backup:user_backup,
		user_restore:user_restore
		
	};
	
	user =JSON.stringify( user );
	
	loader_show();

	$.ajax({
		
		url:'php/ajax_post_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'insert_user', user },
		success:function(response){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}

			
			cancel_modal();
			cancel_modal();
			
			users_body();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
};
function update_user()
{
	
	if ( !( $('#user_password').val()!='' ) ){
		$('#user_password').css( 'border-bottom', '1px dashed red' );
		return ;
	}else{
		$('#user_password').css( 'border-bottom', 'none' );
	}
	
	var id =$('#user_id').val();
	
	var user_name =$('#user_name').val();
	var user_password =$('#user_password').val();
	var user_branch =$('#user_branch').val();

	if ( $('#user_view_account').prop('checked')==true ){
		var user_view_account ='true';
	}else{
		var user_view_account ='false';
	}
	
	if ( $('#user_insert_account').prop('checked')==true ){
		var user_insert_account ='true';
	}else{
		var user_insert_account ='false';
	}
	
	if ( $('#user_update_account').prop('checked')==true ){
		var user_update_account ='true';
	}else{
		var user_update_account ='false';
	}
	
	if ( $('#user_delete_account').prop('checked')==true ){
		var user_delete_account ='true';
	}else{
		var user_delete_account ='false';
	}
	
	if ( $('#user_export_accounts').prop('checked')==true ){
		var user_export_accounts ='true';
	}else{
		var user_export_accounts ='false';
	}


	if ( $('#user_view_stock').prop('checked')==true ){
		var user_view_stock ='true';
	}else{
		var user_view_stock ='false';
	}
	
	if ( $('#user_insert_stock').prop('checked')==true ){
		var user_insert_stock ='true';
	}else{
		var user_insert_stock ='false';
	}
	
	if ( $('#user_update_stock').prop('checked')==true ){
		var user_update_stock ='true';
	}else{
		var user_update_stock ='false';
	}
	
	if ( $('#user_delete_stock').prop('checked')==true ){
		var user_delete_stock ='true';
	}else{
		var user_delete_stock ='false';
	}
	
	if ( $('#user_cost').prop('checked')==true ){
		var user_cost ='true';
	}else{
		var user_cost ='false';
	}
	
	if ( $('#user_all_items').prop('checked')==true ){
		var user_all_items ='true';
	}else{
		var user_all_items ='false';
	}
	
	if ( $('#user_export_stock').prop('checked')==true ){
		var user_export_stock ='true';
	}else{
		var user_export_stock ='false';
	}

	
	if ( $('#user_view_sale').prop('checked')==true ){
		var user_view_sale ='true';
	}else{
		var user_view_sale ='false';
	}
	
	if ( $('#user_insert_sale').prop('checked')==true ){
		var user_insert_sale ='true';
	}else{
		var user_insert_sale ='false';
	}
	
	if ( $('#user_update_sale').prop('checked')==true ){
		var user_update_sale ='true';
	}else{
		var user_update_sale ='false';
	}
	
	if ( $('#user_delete_sale').prop('checked')==true ){
		var user_delete_sale ='true';
	}else{
		var user_delete_sale ='false';
	}


	if ( $('#user_view_r_sale').prop('checked')==true ){
		var user_view_r_sale ='true';
	}else{
		var user_view_r_sale ='false';
	}
	
	if ( $('#user_insert_r_sale').prop('checked')==true ){
		var user_insert_r_sale ='true';
	}else{
		var user_insert_r_sale ='false';
	}
	
	if ( $('#user_update_r_sale').prop('checked')==true ){
		var user_update_r_sale ='true';
	}else{
		var user_update_r_sale ='false';
	}
	
	if ( $('#user_delete_r_sale').prop('checked')==true ){
		var user_delete_r_sale ='true';
	}else{
		var user_delete_r_sale ='false';
	}


	if ( $('#user_view_purchase').prop('checked')==true ){
		var user_view_purchase ='true';
	}else{
		var user_view_purchase ='false';
	}
	
	if ( $('#user_insert_purchase').prop('checked')==true ){
		var user_insert_purchase ='true';
	}else{
		var user_insert_purchase ='false';
	}
	
	if ( $('#user_update_purchase').prop('checked')==true ){
		var user_update_purchase ='true';
	}else{
		var user_update_purchase ='false';
	}
	
	if ( $('#user_delete_purchase').prop('checked')==true ){
		var user_delete_purchase ='true';
	}else{
		var user_delete_purchase ='false';
	}
	
	
	if ( $('#user_view_r_purchase').prop('checked')==true ){
		var user_view_r_purchase ='true';
	}else{
		var user_view_r_purchase ='false';
	}
	
	if ( $('#user_insert_r_purchase').prop('checked')==true ){
		var user_insert_r_purchase ='true';
	}else{
		var user_insert_r_purchase ='false';
	}
	
	if ( $('#user_update_r_purchase').prop('checked')==true ){
		var user_update_r_purchase ='true';
	}else{
		var user_update_r_purchase ='false';
	}
	
	if ( $('#user_delete_r_purchase').prop('checked')==true ){
		var user_delete_r_purchase ='true';
	}else{
		var user_delete_r_purchase ='false';
	}

	
	if ( $('#user_view_income').prop('checked')==true ){
		var user_view_income ='true';
	}else{
		var user_view_income ='false';
	}
	
	if ( $('#user_insert_income').prop('checked')==true ){
		var user_insert_income ='true';
	}else{
		var user_insert_income ='false';
	}
	
	if ( $('#user_update_income').prop('checked')==true ){
		var user_update_income ='true';
	}else{
		var user_update_income ='false';
	}
	
	if ( $('#user_delete_income').prop('checked')==true ){
		var user_delete_income ='true';
	}else{
		var user_delete_income ='false';
	}


	if ( $('#user_view_outcome').prop('checked')==true ){
		var user_view_outcome ='true';
	}else{
		var user_view_outcome ='false';
	}
	
	if ( $('#user_insert_outcome').prop('checked')==true ){
		var user_insert_outcome ='true';
	}else{
		var user_insert_outcome ='false';
	}
	
	if ( $('#user_update_outcome').prop('checked')==true ){
		var user_update_outcome ='true';
	}else{
		var user_update_outcome ='false';
	}
	
	if ( $('#user_delete_outcome').prop('checked')==true ){
		var user_delete_outcome ='true';
	}else{
		var user_delete_outcome ='false';
	}

	if ( $('#user_view_receipt').prop('checked')==true ){
		var user_view_receipt ='true';
	}else{
		var user_view_receipt ='false';
	}
	
	if ( $('#user_insert_receipt').prop('checked')==true ){
		var user_insert_receipt ='true';
	}else{
		var user_insert_receipt ='false';
	}
	
	if ( $('#user_update_receipt').prop('checked')==true ){
		var user_update_receipt ='true';
	}else{
		var user_update_receipt ='false';
	}
	
	if ( $('#user_delete_receipt').prop('checked')==true ){
		var user_delete_receipt ='true';
	}else{
		var user_delete_receipt ='false';
	}


	if ( $('#user_view_payment').prop('checked')==true ){
		var user_view_payment ='true';
	}else{
		var user_view_payment ='false';
	}
	
	if ( $('#user_insert_payment').prop('checked')==true ){
		var user_insert_payment ='true';
	}else{
		var user_insert_payment ='false';
	}
	
	if ( $('#user_update_payment').prop('checked')==true ){
		var user_update_payment ='true';
	}else{
		var user_update_payment ='false';
	}
	
	if ( $('#user_delete_payment').prop('checked')==true ){
		var user_delete_payment ='true';
	}else{
		var user_delete_payment ='false';
	}


	if ( $('#user_all_branches').prop('checked')==true ){
		var user_all_branches ='true';
	}else{
		var user_all_branches ='false';
	}

	if ( $('#user_journal').prop('checked')==true ){
		var user_journal ='true';
	}else{
		var user_journal ='false';
	}
	
	if ( $('#user_export_journal').prop('checked')==true ){
		var user_export_journal ='true';
	}else{
		var user_export_journal ='false';
	}
	
	if ( $('#user_loss_profit').prop('checked')==true ){
		var user_loss_profit ='true';
	}else{
		var user_loss_profit ='false';
	}
	
	if ( $('#user_users').prop('checked')==true ){
		var user_users ='true';
	}else{
		var user_users ='false';
	}
	
	if ( $('#user_backup').prop('checked')==true ){
		var user_backup ='true';
	}else{
		var user_backup ='false';
	}
	
	if ( $('#user_restore').prop('checked')==true ){
		var user_restore ='true';
	}else{
		var user_restore ='false';
	}

	user ={
		
		user_password:user_password,
		user_branch:user_branch,
		
		user_view_account:user_view_account,
		user_insert_account:user_insert_account,
		user_update_account:user_update_account,
		user_delete_account:user_delete_account,
		user_export_accounts:user_export_accounts,

		
		user_view_stock:user_view_stock,
		user_insert_stock:user_insert_stock,
		user_update_stock:user_update_stock,
		user_delete_stock:user_delete_stock,
		user_cost:user_cost,
		user_all_items:user_all_items,
		user_export_stock:user_export_stock,

		user_view_sale:user_view_sale,
		user_insert_sale:user_insert_sale,
		user_update_sale:user_update_sale,
		user_delete_sale:user_delete_sale,
		
		user_view_r_sale:user_view_r_sale,
		user_insert_r_sale:user_insert_r_sale,
		user_update_r_sale:user_update_r_sale,
		user_delete_r_sale:user_delete_r_sale,
		
		user_view_purchase:user_view_purchase,
		user_insert_purchase:user_insert_purchase,
		user_update_purchase:user_update_purchase,
		user_delete_purchase:user_delete_purchase,
		
		user_view_r_purchase:user_view_r_purchase,
		user_insert_r_purchase:user_insert_r_purchase,
		user_update_r_purchase:user_update_r_purchase,
		user_delete_r_purchase:user_delete_r_purchase,
		
		user_view_income:user_view_income,
		user_insert_income:user_insert_income,
		user_update_income:user_update_income,
		user_delete_income:user_delete_income,
		
		user_view_outcome:user_view_outcome,
		user_insert_outcome:user_insert_outcome,
		user_update_outcome:user_update_outcome,
		user_delete_outcome:user_delete_outcome,
		
		user_view_receipt:user_view_receipt,
		user_insert_receipt:user_insert_receipt,
		user_update_receipt:user_update_receipt,
		user_delete_receipt:user_delete_receipt,
		
		user_view_payment:user_view_payment,
		user_insert_payment:user_insert_payment,
		user_update_payment:user_update_payment,
		user_delete_payment:user_delete_payment,
		
		user_all_branches:user_all_branches,
		user_journal:user_journal,
		user_export_journal:user_export_journal,
		user_loss_profit:user_loss_profit,
		user_users:user_users,
		user_backup:user_backup,
		user_restore:user_restore
		
	};

	user =JSON.stringify( user );

	loader_show();
	
	$.ajax({
		
		url:'php/ajax_post_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'update_user', user, id },
		success:function(response){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}

			
			cancel_modal();
			cancel_modal();
			
			users_body();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
};
function delete_user( this_button )
{
	
	if ( !(confirm("Dalete User ?")) ){
		return
	}
	
	var id =0;

	var this_user = $(this_button).closest('.order-item');


	id =$(this_user).children('.user-id').val();


	loader_show();
	
	$.ajax({
		
		url:'php/ajax_post_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'delete_user', id },
		success:function(response){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			cancel_modal();
			
			users_body();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

	});
	
};
/* BackUp */
function backup()
{
	
	if ( !(confirm('BackUp ?') ) ){
		return;
	}
	
	loader_show();
	
	$.ajax({
		
		url:'php/ajax_post_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'backup' },
		success:function(response){
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}
function restore()
{
	
	if ( !(confirm('Restore ?') ) ){
		return;
	}
	
	loader_show();
	
	$.ajax({
		
		url:'php/ajax_post_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'restore' },
		success:function(response){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}