/* t_accounts */
function accounts_body()
{

	var page_number =$('.page-number').val();
	
	var page_search_branch =$('.page-search-branch').val();
	var page_search_account =$('.page-search-account').val();
	var page_search_type =$('.page-search-type').val();
	var page_search_order =$('.page-search-order').val();
	
	$('.load-btn').remove();
	
	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{action:'select_accounts', page_number, page_search_branch, page_search_account, page_search_type, page_search_order},
		success:function( response ){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
				window.location= 'home.php';
				return;
			}
			
			loader_remove();

			$('.page-number').val( parseInt( $('.page-number').val() ) + 1 );
			
			$('.loader').remove();
			
			$('.items-body').append( response['data'] );
			
			$('.item').first().addClass('selected');
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}
function insert_account_modal()
{

	loader_show();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'insert_account_modal' },
		success:function( response ){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			

			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			$('body').append( response['data'] );
			$('.autofocus').focus();
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

		
	});

}
function update_account_modal()
{
	
	if ( !( $('.item-container .selected').length==1 ) ){
		alert('Select Account');
		return;
	}
	
	var id =$('.item-container .selected').data('id');
	
		loader_show();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'update_account_modal', id },
		success:function( response ){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			

			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			$('body').append( response['data'] );
			$('.autofocus').focus();
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

		
	});
	
}
function refresh_account( id, second_id )
{
	
	loader_show();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'refresh_account', id },
		success:function( response ){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			$('.item-container .item').each(function(){
				
				if ( $(this).data('id') == id ) {					
					$(this).replaceWith(response['data']);
				}
				
			});
			
			$('.item-container .selected').removeClass('selected');

			$('.item-container .item').each(function(){
				
				if ( $(this).data('id') == id ) {					
					$(this).addClass('selected');
				}
				
			});

		},

		
	});
	
	if ( second_id == '' ){
		loader_remove();
		return;
	}

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'refresh_account', id:second_id },
		success:function( response ){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			$('.item-container .item').each(function(){
				
				if ( $(this).data('id') == second_id ) {					
					$(this).replaceWith(response['data']);
				}
				
			});
			
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

		
	});
	
}
function more_account_modal()
{
	
	if ( !( $('.item-container .selected').length==1 ) ){
		alert('Select Account');
		return;
	}
	
	var id =$('.item-container .selected').data('id');
	
		loader_show();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'more_account_modal', id },
		success:function( response ){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			$('body').append( response['data'] );
			$('.autofocus').focus();
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

		
	});
	
}
function cancel_modal()
{
	
	$('.modal:last').remove();
	
}
function account_body()
{
	var page_number =$('.account-page-number').val();
	var page_search =$('.account-page-search').val();

	if ( account_id==undefined ){		
		var account_id =$('#invoice_account_id').val();
	}
	if ( account_id==undefined ){		
		var account_id =$('#payment_account_id').val();
	}
	if ( account_id==undefined ){		
		var account_id =$('#income_account_id').val();
	}

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{action:'select_payment_accounts', account_id,page_number, page_search},
		success:function( response ){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			loader_remove();

			$('.account-page-number').val( parseInt( $('.account-page-number').val() ) + 1 );

			$('.loader').remove();
			
			$('.account-body').append( response['data'] );
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}
/* t_payments */
function payments_body()
{

	var page_number =$('.page-number').val();
	
	var page_search_branch =$('.page-search-branch').val();
	var page_search_id =$('.page-search-id').val();
	var page_search_account =$('.page-search-account').val();
	var page_search_type =$('.page-search-type').val();
	var page_search_order =$('.page-search-order').val();
	
	$('.load-btn').remove();
	
	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{action:'select_payments', page_number, page_search_branch, page_search_id, page_search_account, page_search_type, page_search_order},
		success:function( response ){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
				window.location= 'home.php';
				return;
			}
			
			loader_remove();

			$('.page-number').val( parseInt( $('.page-number').val() ) + 1 );
			
			$('.loader').remove();
			
			$('.items-body').append( response['data'] );
			
			$('.item').first().addClass('selected');
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}
function insert_payment_modal( type )
{

	if ( !( $('.item-container .selected').length==1 ) ){
		alert('Select Account');
		return;
	}
	
	var account_id =$('.item-container .selected').data('id');
	
	loader_show();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'insert_payment_modal', account_id, type },
		success:function( response ){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			$('body').append( response['data'] );
			$('.autofocus').focus();
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

		
	});

}
function update_payment_modal()
{

	if ( !( $('.item-container .selected').length==1 ) ){
		alert('Select Payment');
		return;
	}
	
	var id =$('.item-container .selected').data('id');
	
	loader_show();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'update_payment_modal', id },
		success:function( response ){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			$('body').append( response['data'] );
			$('.autofocus').focus();
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

		
	});

}
function refresh_payment( id )
{
	
	loader_show();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'refresh_payment', id },
		success:function( response ){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			$('.item-container .item').each(function(){
				
				if ( $(this).data('id') == id ) {					
					$(this).replaceWith(response['data']);
				}
				
			});

			$('.item-container .item').each(function(){
				
				if ( $(this).data('id') == id ) {					
					$(this).addClass('selected');
				}
				
			});

			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

		
	});
}
function more_payment_modal( id )
{

	if (id==''){
		
		if ( !( $('.item-container .selected').length==1 ) ){
			alert('Select Payment');
			return;
		}
		
		var id =$('.item-container .selected').data('id');
	
	}

	loader_show();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'more_payment_modal', id },
		success:function( response ){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			$('body').append( response['data'] );
			$('.autofocus').focus();
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

		
	});

}
function cancel_payment()
{
	
	$('.new-payment').remove();
	
}
/* t_invoices */
function invoices_body()
{

	var page_number =$('.page-number').val();
	
	var page_search_branch =$('.page-search-branch').val();
	var page_search_id =$('.page-search-id').val();
	var page_search_account =$('.page-search-account').val();
	var page_search_type =$('.page-search-type').val();
	var page_search_order =$('.page-search-order').val();
	
	$('.load-btn').remove();
	
	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{action:'select_invoices', page_number, page_search_branch, page_search_id, page_search_account, page_search_type, page_search_order},
		success:function( response ){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
				window.location= 'home.php';
				return;
			}
			
			loader_remove();

			$('.page-number').val( parseInt( $('.page-number').val() ) + 1 );
			
			$('.loader').remove();
			
			$('.items-body').append( response['data'] );
			
			$('.item').first().addClass('selected');
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}
function insert_invoice_modal( type )
{
	
	if ( !( $('.item-container .selected').length==1 ) ){
		alert('Select Account');
		return;
	}
	
	var account_type =$('.item-container .selected').data('type');
	var account_id =$('.item-container .selected').data('id');


	
	loader_show();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'insert_invoice_modal', account_id, type },
		success:function( response ){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			$('body').append( response['data'] );
			$('.autofocus').focus();
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

		
	});


	
	
	
};
function update_invoice_modal()
{
	
	if ( !( $('.item-container .selected').length==1 ) ){
		alert('Select Invoice');
		return;
	}

	var id =$('.item-container .selected').data('id');
	var type =$('.item-container .selected').data('type');
	
	if ( type!='Sale' && type!='R Sale' && type!='Purchase' && type!='R Purchase' ){
		update_income_modal();
		return;
	}
	
	loader_show();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'update_invoice_modal', id },
		success:function( response ){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			$('body').append( response['data'] );
			$('.autofocus').focus();
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

		
	});


	
	
	
};
function refresh_invoice( id )
{
	
	loader_show();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'refresh_invoice', id },
		success:function( response ){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			$('.item-container .item').each(function(){
				
				if ( $(this).data('id') == id ) {					
					$(this).replaceWith(response['data']);
				}
				
			});

			$('.item-container .item').each(function(){
				
				if ( $(this).data('id') == id ) {					
					$(this).addClass('selected');
				}
				
			});

			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

		
	});
}
function more_invoice_modal( id )
{
	
	if ( id=='' ){
		
		if ( !( $('.item-container .selected').length==1 ) ){
			alert('Select Invoice');
			return;
		}

		var id =$('.item-container .selected').data('id');
		var type =$('.item-container .selected').data('type');

	}else{
		var type = 'Sale';
	}
	
	if ( type!='Sale' && type!='R Sale' && type!='Purchase' && type!='R Purchase' ){
		more_income_modal( '' );
		return;
	}
	
	loader_show();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'more_invoice_modal', id },
		success:function( response ){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			$('body').append( response['data'] );
			$('.autofocus').focus();
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

		
	});


	
	
	
};
function insert_income_modal( type )
{
	
	if ( !( $('.item-container .selected').length==1 ) ){
		alert('Select Account');
		return;
	}
	
	var account_type =$('.item-container .selected').data('type');
	var account_id =$('.item-container .selected').data('id');

	
	loader_show();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'insert_income_modal', account_id, type },
		success:function( response ){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			$('body').append( response['data'] );
			$('.autofocus').focus();
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

		
	});


	
	
	
};
function update_income_modal()
{
	
	if ( !( $('.item-container .selected').length==1 ) ){
		alert('Select Invoice');
		return;
	}

	var id =$('.item-container .selected').data('id');
	
	loader_show();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'update_income_modal', id },
		success:function( response ){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
				
				if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			$('body').append( response['data'] );
			$('.autofocus').focus();
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

		
	});


	
	
	
};
function more_income_modal( id )
{
	if (id==''){
		
		if ( !( $('.item-container .selected').length==1 ) ){
			alert('Select Invoice');
			return;
		}

		var id =$('.item-container .selected').data('id');
		
	}
	
	loader_show();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'more_income_modal', id },
		success:function( response ){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			$('body').append( response['data'] );
			$('.autofocus').focus();
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

		
	});


	
	
	
};
/* t_items */
function inventory_modal()
{
	
	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{action:'select_inventory_modal'},
		success:function( response ){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			loader_remove();
			
			$('body').append( response['data'] );
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}
function inventory()
{

	var page_search_branch =$('.inventory-page-search-branch').val();
	var page_search_from =$('.inventory-page-search-from').val();
	var page_search_to =$('.inventory-page-search-to').val();


	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{action:'select_inventory', page_search_branch, page_search_from, page_search_to },
		success:function( response ){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			loader_remove();
			
			$('.response-textarea').html( response['data'] );
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}
function all_items_modal()
{

	$('.load-btn').remove();
	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{action:'select_all_items_modal'},
		success:function( response ){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			loader_remove();

			$('.page-number').val( parseInt( $('.page-number').val() ) + 1 );
			
			$('body').append( response['data'] );
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}
function all_items_body()
{

	var page_search_branch =$('.all-items-page-search-branch').val();
	var page_search_from =$('.all-items-page-search-from').val();
	var page_search_to =$('.all-items-page-search-to').val();
	var page_search_product =$('.all-items-page-search-product').val();
	var page_search_category1 =$('.all-items-page-search-category1').val();
	var page_search_category2 =$('.all-items-page-search-category2').val();
	var page_search_category3 =$('.all-items-page-search-category3').val();
	var page_search_category4 =$('.all-items-page-search-category4').val();
	var page_search_category5 =$('.all-items-page-search-category5').val();
	var page_search_category6 =$('.all-items-page-search-category6').val();
	var page_search_category7 =$('.all-items-page-search-category7').val();
	var page_search_category8 =$('.all-items-page-search-category8').val();

	$('.load-btn').remove();
	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{action:'select_all_items', page_search_branch, page_search_from, page_search_to, page_search_product, page_search_category1, page_search_category2, page_search_category3, page_search_category4, page_search_category5, page_search_category6, page_search_category7, page_search_category8},
		success:function( response ){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			loader_remove();
			
			$('.all-items-container').html( response['data'] );
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}
function loss_profit_modal()
{
	
	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{action:'select_loss_profit_modal'},
		success:function( response ){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			loader_remove();
			
			$('body').append( response['data'] );
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}
function loss_profit()
{

	var page_search_branch =$('.loss-porfit-page-search-branch').val();
	var page_search_from =$('.loss-porfit-page-search-from').val();
	var page_search_to =$('.loss-porfit-page-search-to').val();


	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{action:'select_loss_profit', page_search_branch, page_search_from, page_search_to },
		success:function( response ){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			loader_remove();
			
			$('.response-textarea').html( response['data'] );
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}
/* t_stock */
function products_body()
{
	var page_number =$('.page-number').val();
	
	var page_search_branch =$('.page-search-branch').val();
	var page_search_product =$('.page-search-product').val();
	var page_search_category1 =$('.page-search-category1').val();
	var page_search_category2 =$('.page-search-category2').val();
	var page_search_category3 =$('.page-search-category3').val();
	var page_search_category4 =$('.page-search-category4').val();
	var page_search_category5 =$('.page-search-category5').val();
	var page_search_category6 =$('.page-search-category6').val();
	var page_search_category7 =$('.page-search-category7').val();
	var page_search_category8 =$('.page-search-category8').val();
	var page_search_order =$('.page-search-order').val();
	
	$('.load-btn').remove();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{action:'select_products', page_number, page_search_branch, page_search_product, page_search_category1, page_search_category2, page_search_category3, page_search_category4, page_search_category5, page_search_category6, page_search_category7, page_search_category8, page_search_order },
		success:function( response ){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
				window.location= 'home.php';
				return;
			}
			
			loader_remove();

			$('.page-number').val( parseInt( $('.page-number').val() ) + 1 );
			
			
			$('.loader').remove();
			
			$('.items-body').append( response['data'] );
			
			$('.item').first().addClass('selected');
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}
function insert_product_modal()
{

	loader_show();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'insert_product_modal' },
		success:function( response ){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			$('body').append( response['data'] );
			$('.autofocus').focus();
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

		
	});

}
function update_product_modal()
{

	if ( !( $('.item-container .selected').length==1 ) ){
		alert('Select Product');
		return;
	}
	
	var id =$('.item-container .selected').data('id');

	loader_show();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'update_product_modal', id },
		success:function( response ){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			$('body').append( response['data'] );
			$('.autofocus').focus();
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

		
	});

}
function refresh_product( id )
{
	
	loader_show();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'refresh_product', id },
		success:function( response ){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			$('.item-container .item').each(function(){
				
				if ( $(this).data('id') == id ) {					
					$(this).replaceWith(response['data']);
				}
				
			});

			$('.item-container .item').each(function(){
				
				if ( $(this).data('id') == id ) {					
					$(this).addClass('selected');
				}
				
			});

			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

		
	});
}
function more_product_modal()
{

	if ( !( $('.item-container .selected').length==1 ) ){
		alert('Select Account');
		return;
	}
	
	var id =$('.item-container .selected').data('id');

	loader_show();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'more_product_modal', id },
		success:function( response ){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			$('body').append( response['data'] );
			$('.autofocus').focus();
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

		
	});

}
function invoice_products_body()
{
	var page_number =$('.invoice-product-page-number').val();
	
	var page_search_product =$('.invoice-product-page-search-product').val();
	var page_search_category1 =$('.invoice-product-page-search-category1').val();
	var page_search_category2 =$('.invoice-product-page-search-category2').val();
	var page_search_category3 =$('.invoice-product-page-search-category3').val();
	var page_search_category4 =$('.invoice-product-page-search-category4').val();
	var page_search_category5 =$('.invoice-product-page-search-category5').val();
	var page_search_category6 =$('.invoice-product-page-search-category6').val();
	var page_search_category7 =$('.invoice-product-page-search-category7').val();
	var page_search_category8 =$('.invoice-product-page-search-category8').val();

	var type =$('#invoice_type').val();
	
	var account_id =$('#invoice_account_id').val();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{action:'select_invoice_products', account_id, type, page_number, page_search_product, page_search_category1, page_search_category2, page_search_category3, page_search_category4, page_search_category5, page_search_category6, page_search_category7, page_search_category8 },
		success:function( response ){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			loader_remove();

			$('.invoice-product-page-number').val( parseInt( $('.invoice-product-page-number').val() ) + 1 );

			$('.loader').remove();
			
			$('.invoice-products-body').append( response['data'] );
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}
/* t_journal */
function journal_body()
{

	var page_number =$('.page-number').val();
	
	var page_search_branch =$('.page-search-branch').val();
	var page_search_from =$('.page-search-from').val();
	var page_search_to =$('.page-search-to').val();
	var page_search_account =$('.page-search-account').val();
	var page_search_type =$('.page-search-type').val();
	var page_search_order =$('.page-search-order').val();
	
	$('.load-btn').remove();
	
	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{action:'select_journal', page_number, page_search_branch, page_search_from, page_search_to, page_search_account, page_search_type, page_search_order},
		success:function( response ){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
				window.location= 'home.php';
				return;
			}
			
			$('.page-number').val( parseInt( $('.page-number').val() ) + 1 );
			
			$('.items-body').append( response['data'] );
			
			$('.item').first().addClass('selected');
			
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}
function update_journal_modal()
{
	if ( !( $('.item-container .selected').length==1 ) ){
		alert('Select Entry');
		return;
	}

	var type =$('.item-container .selected').data('type');
	
	if ( type == 'Payment' || type == 'Receipt' ){
		update_payment_modal();
		return;
	}
	
	if ( type == 'Income' || type == 'Outcome' ){
		update_income_modal();
		return;
	}
	
	if ( type == 'Sale' || type == 'R Sale' || type == 'Purchase' || type == 'R Purchase'  ){
		update_invoice_modal();
		return;
	}
	
}
function more_journal_modal( parent_id, type )
{
	
	if (parent_id==''){
		
		if ( !( $('.item-container .selected').length==1 ) ){
			alert('Select Entry');
			return;
		}

		var type =$('.item-container .selected').data('type');
		
	}

	if ( type == 'Payment' || type == 'Receipt' ){
		more_payment_modal( parent_id );
		return;
	}
	
	if ( type == 'Income' || type == 'Outcome' ){
		more_income_modal( parent_id );
		return;
	}
	
	if ( type == 'Sale' || type == 'R Sale' || type == 'Purchase' || type == 'R Purchase'  ){
		more_invoice_modal( parent_id );
		return;
	}

	
}
function total_body( from_date, to_date, user )
{

	var page_number =$('.page-number').val();
	var page_search =$('.page-search').val();

	cancel_modal();
	
	$('.load-btn').remove();
	
	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{action:'select_total', from_date, to_date, user},
		success:function( response ){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			loader_remove();

			$('.page-number').val( parseInt( $('.page-number').val() ) + 1 );
			
			$('body').append( response['data'] );
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}
/* t_users */
function users_body()
{

	var page_number =$('.page-number').val();
	var page_search =$('.page-search').val();
	
	$('.load-btn').remove();
	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{action:'select_users', page_number, page_search},
		success:function( response ){

			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			
			if ( response['not-authnicated']=='true' ){
				alert('Not Authnicated');
			}
			
			loader_remove();

			$('.page-number').val( parseInt( $('.page-number').val() ) + 1 );
			
			$('body').append( response['data'] );
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}
		
	});
	
}
function update_user_modal( this_button )
{
	
	var this_user = $(this_button).closest('.order-item');


	id =$(this_user).children('.user-id').val();
	
	loader_show();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'update_user_modal',id },
		success:function( response ){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			$('body').append( response['data'] );
			$('.autofocus').focus();
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

		
	});

}
function insert_user_modal()
{

	loader_show();

	$.ajax({
		
		url:'php/ajax_get_handler.php',
		type:'POST',
		dataType:'json',
		tryCount: 0,
		trylimit: 3,
		data:{ action:'insert_user_modal', },
		success:function( response ){
			
			if ( !( response['error']==0 ) ){
				
				if ( response['sign-out']=='true' ){
					location.reload();
					return;
				}
				
				console.error(response['error']);
				return;
				
			}
			$('body').append( response['data'] );
			$('.autofocus').focus();
			loader_remove();
			
		},
		error:function(){
			this.tryCount++;
			if ( this.tryCount < this.trylimit ){
				$.ajax(this);
			}

		}

		
	});

}