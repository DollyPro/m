
function loader_show(){
	$('body').append(`
		<div class="loader" style="
			background-color:transparent;
			background-color:rgb(0,0,0,0.3);
			position:fixed;
			z-index:999;
			top:0px;
			bottom:0px;
			width:100%;		
		">
			<div style="
				position:fixed;
				width:100px;
				height:25px;
				top:0px;
				bottom:0px;
				left:0px;
				right:0px;
				margin:auto;
				background-color:orange;
				border-radius:4px;
				border:1px solid black;
				font-weight:bold;
				box-shadow: 0px 0px 5px #333;
			">
				Loading...
			</div>
		</div>
	`);
}
function loader_remove(){
	$('.loader').remove();
}
function remove_focus(){
	$("input").blur();
}
function show_menu(){
	
	var show = false ;

	if ( $('.menu').css('display')=='none' ){
		
		show=true;
		
	}
	
	$('.menu').css('display', 'none');

	if (show){
		
		$('.menu').css('display', 'block');

	}
	
};
function show_map(allow,my_location){
	
	var action_btn='';
	
	if (my_location==''){
		my_location='0,0';
	}
	
	if (allow=='true'){
	
	action_btn=`
	
		<i onclick="save_location();" class="fas fa-check"></i>
		<i onclick="remove_location();"  class="fas fa-trash-alt"></i>
	`
	}
	
	$('body').append(`
		
		<div class="map-container">

			<div id="map"></div>
			<div class="action">
			`+action_btn+`
			<i onclick="cancel_location();" class="fas fa-times"></i>
			<input type="hidden" class="map-location" value="`+ my_location +`">
			</div>

		</div>
	
	`);
	
		
	var latlng=$('.map-location').val();

	var latlng=latlng.split(',');

	var lat = latlng[0];
	var lng = latlng[1];		

	if (!(lat>0 || lat<0 || lat==0))
		lat=0;

	if (!(lng>0 || lng<0 || lng==0))
		lng=0;

	window.my_map = L.map('map').setView([lat, lng], 3);

	window.marker = L.marker([lat, lng]).addTo(my_map);
	
	L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
		attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
		maxZoom: 18,
		id: 'mapbox/streets-v11',
		accessToken: 'pk.eyJ1IjoibWFoZGlzYW1oYXQiLCJhIjoiY2s2anp5ZGYxMDByaDNucXQ2MHltM3BtbyJ9.SyZ9aKt8I_p_DAXqYVqrnw'
	}).addTo(my_map);
	
	if (allow=='true')
		my_map.on('click', get_latlng);

	
}
function get_latlng(e){
	
	var coord = e.latlng.toString().split(',');
	var lat = coord[0].split('(');
	var lat = lat[1];
	var lng = coord[1].split(')');
	var lng = lng[0];
	
    my_map.removeLayer(marker);		
	
	window.marker =	L.marker([lat,lng]).addTo(my_map);
	
	//my_map.setView([lat, lng]);
	
	$('.map-location').val(lat+','+lng);
	
}
function save_location(){

	try{
		var latlng=$('.map-location').val();
		var latlng=latlng.split(',');
		var lat = latlng[0];
		var lng = latlng[1];
		
		$('.location-input').val(lat+','+lng);
		
	}
	catch(error){
		$('.location-input').val('0, 0');
		$('.map-location').val(0+', '+0);
		window.marker =	L.marker([0,0]).addTo(my_map);
	}
	
	$('.map-container').remove();

}
function cancel_location(){
	$('.map-container').remove();
}
function remove_location(){
	$('.location-input').val('');
	$('.map-container').remove();
}
function select_item( my_element ){
	
	$('.item').removeClass('selected');
	$(my_element).addClass('selected');
	
};
function show_account_modal( my_input ){
	loader_show();
	$(my_input).parent('section').addClass('active');	
	$('.account-body').html('');
	$('.account-page-number').val( 0 );
	$('.account-page-search').val( '' );
	$('.account-page-search-input').val('');
	account_body();
	$('.account-id-modal').show();
}
function cancel_account_modal(){
	$('.account-id-modal').hide();
	$('.active').removeClass('active');
}
function save_account_modal(){
	
	if ( !( $('.account-id-modal .selected').length > 0 ) ){
		return;
	}
	
	var account_id =$('.account-id-modal .selected').data('id');
	var account_name =$('.account-id-modal .selected').data('name');

	$('.active .account-input').val(account_name);
	$('.active .account ').val(account_id);
	
	$('.active').removeClass('active');
	$('.account-id-modal').hide();
	
}
function save_account_modal_order(){
	
	if ( !( $('.account-id-modal .selected').length > 0 ) ){
		return;
	}
	
	var account_id =$('.account-id-modal .selected').data('id');
	var account_name =$('.account-id-modal .selected').data('name');

	$('.order-item .active').val(account_name);
	$('.order-item .active').parent('section').parent('.order-item').children('.second_account').val(account_id);
	
	$('.account-id-modal').hide();
	
	$('.order-item .active').removeClass('active');
	
}
function show_items(){

	loader_show();
	$('.invoice-products-body').html('');
	$('.invoice-product-page-number').val( 0 );
	
	$('.invoice-product-page-search-product').val('');
	$('.invoice-product-page-search-category1').val('');
	$('.invoice-product-page-search-category2').val('');
	$('.invoice-product-page-search-category3').val('');
	$('.invoice-product-page-search-category4').val('');
	$('.invoice-product-page-search-category5').val('');
	$('.invoice-product-page-search-category6').val('');
	$('.invoice-product-page-search-category7').val('');
	$('.invoice-product-page-search-category8').val('');
	
	$('.invoice-product-page-search-input-product').val('');
	$('.invoice-product-page-search-input-category1').val('');
	$('.invoice-product-page-search-input-category2').val('');
	$('.invoice-product-page-search-input-category3').val('');
	$('.invoice-product-page-search-input-category4').val('');
	$('.invoice-product-page-search-input-category5').val('');
	$('.invoice-product-page-search-input-category6').val('');
	$('.invoice-product-page-search-input-category7').val('');
	$('.invoice-product-page-search-input-category8').val('');
	
	invoice_products_body();
	$('.invoice-stock').show();

}
function cancel_items(){
	$('.invoice-stock').hide();
}
function save_items(){
	
	var item ='';
	
	$('.stock-item-container table .selected').each(function() {
		

			var item_id =$(this).data('id');
			var item_name =$(this).data('name');
			var price =$(this).data('price');
		
			$(this).removeClass('selected');
		
			item = item + `
				<div class="invoice-item">
					<input  class="item-id" type="hidden" value="`+ item_id +`">
					<section class="item-name"><i class="fas fa-caret-down"> `+ item_name +`</i><i class="fas fa-trash delete-item"></i></section>
					<section><h6>Qty.</h6><input class="item-qty" type="number" value="1"></section>
					<section><h6>Price</h6><input class="item-price" type="number" value="`+ price +`"></section>
					<section><h6>Disc.%.</h6><input  class="item-discount" type="number" value="0"></section>
				</div>
			`;
		
	});
	
	$('.invoice-items').append(item);
	
	$('.invoice-stock').hide();
	
	change_invoice();
}
function change_invoice(){
	
	var qty =0;
	var price =0;
	var item_discount =0;
	var item_ammount =0;
	
	var invoice_total =0;
	var invoice_discount =0;
	var invoice_net =0;
	
	$('.invoice-item').each(function(){
		
		if ( !($(this).children('section').children('.item-qty').val()>0) ){
			$(this).children('section').children('.item-qty').val('0');
		}
		qty =$(this).children('section').children('.item-qty').val();
		
		if ( !($(this).children('section').children('.item-price').val()>0) ){
			$(this).children('section').children('.item-price').val('0');
		}
		price =$(this).children('section').children('.item-price').val();
		
		if ( !($(this).children('section').children('.item-discount').val()>0) ){
			$(this).children('section').children('.item-discount').val('0');
		}
		item_discount =$(this).children('section').children('.item-discount').val();
		
		item_ammount = (qty*price) - ( (qty*price) * (item_discount/100) ) ;
		
		if ( item_ammount>0 ){
			$(this).css( 'background-color', '' );
		}
			
		invoice_total =invoice_total + item_ammount;
		
		
	});
	
	$('#invoice_total').val( invoice_total );
	
	if ( !($('#invoice_discount').val()<=invoice_total) ){
		$('#invoice_discount').val('0');
	}
	invoice_discount =$('#invoice_discount').val();
	
	invoice_net =invoice_total-invoice_discount;
	$('#invoice_net').val( invoice_net );
	
};
function add_active_class_order( my_element ){
	$('.order-item .active').removeClass('active');
	$(my_element).addClass('active');
}
function cancel_user_modal(){
	$('.user-modal').remove();
}

$(window).on('load',(function(){
	
	var title =document.title;
	if (title =='M.Accounts'){		
		accounts_body();
	}
	if (title =='M.Stock'){
		products_body();
	}
	if (title =='M.Payments'){
		payments_body();
	}
	if (title =='M.Invoices'){
		invoices_body();
	}
	if (title =='M.Journal'){
		
		Date.prototype.toDateInputValue = (function() {
		var local = new Date(this);
		local.setMinutes(this.getMinutes() - this.getTimezoneOffset());
		return local.toJSON().slice(0,10);
		});
		
		$('.default-today').val( new Date().toDateInputValue() );
		
		journal_body();
		
	}
	if (title =='M.Home'){
		loader_remove();
	}
	
}));

$(document).on('click', '.item-container .item', function(){
	
	var my_element = $(this) ;
	
	select_item( my_element );
	
	
});

$(document).on('dblclick', '.item-container .item', function(){
	
	$(this).children('.more').click();
	
});

$(document).on('click','.invoice-items .item-name .delete-item',function(){
	
	$(this).closest('div').remove();
	
	change_invoice()
	
});

$(document).on('click','.invoice-items .item-name',function(){
	
	var show =false;
	
	if ( !( $(this).parent('div').hasClass('active') ) ){
		show=true;
	}

	$('.invoice-items div').removeClass('active');
	$('.invoice-items div .item-name i:not(.delete-item)').attr('class', 'fas fa-caret-down');
	
	if (show){
		$(this).parent('div').addClass('active');
		$(this).children('i:not(.delete-item)').attr('class', 'fas fa-caret-up');
	}

});

$(document).on('click','.order-items .order-item-name',function(){
	
	var show =false;
	
	if ( !( $(this).parent('div').hasClass('active') ) ){
		show=true;
	}

	$('.order-items div').removeClass('active');
	
	$('.order-items div .order-item-name i').each(function(){
		if ( $(this).attr('class')=='fas fa-caret-down' || $(this).attr('class')=='fas fa-caret-up' ){
			$(this).attr('class', 'fas fa-caret-down');
		}
	});
	
	if (show){
		$(this).parent('div').addClass('active');
		
		$('.order-items .active .order-item-name i').each(function(){
		if ( $(this).attr('class')=='fas fa-caret-down' || $(this).attr('class')=='fas fa-caret-up' ){
			$(this).attr('class', 'fas fa-caret-up');
		}
	});
	}

});

$(document).on('click','.stock-item-container tr',function(){
	
	var select =false;
	
	if ( !( $(this).hasClass('selected') ) ){
		select=true;
	}
	
	if (select){	
		$(this).addClass('selected');
	}
	else{
		$(this).removeClass('selected');
	}
	
});

$(document).on('click','.account-item-container tr',function(){
	
	$('.account-item-container tr').removeClass('selected');
	
	$(this).addClass('selected');	
	
});

$(document).on('focus','input',function(){
	$(this).select();
});

$(document).on('click','h6',function(){
	$(this).parent('section').children('input').focus();
});

$(document).on('input','.invoice-modal input',function(){
	change_invoice();
});

$(document).on('input','.invoice-modal .invoice-items input',function(){
	
	if ( !($(this).val()>=0) ){
		$(this).val('0');
	}
	
});

$(document).on('input','.order-modal .order-item input',function(){
	
	if ( !($(this).val()>=0) ){
		$(this).val('0');
	}
	
});

$(document).on('click','.order-modal .order-items .purchase-order-item',function(){
	
	insert_purchase( this );
	
});

$(document).on('click','.order-modal .order-items .confirm-purchase-item',function(){
	
	confirm_purchase( this );
	
});

$(document).on('click','.order-modal .order-items .delete-purchase-item',function(){
	
	delete_purchase( this );
	
});

$(document).on('click','.order-modal .order-items .update-user-btn',function(){
	
	update_user_modal( this );
	
});

$(document).on('click','.order-modal .order-items .delete-user-btn',function(){
	
	delete_user( this );
	
});

$(document).on('click','.more-invoice-btn',function(){
	
	more_invoice_modal('');
	
});

$(document).on('click','.more-journal-btn',function(){
	
	more_journal_modal('', '');
	
});

$(document).on('click','.more-payment-btn',function(){
	
	more_journal_modal('');
	
});

$(document).on('click','.more-product-btn',function(){
	
	more_product_modal();
	
});

$(document).on('click','.product-activity tr',function(){
	
	var invoice_id = $(this).children('.invoice-id').val();
	
	more_invoice_modal( invoice_id );
	
});

$(document).on('click','.more-account-btn',function(){
	
	more_account_modal();
	
});

$(document).on('click','.account-activity tr',function(){
	
	var parent_id = $(this).children('.parent-id').val();
	var type = $(this).children('.type').val();
	
	more_journal_modal( parent_id, type );	
});

$(document).on('click','.account-items tr',function(){
	
	var invoice_id = $(this).children('.invoice-id').val();
	
	more_invoice_modal( invoice_id );	
});

$(document).on('click','.selected .active-invoice-btn',function(){
	
	active_invoice();
	
});

$(document).on('click','.selected .pay-invoice-btn',function(){
	
	pay_invoice();
	
});

$(document).on('click','.selected .active-payment-btn',function(){
	
	active_payment();
	
});

$('.sign-in').submit(function(e){
	
	var submit ='true';
	
	$('.sign-in input').css( 'border', '' );
	
	$('.sign-in input').each(function(){
		
		if ( $(this).val()=='' ){
			$(this).css( 'border', '1px dashed red' );
			submit ='false';
		}

	});

	if ( !( submit =='true' ) ){
		e.preventDefault();
	}
	
});

$('.sign-in-btn').click(function(){
	$('.sign-in').submit();
});

$('.sign-out-btn').click(function(){
	$('.sign-out-form').submit();
});