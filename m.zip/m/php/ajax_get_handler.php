<?php
require 'get.php';
#check user
session_start();

if ( isset($_SESSION['name']) && isset($_SESSION['password']) ){
	
	$name =$_SESSION['name'];
	$my_password =$_SESSION['password'];
	
	if ( !( $response =check_user( $name, $my_password ) ) ){
		$response['error']= '100000';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){

		unset($_SESSION['name']);
		unset($_SESSION['password']);
		$response['error'] ='10100';
		$response['sign-out'] ='true';
		die(json_encode($response));

	}
	
	$data =$response['data'];
	$row = $data ->fetch_assoc();
	$user = $row['c_ID'];

	
	$authnication_user_branch=htmlentities($row['c_Branch']);
	
	$authnication_user_view_account=htmlentities($row['c_ViewAccount']);
	$authnication_user_insert_account=htmlentities($row['c_InsertAccount']);
	$authnication_user_update_account=htmlentities($row['c_UpdateAccount']);
	$authnication_user_delete_account=htmlentities($row['c_DeleteAccount']);
	$authnication_user_export_accounts=htmlentities($row['c_ExportAccounts']);
	
	$authnication_user_view_stock=htmlentities($row['c_ViewStock']);
	$authnication_user_insert_stock=htmlentities($row['c_InsertStock']);
	$authnication_user_update_stock=htmlentities($row['c_UpdateStock']);
	$authnication_user_delete_stock=htmlentities($row['c_DeleteStock']);
	$authnication_user_cost=htmlentities($row['c_Cost']);
	$authnication_user_all_items=htmlentities($row['c_AllItems']);
	$authnication_user_export_stock=htmlentities($row['c_ExportStock']);
	
	$authnication_user_view_sale=htmlentities($row['c_ViewSale']);
	$authnication_user_insert_sale=htmlentities($row['c_InsertSale']);
	$authnication_user_update_sale=htmlentities($row['c_UpdateSale']);
	$authnication_user_delete_sale=htmlentities($row['c_DeleteSale']);
	
	$authnication_user_view_r_sale=htmlentities($row['c_ViewRSale']);
	$authnication_user_insert_r_sale=htmlentities($row['c_InsertRSale']);
	$authnication_user_update_r_sale=htmlentities($row['c_UpdateRSale']);
	$authnication_user_delete_r_sale=htmlentities($row['c_DeleteRSale']);
	
	$authnication_user_view_purchase=htmlentities($row['c_ViewPurchase']);
	$authnication_user_insert_purchase=htmlentities($row['c_InsertPurchase']);
	$authnication_user_update_purchase=htmlentities($row['c_UpdatePurchase']);
	$authnication_user_delete_purchase=htmlentities($row['c_DeletePurchase']);
	
	$authnication_user_view_r_purchase=htmlentities($row['c_ViewRPurchase']);
	$authnication_user_insert_r_purchase=htmlentities($row['c_InsertRPurchase']);
	$authnication_user_update_r_purchase=htmlentities($row['c_UpdateRPurchase']);
	$authnication_user_delete_r_purchase=htmlentities($row['c_DeleteRPurchase']);
	
	$authnication_user_view_income=htmlentities($row['c_ViewIncome']);
	$authnication_user_insert_income=htmlentities($row['c_InsertIncome']);
	$authnication_user_update_income=htmlentities($row['c_UpdateIncome']);
	$authnication_user_delete_income=htmlentities($row['c_DeleteIncome']);
	
	$authnication_user_view_outcome=htmlentities($row['c_ViewOutcome']);
	$authnication_user_insert_outcome=htmlentities($row['c_InsertOutcome']);
	$authnication_user_update_outcome=htmlentities($row['c_UpdateOutcome']);
	$authnication_user_delete_outcome=htmlentities($row['c_DeleteOutcome']);
	
	$authnication_user_view_receipt=htmlentities($row['c_ViewReceipt']);
	$authnication_user_insert_receipt=htmlentities($row['c_InsertReceipt']);
	$authnication_user_update_receipt=htmlentities($row['c_UpdateReceipt']);
	$authnication_user_delete_receipt=htmlentities($row['c_DeleteReceipt']);
	
	$authnication_user_view_payment=htmlentities($row['c_ViewPayment']);
	$authnication_user_insert_payment=htmlentities($row['c_InsertPayment']);
	$authnication_user_update_payment=htmlentities($row['c_UpdatePayment']);
	$authnication_user_delete_payment=htmlentities($row['c_DeletePayment']);
	
	$authnication_user_all_branches=htmlentities($row['c_AllBranches']);
	$authnication_user_journal=htmlentities($row['c_Journal']);
	$authnication_user_export_journal=htmlentities($row['c_ExportJournal']);
	$authnication_user_loss_profit=htmlentities($row['c_LossProfit']);
	$authnication_user_users=htmlentities($row['c_Users']);
	$authnication_user_backup=htmlentities($row['c_BackUp']);
	$authnication_user_restore=htmlentities($row['c_Restore']);

	
}else{
	$response['error'] ='10101';
	$response['sign-out'] ='true';
	die(json_encode($response));
}
#action type

if ( !( isset($_POST['action']) ) ){
	$response['error'] ='1000';
	die(json_encode($response));
}
$action =$_POST['action'];

#t_accounts
if ( $action == 'select_accounts' ){

	if ( !( $authnication_user_view_account == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}

	if ( !( isset($_POST['page_search_account']) ) ){
		$page_search_account ='';
	}else{
		$page_search_account =$_POST['page_search_account'];
	}
	
	if ( !( isset($_POST['page_search_branch']) ) ){
		$page_search_branch ='';
	}else{
		$page_search_branch =$_POST['page_search_branch'];
	}
	
	if ( !( isset($_POST['page_search_type']) ) ){
		$page_search_type ='';
	}else{
		$page_search_type =$_POST['page_search_type'];
	}
	
	if ( !( isset($_POST['page_search_order']) ) ){
		$page_search_order ='';
	}else{
		$page_search_order =$_POST['page_search_order'];
	}

	if ( !( isset($_POST['page_number']) ) ){
		$page_number =0;
	}else{
		$page_number =$_POST['page_number'];
		if ( !( $page_number>=0 ) ){
			$page_number =0;
		}
	}
	
	$page_limit =25;
	$off_set =$page_limit * $page_number;
	$i =0;
	
	if ( !( $authnication_user_all_branches == 'true' ) ){
		if ( !($response =select_user_accounts( $page_search_branch, $page_search_account, $page_search_type, $page_search_order, $authnication_user_branch )) ){
			$response ='11001';
			die(json_encode($response));
		}
	}else{
		if ( !($response =select_accounts( $page_search_branch, $page_search_account, $page_search_type, $page_search_order )) ){
			$response ='11001';
			die(json_encode($response));
		}		
	}
	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	$accounts ='';
	$data =$response['data'];
	for ( $i=0 ; $row =$data ->fetch_assoc() ; $i++ ){

		if ( $i>$off_set-1 && $i<($page_limit+$off_set) ){

			$account_id =htmlentities($row['c_ID']);
			$branch =htmlentities($row['c_Branch']);
			$account_name =htmlentities($row['c_Name']);
			$account_type =htmlentities($row['c_Type']);
			$account_debit =htmlentities($row['c_Debit']);
			$account_credit =htmlentities($row['c_Credit']);
			$opening_balance =htmlentities($row['c_OpeningBalance']);
			$account_balance =( $opening_balance )+($account_debit-$account_credit);
			
			if ( $account_debit >0 || $account_credit >0 ){
				$account_activity ='true';
			}
			else{
				$account_activity ='false';
			}
			
			$account_color ='';
			if ( $account_balance>0 ){
				$account_color = 'green';
			}
			if ( $account_balance<0 ){
				$account_color = 'red';
			}
			
			$accounts .="
				<div class='item $account_color' data-id='$account_id' data-name='$account_name' data-activity ='$account_activity' data-type ='$account_type'>		
					<span class='bolder'>$account_name</span>
					<span class='light'>$account_type</span>
					<span class='light'>$branch</span>
					<section class='level2'>
					<span class='light'>Credit: $account_credit</span>
					<span class='light'>Debit: $account_debit</span>
					</section>
					<span class='bold'>balance: $account_balance</span>
					<span class='more more-account-btn'><i class='fas fa-ellipsis-h'></i> More</span>		
				</div>
			";
		
		}
	
	}
	
	if ( mysqli_num_rows($data) > ($page_limit+$off_set) ){
		$accounts .="<i class='fas fa-chevron-down load-btn' onclick='accounts_body();' > Load More</i>";
	}
	
	
	$response['data'] =$accounts;
	$response['error'] ='0';
	die(json_encode($response));
	
}
if ( $action == 'refresh_account' ){
	
	if ( !( $authnication_user_view_account == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !( isset($_POST['id']) ) ){
		$response['error'] ='11200';
		die(json_encode($response));
	}
	
	$id =$_POST['id'];	
	
	if ( !($response =select_account( $id )) ){
		$response['error'] ='11001';
		die(json_encode($response));
	}
	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row = $data ->fetch_assoc();

	$account_id =htmlentities($row['c_ID']);
	$branch =htmlentities($row['c_Branch']);
	$account_name =htmlentities($row['c_Name']);
	$account_type =htmlentities($row['c_Type']);
	$account_debit =htmlentities($row['c_Debit']);
	$account_credit =htmlentities($row['c_Credit']);
	$opening_balance =htmlentities($row['c_OpeningBalance']);
	$account_balance =( $opening_balance )+($account_debit-$account_credit);

	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if ( $account_debit >0 || $account_credit >0 ){
		$account_activity ='true';
	}
	else{
		$account_activity ='false';
	}
			
	$account_color ='';
	if ( $account_balance>0 ){
		$account_color = 'green';
	}
	if ( $account_balance<0 ){
		$account_color = 'red';
	}
			
	$account ="
		<div class='item $account_color' data-id='$account_id' data-name='$account_name' data-activity ='$account_activity' data-type ='$account_type'>		
				<span class='bolder'>$account_name</span>
				<span class='light'>$account_type</span>
				<span class='light'>$branch</span>
				<section class='level2'>
				<span class='light'>Credit: $account_credit</span>
				<span class='light'>Debit: $account_debit</span>
				</section>
				<span class='bold'>balance: $account_balance</span>
				<span class='more more-account-btn'><i class='fas fa-ellipsis-h'></i> More</span>		
				</div>
	";
	
	$response['data'] =$account;
	$response['error'] ='0';
	die(json_encode($response));
	
}
if ( $action == 'insert_account_modal' ){
	
	if ( !( $authnication_user_insert_account == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !( $authnication_user_all_branches == 'true' ) ){
		$branches = "<option value='$authnication_user_branch'>$authnication_user_branch</option>";
	}else{

		if ( !($response =select_branches()) ){
			$response ='16000';
			die(json_encode($response));
		}
		
		if ( !( $response['error'] ==0 ) ){
			die(json_encode($response));
		}
		
		$branches ='';
		$data =$response['data'];
		
		while($row= $data->fetch_assoc()){
			$branch = $row['c_Branch'];
			$branches .="<option value='$branch'>$branch</option>";
		}
		
	}
	
	
	$response['error'] ='0';
	$response['data'] =
			'<div class="insert-account-modal modal">

				
				<div class="header">
					
					<div class="logo">
					<img src="logo.png" >
					</div>
					
					<i onclick="insert_account();" class="fas fa-check insert-btn"></i>
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
					
				</div>
				

				<form onsubmit="event.preventDefault();remove_focus();insert_account();" class="input-container">
				<input type="submit" style="display:none;">
				
					<h5>
					New Account: Account
					</h5>
				
					<section>
					<h6>Branch:</h6>
					<select id="account_branch">
					'.$branches.'
					</select>
					</section>
					
					<section class="required">
					<h6>Name:</h6>
					<input id="account_name" class="autofocus" type="text" value="">
					</section>
					
					<section>
					<h6>Type:</h6>
					<select id="account_type">
						<option>Customer</option>
						<option>Supplier</option>
						<option>Expense</option>
						<option>Petty Cash</option>
						<option>Bank</option>
						<option>Sale</option>
						<option>Purchase</option>
					</select>
					</section>

					<section>
					<h6>Contact:</h6>
					<input id="account_contact" type="text" value="">
					</section>
					
					<section>
					<h6>Opening Balance:</h6>
					<input id="account_opening_balance" type="number" value="">
					</section>

					<section>
					<h6>Address:</h6>
					<input id="account_address" type="text" value="">
					</section>
					
					<section>
					<h6>Location:</h6>
					<input onclick="show_map(`true`,this.value);" id="account_location" class="location-input" type="text" value="" style="cursor:pointer;" readonly>
					</section>
					
					<section>
					<h6>Memo:</h6>
					<input id="account_memo" type="text" value="">
					</section>

					<i onclick="insert_account();" class="fas fa-check insert-btn"></i>
					<i onclick="cancel_modal();"class="fas fa-times cancel-btn"></i>

				</form>
				

			</div>';
	die(json_encode($response));
	
}
if ( $action == 'update_account_modal' ){
	
	if ( !( $authnication_user_update_account == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !( isset($_POST['id']) ) ){
		$response['error'] ='11200';
		die(json_encode($response));
	}
	
	$id =$_POST['id'];
	
	if ( !( $response =select_account($id) ) ){
		$response['error'] ='11201';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$name=htmlentities($row['c_Name']);
	$branch=htmlentities($row['c_Branch']);
	$type=htmlentities($row['c_Type']);
	$opening_balance=htmlentities($row['c_OpeningBalance']);
	$debit=htmlentities($row['c_Debit']);
	$credit=htmlentities($row['c_Credit']);
	$contact=htmlentities($row['c_Contact']);
	$address=htmlentities($row['c_Address']);
	$location=htmlentities($row['c_Location']);
	$memo=htmlentities($row['c_Memo']);
	$basic=htmlentities($row['c_Basic']);
	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	$allow_name_update='';
	if ($debit!=0 || $credit!=0 || $basic!=null){
		$allow_name_update='readonly';
	}
	
	
	$response['error'] ='0';
	$response['data'] =
			'<div class="update-account-modal modal">

				
				<div class="header">
					
					<div class="logo">
					<img src="logo.png" >
					</div>
					
					<i onclick="update_account();" class="fas fa-check insert-btn"></i>
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
					
				</div>
				

				<form onsubmit="event.preventDefault();remove_focus();update_account();" class="input-container">
				<input type="submit" style="display:none;">
				
					<h5>
					Edit Account: '.$name.'
					</h5>
				
					<input id="account_id" type="hidden" value="'.$id.'">
				
					<section>
					<h6>Branch:</h6>
					<input id="account_branch" type="text" value="'.$branch.'" readonly>
					</section>
					
					<section class="required">
					<h6>Name:</h6>
					<input id="account_name" class="autofocus" type="text" value="'.$name.'" '.$allow_name_update.'>
					</section>
					
					<section>
					<h6>Type:</h6>
					<input type="text" value="'.$type.'" readonly>
					</section>

					<section>
					<h6>Opening Balance:</h6>
					<input id="account_opening_balance" type="number" value="'.$opening_balance.'">
					</section>

					<section>
					<h6>Contact:</h6>
					<input id="account_contact" type="text" value="'.$contact.'">
					</section>
					

					<section>
					<h6>Address:</h6>
					<input id="account_address" type="text" value="'.$address.'">
					</section>
					
					<section>
					<h6>Location:</h6>
					<input onclick="show_map(`true`,this.value);" id="account_location" class="location-input" type="text" value="'.$location.'" style="cursor:pointer;" readonly>
					</section>
					
					<section>
					<h6>Memo:</h6>
					<input id="account_memo" type="text" value="'.$memo.'">
					</section>

					<i onclick="update_account();" class="fas fa-check insert-btn"></i>
					<i onclick="cancel_modal();"class="fas fa-times cancel-btn"></i>

				</form>
				

			</div>';
	die(json_encode($response));
	
}
if ( $action == 'more_account_modal' ){
	
	if ( !( $authnication_user_view_account == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !( isset($_POST['id']) ) ){
		$response['error'] ='11200';
		die(json_encode($response));
	}
	
	$id =$_POST['id'];
	
	if ( !( $response =select_account($id) ) ){
		$response['error'] ='11201';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$branch=htmlentities($row['c_Branch']);
	$name=htmlentities($row['c_Name']);
	$debit=htmlentities($row['c_Debit']);
	$credit=htmlentities($row['c_Credit']);
	$type=htmlentities($row['c_Type']);
	$opening_balance=htmlentities($row['c_OpeningBalance']);
	$balance = ( $opening_balance ) + ( $debit -$credit );
	$contact=htmlentities($row['c_Contact']);
	$address=htmlentities($row['c_Address']);
	$location=htmlentities($row['c_Location']);
	$memo=htmlentities($row['c_Memo']);
	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ( !( isset($_POST['page_search']) ) ){
		$page_search ='';
	}else{
		$page_search =$_POST['page_search'];
	}

	if ( !( isset($_POST['page_number']) ) ){
		$page_number =0;
	}else{
		$page_number =$_POST['page_number'];
		if ( !( $page_number>=0 ) ){
			$page_number =0;
		}
	}
	
	
	$page_limit =500;
	$off_set =$page_limit * $page_number;
	$i =0;
	
	if ( !($response =select_account_journal( $id )) ){
		$response ='11202';
		die(json_encode($response));
	}
	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	$account_journal ='';
	$data =$response['data'];
	for ( $i=0 ; $row =$data ->fetch_assoc() ; $i++ ){

		if ( $i>$off_set-1 && $i<($page_limit+$off_set) ){

			$journal_type =htmlentities($row['c_Type']);
			$journal_parent_id =htmlentities($row['c_ParentID']);
			$journal_type =htmlentities($row['c_Type']);
			$journal_debit =htmlentities($row['c_Debit']);
			$journal_credit =htmlentities($row['c_Credit']);
			$journal_date =htmlentities($row['c_Date']);

			
			$this_record="
				<tr>
					<input type='hidden' value='$journal_parent_id' class='parent-id' >
					<input type='hidden' value='$journal_type' class='type' >
					<td>$journal_parent_id</td>
					<td>$journal_type</td>
					<td>$journal_debit</td>
					<td>$journal_credit</td>
					<td>$journal_date</td>
				</tr>
			";
			
			$allow='true';
			if ($journal_type=='Sale'){
				if ( !($authnication_user_view_sale=='true') ){
					$allow ='false';
				}
			}			
			if ($journal_type=='R Sale'){
				if ( !($authnication_user_view_r_sale=='true') ){
						$allow ='false';
				}
			}
			if ($journal_type=='Purchase'){
				if ( !($authnication_user_view_purchase=='true') ){
					$allow ='false';
				}
			}			
			if ($journal_type=='R Purchase'){
					if ( !($authnication_user_view_r_purchase=='true') ){
					$allow ='false';
				}
			}			
			if ($journal_type=='Income'){
					if ( !($authnication_user_view_income=='true') ){
					$allow ='false';
				}
			}		
			if ($journal_type=='Outcome'){
				if ( !($authnication_user_view_outcome=='true') ){
					$allow ='false';
				}
			}
			if ($journal_type=='Receipt'){
				if ( !($authnication_user_view_receipt=='true') ){
					$allow ='false';
				}
			}		
			if ($journal_type=='Payment'){
				if ( !($authnication_user_view_payment=='true') ){
					$allow ='false';
				}
			}
			
			if ($allow!='true'){
				$this_record='';
				$i--;
			}
			
			$account_journal .=$this_record;
		
		}
	
	}
	
	$page_limit =500;
	$off_set =$page_limit * $page_number;
	$i =0;
	
	if ( !($response =select_account_items( $id )) ){
		$response ='11202';
		die(json_encode($response));
	}
	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	$account_items ='';
	$data =$response['data'];
	for ( $i=0 ; $row =$data ->fetch_assoc() ; $i++ ){

		if ( $i>$off_set-1 && $i<($page_limit+$off_set) ){

			$item_invoice_id =htmlentities($row['c_InvoiceID']);
			$item_invoice_type =htmlentities($row['c_InvoiceType']);
			$item_stock_name =htmlentities($row['c_StockName']);
			$item_qty =htmlentities($row['c_Qty']);
			$item_price =htmlentities($row['c_Price']);
			$item_discount =htmlentities($row['c_Discount']);
			$item_invoice_date =htmlentities($row['c_InvoiceDate']);
			
			$item_ammount = ($item_price*$item_qty)-( ($item_price*$item_qty)*($item_discount/100) );
			
			$account_item="
				<tr>
					<input type='hidden' value='$item_invoice_id' class='invoice-id' >
					<td>$item_invoice_type</td>
					<td>$item_stock_name</td>
					<td>$item_qty</td>
					<td>$item_ammount</td>
					<td>$item_invoice_date</td>
				</tr>
			";
			
			$allow='true';
			if ($item_invoice_type=='Sale'){
				if ( !($authnication_user_view_sale=='true') ){
					$allow ='false';
				}
			}			
			if ($item_invoice_type=='R Sale'){
				if ( !($authnication_user_view_r_sale=='true') ){
					$allow ='false';
				}
			}
			if ($item_invoice_type=='Purchase'){
				if ( !($authnication_user_view_purchase=='true') ){
					$allow ='false';
				}
			}			
			if ($item_invoice_type=='R Purchase'){
					if ( !($authnication_user_view_r_purchase=='true') ){
					$allow ='false';
				}
			}	
			if ($allow!='true'){
				$account_item= '';
				$i--;
			}
			
			$account_items .=$account_item;
		
		}
	
	}

	
	
	
	$response['error'] ='0';
	$response['data'] =
			'<form class="more-account-modal modal more-modal" onsubmit="event.preventDefault();remove_focus();cancel_modal();">
			<input type="submit" style="display:none;">
				
				<div class="header">
					
					<div class="logo">
					<img src="logo.png" >
					</div>
					
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
					
				</div>
				

				<div class="input-container">
				
					<h5>
					Account: '.$name.'
					</h5>
					
					<div class="left-div">
					
						<section>
						<h6>Branch:</h6>
						<input type="text" value="'.$branch.'" readonly>
						</section>
						
						<section class="required">
						<h6>Name:</h6>
						<input type="text" class="autofocus" value="'.$name.'" readonly>
						</section>
						
						<section>
						<h6>Type:</h6>
						<input type="text" value="'.$type.'" readonly>
						</section>
						
						<section>
						<h6>Opening Balance:</h6>
						<input id="account_opening_balance" type="number" value="'.$opening_balance.'" readonly>
						</section>
						
						<section>
						<h6>Debit:</h6>
						<input type="text" value="'.$debit.'" readonly>
						</section>
						
						<section>
						<h6>Credit:</h6>
						<input type="text" value="'.$credit.'" readonly>
						</section>
						
						<section>
						<h6>Balance:</h6>
						<input type="text" value="'.$balance.'" readonly>
						</section>

						<section>
						<h6>Contact:</h6>
						<input type="text" value="'.$contact.'" readonly>
						</section>
						

						<section>
						<h6>Address:</h6>
						<input type="text" value="'.$address.'" readonly>
						</section>
						
						<section>
						<h6>Location:</h6>
						<input onclick="show_map(`false`,this.value);" type="text" value="'.$location.'"  readonly>
						</section>
						
						<section>
						<h6>Memo:</h6>
						<input type="text" value="'.$memo.'" readonly>
						</section>
						
						
					</div>
					
					<div class="activity-table-container activity-table-container1">
						
							<table class="activity-table account-activity">
								<tr>
									<td>ID</td>
									<td>Type</td>
									<td>Debit</td>
									<td>Credit</td>
									<td>Date</td>
								</tr>
								'.$account_journal.'
							</table>
						
					</div>
					
					<div class="activity-table-container activity-table-container2">
						
							<table class="activity-table account-items">
								<tr>
									<td>Type</td>
									<td>Name</td>
									<td>Qty.</td>
									<td>Ammount</td>
									<td>Date</td>
								</tr>
								'.$account_items.'
							</table>
						
					</div>
					
					<i onclick="cancel_modal();"class="fas fa-times cancel-btn"></i>
					

				</div>
				

			</form>';
	die(json_encode($response));
	
}
if ( $action == 'select_payment_accounts' ){
	
	if ( !($authnication_user_insert_sale=='true') && !($authnication_user_insert_r_sale=='true') && !($authnication_user_insert_purchase=='true') && !($authnication_user_insert_r_purchase=='true') && !($authnication_user_insert_receipt=='true') && !($authnication_user_insert_payment=='true') ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !( isset($_POST['page_search']) ) ){
		$page_search ='';
	}else{
		$page_search =$_POST['page_search'];
	}

	if ( !( isset($_POST['page_number']) ) ){
		$page_number =0;
	}else{
		$page_number =$_POST['page_number'];
		if ( !( $page_number>=0 ) ){
			$page_number =0;
		}
	}

	if ( !( isset($_POST['account_id']) ) ){
		$account_id =0;
	}else{
		$account_id =$_POST['account_id'];
	}
	
	if ( !( $response =select_account($account_id) ) ){
		$response['error']='13101';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$account_name =htmlentities($row['c_Name']);
	$branch =htmlentities($row['c_Branch']);
	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	$page_limit =25;
	$off_set =$page_limit * $page_number;
	$i =0;
	
	if ( !($response =select_user_accounts( '', $page_search, '', '', $branch )) ){
		$response ='11300';
		die(json_encode($response));
	}

	
	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	$accounts ='';
	$data =$response['data'];
	for ( $i=0 ; $row =$data ->fetch_assoc() ; $i++ ){

		if ( $i>$off_set-1 && $i<($page_limit+$off_set) ){

			$id =htmlentities($row['c_ID']);
			$name =htmlentities($row['c_Name']);

			$accounts .="
				
				<tr data-id='$id' data-name='$name'>
					<td>$name</td>
				</tr>
				
			";
		
		}
	
	}	
	
	$response['data'] =$accounts;
	$response['error'] ='0';
	die(json_encode($response));	
}
#t_payments
if ( $action == 'select_payments' ){

	if ( $authnication_user_view_receipt!='true' && $authnication_user_view_payment!='true'  ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}

	if ( !( isset($_POST['page_search_branch']) ) ){
		$page_search_branch ='';
	}else{
		$page_search_branch =$_POST['page_search_branch'];
	}
	
	if ( !( isset($_POST['page_search_id']) ) ){
		$page_search_id ='';
	}else{
		$page_search_id =$_POST['page_search_id'];
	}

	if ( !( isset($_POST['page_search_account']) ) ){
		$page_search_account ='';
	}else{
		$page_search_account =$_POST['page_search_account'];
	}
	
	if ( !( isset($_POST['page_search_type']) ) ){
		$page_search_type ='';
	}else{
		$page_search_type =$_POST['page_search_type'];
	}
	
	if ( !( isset($_POST['page_search_order']) ) ){
		$page_search_order ='';
	}else{
		$page_search_order =$_POST['page_search_order'];
	}

	if ( !( isset($_POST['page_number']) ) ){
		$page_number =0;
	}else{
		$page_number =$_POST['page_number'];
		if ( !( $page_number>=0 ) ){
			$page_number =0;
		}
	}
	
	$page_limit =25;
	$off_set =$page_limit * $page_number;
	$i =0;

	if ( !($authnication_user_all_branches=='true') ){
		if ( !($response =select_user_payments( $page_search_branch, $page_search_id, $page_search_account, $page_search_type, $page_search_order, $authnication_user_branch )) ){
			$response ='12001';
			die(json_encode($response));
		}
	}else{
		if ( !($response =select_payments( $page_search_branch, $page_search_id, $page_search_account, $page_search_type, $page_search_order )) ){
			$response ='12001';
			die(json_encode($response));
		}
	}

	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	$payments ='';
	$data =$response['data'];
	for ( $i=0 ; $row =$data ->fetch_assoc() ; $i++ ){
		

		if ( $i>$off_set-1 && $i<($page_limit+$off_set) ){

			$id =htmlentities($row['c_ID']);
			$branch =htmlentities($row['c_Branch']);
			$account_name =htmlentities($row['c_AccountName']);
			$ammount =htmlentities($row['c_Ammount']);
			$date =htmlentities($row['c_Date']);
			$type =htmlentities($row['c_Type']);
			
			$color ='';
			if ( $type =='Receipt' ){
				$color = 'green';
			}
			if ( $type =='Payment' ){
				$color = 'red';
			}

			$payment="
				<div class='item $color' data-id='$id' data-account-name='$account_name' data-type='$type'>		
					<span class='bolder'>$account_name #$id</span>
					<span class='light'>$branch</span>
					<section class='level2'>
					<span class='light'>$type</span>
					<span class='light'>$date</span>
					</section>
					<span class='bold'>$ammount</span>
					<span class='more more-payment-btn'><i class='fas fa-ellipsis-h'></i> More</span>		
				</div>
			";

			$allow ='true';
			if ($type=='Receipt'){
				if ( !($authnication_user_view_receipt=='true') ){
					$allow ='false';
				}
			}
			
			if ($type=='Payment'){
				if ( !($authnication_user_view_payment=='true') ){
					$allow ='false';
				}
			}
			
			if ($allow!='true'){
				$payment= '';
				$i--;
			}
			
			$payments .=$payment;
		
		}
	
	}
	
	if ( mysqli_num_rows($data) > ($page_limit+$off_set) ){
		$payments .="<i class='fas fa-chevron-down load-btn' onclick='payments_body();' > Load More</i>";
	}
	
	
	$response['data'] =$payments;
	$response['error'] ='0';
	die(json_encode($response));
	
}
if ( $action == 'refresh_payment' ){

	if ( $authnication_user_view_receipt!='true' && $authnication_user_view_payment!='true'  ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}

	if ( !( isset($_POST['id']) ) ){
		$response['error']='12200';
		die(json_encode($response));
	}

	$id =$_POST['id'];	

	if ( !($response =select_payment( $id )) ){
		$response['error'] ='12201';
		die(json_encode($response));
	}

	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row = $data ->fetch_assoc();

	$id =htmlentities($row['c_ID']);
	$branch =htmlentities($row['c_Branch']);
	$account_name =htmlentities($row['c_AccountName']);
	$type =htmlentities($row['c_Type']);
	$ammount =htmlentities($row['c_Ammount']);
	$date =htmlentities($row['c_Date']);

	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	$color ='';
	if ( $type =='Receipt' ){
		$color = 'green';
	}
	if ( $type =='Payment' ){
		$color = 'red';
	}

	
	$payment ="
		<div class='item $color' data-id='$id' data-account-name='$account_name' data-type='$type'>		
			<span class='bolder'>$account_name #$id</span>
			<span class='light'>$branch</span>
			<section class='level2'>
			<span class='light'>$type</span>
			<span class='light'>$date</span>
			</section>
			<span class='bold'>$ammount</span>
			<span class='more more-payment-btn'><i class='fas fa-ellipsis-h'></i> More</span>	
		</div>
	";

	if ($type=='Receipt'){
		if ( !($authnication_user_view_receipt=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if ($type=='Payment'){
		if ( !($authnication_user_view_payment=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	$response['data'] =$payment;
	$response['error'] ='0';
	die(json_encode($response));
	
}
if ( $action == 'insert_payment_modal' ){
	
	if ( !( isset($_POST['account_id']) && isset($_POST['type']) ) ){
		$response['error']='12100';
		die(json_encode($response));
	}
	
	$account_id =$_POST['account_id'];
	$type =$_POST['type'];
	
	if ( !( $type =='Payment' || $type =='Receipt' ) ){
		$type ='Payment';
	}
	
	if ($type=='Receipt'){
		if ( !($authnication_user_insert_receipt=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if ($type=='Payment'){
		if ( !($authnication_user_insert_payment=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	$basic_account = 'petty_cash';
	

	if ( !( $response =select_account($account_id) ) ){
		$response['error']='12102';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$account_name =htmlentities($row['c_Name']);
	$branch =htmlentities($row['c_Branch']);

	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if ( !( $response =select_basic_account($basic_account, $branch) ) ){
		$response['error']='12101';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$second_account_id =htmlentities($row['c_ID']);


	$from_label = 'From';
	if ( $type == 'Receipt' ){
		$from_label = 'To';
	}
	
	$response['error'] ='0';
	$response['data']=
			'<form class="insert-payment-modal modal" onsubmit="event.preventDefault();remove_focus();insert_payment();">
			<input type="submit" style="display:none;">
				
				<div class="header">
					
					<div class="logo">
					<img src="logo.png" >
					</div>
					
					<i onclick="insert_payment();" class="fas fa-check insert-btn"></i>
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
					
				</div>
		

		
				<div class="input-container">
				
					<input id="payment_type" type="hidden" value="'.$type.'" >
				
					<h5>
					New '.$type.'
					</h5>
					
					<section>
					<h6>Branch:</h6>
					<input type="text" value="'.$branch.'" readonly>
					</section>
					
					<section>
					<input id="payment_account_id" class="account" type="hidden" value="'.$account_id.'" >
					<h6>Account:</h6>
					<input id="payment_account" class="account-input" type="text" value="'.$account_name.'" readonly  style="cursor:pointer;" onclick="show_account_modal(this);">
					</section>
					
					<section>
					<input id="payment_second_account" class="account" type="hidden" value="'.$second_account_id.'" >
					<h6>'.$from_label.':</h6>
					<input id="payment_from" class="account-input" type="text" value="Petty Cash" readonly  style="cursor:pointer;" onclick="show_account_modal(this);">
					</section>
					
					<section class="required">
					<h6>Amount:</h6>
					<input id="payment_ammount" class="autofocus" type="number" value="">
					</section>
					
					<section>
					<h6>Memo:</h6>
					<input id="payment_memo" type="text" value="">
					</section>


					<i onclick="insert_payment();" class="fas fa-check insert-btn"></i>
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>

				</div>
				
				<div class="account-id-modal">

				
					<input type="hidden" class="account-page-number" value="0">
					<input type="hidden" class="account-page-search" value="">
				
					<div class="search">
					<input type="submit" style="display:none;">
						<input type="text" placeholder="Name" class="account-page-search-input">
						<i class="fas fa-search" onclick="
						loader_show();
						document.getElementsByClassName(`account-page-search`)[0].value =document.getElementsByClassName(`account-page-search-input`)[0].value;
						document.getElementsByClassName(`account-page-number`)[0].value =0;
						document.getElementsByClassName(`account-body`)[0].innerHTML =``;
						account_body();
						"></i>
					</div>

					<div class="account-item-container">
						<table class="account-body"></table>
					</div>
					
					<div class="action">
						<i  onclick="save_account_modal();"class="fas fa-plus save-account"></i>
						<i  onclick="cancel_account_modal();" class="fas fa-times cancel-account"></i>
					</div>
					
				</form>

			</form>';
	die(json_encode($response));
	
}
if ( $action == 'update_payment_modal' ){

	if ( !( isset($_POST['id']) ) ){
		$response['error']='12200';
		die(json_encode($response));
	}
	
	$id =$_POST['id'];
	
	
	if ( !($response =select_payment( $id )) ){
		$response['error'] ='12201';
		die(json_encode($response));
	}
		
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$branch =htmlentities($row['c_Branch']);
	$account_name =htmlentities($row['c_AccountName']);
	$second_account_name =htmlentities($row['c_SecondAccountName']);
	$type =htmlentities($row['c_Type']);
	$ammount =htmlentities($row['c_Ammount']);
	$memo =htmlentities($row['c_Memo']);
	
	if ($type=='Receipt'){
		if ( !($authnication_user_update_receipt=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if ($type=='Payment'){
		if ( !($authnication_user_update_payment=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	$from_label = 'From';
	if ( $type == 'Receipt' ){
		$from_label = 'To';
	}

	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	$response['error'] ='0';
	$response['data']=
			'<form class="update-payment-modal modal" onsubmit="event.preventDefault();remove_focus();update_payment();">
			<input type="submit" style="display:none;">
				
				<div class="header">
					
					<div class="logo">
					<img src="logo.png" >
					</div>
					
					<i onclick="update_payment();" class="fas fa-check insert-btn"></i>
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
					
				</div>
		

		
				<div class="input-container">
				
					<input id="payment_id" type="hidden" value="'.$id.'" >
				
					<h5>
					Edit '.$type.':
					</h5>
				
					<section>
					<h6>Branch:</h6>
					<input type="text" value="'.$branch.'" readonly>
					</section>
					
					<section>
					<h6>ID:</h6>
					<input type="text" value="'.$id.'" readonly>
					</section>
					
					<section>
					<h6>Account:</h6>
					<input id="" type="text" value="'.$account_name.'" readonly >
					</section>
					
					<section>
					<h6>'.$from_label.':</h6>
					<input id="payment_from" type="text" value="'.$second_account_name.'" readonly >
					</section>
				
					<section class="required">
					<h6>Amount:</h6>
					<input id="payment_ammount" class="autofocus" type="number" value="'.$ammount.'">
					</section>

					<section>
					<h6>Memo:</h6>
					<input id="payment_memo" type="text" value="'.$memo.'">
					</section>


					<i onclick="update_payment();" class="fas fa-check insert-btn"></i>
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>

				</div>

			</form>';
	die(json_encode($response));
	
}
if ( $action == 'more_payment_modal' ){

	if ( !( isset($_POST['id']) ) ){
		$response['error']='12200';
		die(json_encode($response));
	}
	
	$id =$_POST['id'];
	
	
	if ( !($response =select_payment( $id )) ){
		$response['error'] ='12201';
		die(json_encode($response));
	}
		
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}

	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$branch =htmlentities($row['c_Branch']);
	$account_name =htmlentities($row['c_AccountName']);
	$second_account_name =htmlentities($row['c_SecondAccountName']);
	$type =htmlentities($row['c_Type']);
	$ammount =htmlentities($row['c_Ammount']);
	$memo =htmlentities($row['c_Memo']);
	
	if ($type=='Receipt'){
		if ( !($authnication_user_view_receipt=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if ($type=='Payment'){
		if ( !($authnication_user_view_payment=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	$from_label = 'From';
	if ( $type == 'Receipt' ){
		$from_label = 'To';
	}
	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	$response['error'] ='0';
	$response['data']=
			'<form class="more-payment-modal modal" onsubmit="event.preventDefault();remove_focus();cancel_modal();">
			<input type="submit" style="display:none;">
				
				<div class="header">
					
					<div class="logo">
					<img src="logo.png" >
					</div>
					
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
					<a href="reports/invoice.php?payment='.$id.'" target="_blank" class="fas fa-print print-btn"></a>
					
				</div>
		

		
				<div class="input-container">
				
				
					<h5>
					'.$type.':
					</h5>
					
					<section>
					<h6>Branch:</h6>
					<input type="text" value="'.$branch.'" readonly>
					</section>
					
					<section>
					<h6>ID:</h6>
					<input type="text" value="'.$id.'" readonly>
					</section>
					
					<section>
					<h6>Account:</h6>
					<input type="text" value="'.$account_name.'" readonly >
					</section>
					
					<section>
					<h6>'.$from_label.':</h6>
					<input type="text" value="'.$second_account_name.'" readonly >
					</section>
				
					<section class="required">
					<h6>Amount:</h6>
					<input type="number" class="autofocus" value="'.$ammount.'" readonly>
					</section>

					<section>
					<h6>Memo:</h6>
					<input type="text" value="'.$memo.'" readonly>
					</section>
					

					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
					<a href="reports/invoice.php?payment='.$id.'" target="_blank" class="fas fa-print print-btn"></a>

				</div>

			</form>';
	die(json_encode($response));
	
}
#t_invoices
if ( $action == 'select_invoices' ){

	if ( $authnication_user_view_sale!='true' && $authnication_user_view_r_sale!='true' && $authnication_user_view_purchase!='true' && $authnication_user_view_r_purchase!='true' &&$authnication_user_view_income!='true' &&$authnication_user_view_outcome!='true' ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}

	if ( !( isset($_POST['page_search_branch']) ) ){
		$page_search_branch ='';
	}else{
		$page_search_branch =$_POST['page_search_branch'];
	}

	if ( !( isset($_POST['page_search_id']) ) ){
		$page_search_id ='';
	}else{
		$page_search_id =$_POST['page_search_id'];
	}

	if ( !( isset($_POST['page_search_account']) ) ){
		$page_search_account ='';
	}else{
		$page_search_account =$_POST['page_search_account'];
	}
	
	if ( !( isset($_POST['page_search_type']) ) ){
		$page_search_type ='';
	}else{
		$page_search_type =$_POST['page_search_type'];
	}
	
	if ( !( isset($_POST['page_search_order']) ) ){
		$page_search_order ='';
	}else{
		$page_search_order =$_POST['page_search_order'];
	}

	if ( !( isset($_POST['page_number']) ) ){
		$page_number =0;
	}else{
		$page_number =$_POST['page_number'];
		if ( !( $page_number>=0 ) ){
			$page_number =0;
		}
	}
	
	$page_limit =25;
	$off_set =$page_limit * $page_number;
	$i =0;
	
	if ( !($authnication_user_all_branches=='true') ){
		if ( !($response =select_user_invoices( $page_search_branch, $page_search_id, $page_search_account, $page_search_type, $page_search_order, $authnication_user_branch )) ){
			$response ='13001';
			die(json_encode($response));
		}
	}else{	
		if ( !($response =select_invoices( $page_search_branch, $page_search_id, $page_search_account, $page_search_type, $page_search_order )) ){
			$response ='13001';
			die(json_encode($response));
		}
	}
	
	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	$invoices ='';
	$data =$response['data'];
	for ( $i=0 ; $row =$data ->fetch_assoc() ; $i++ ){

		if ( $i>$off_set-1 && $i<($page_limit+$off_set) ){

			$id =htmlentities($row['c_ID']);
			$account_name =htmlentities($row['c_AccountName']);
			$branch =htmlentities($row['c_Branch']);
			$type =htmlentities($row['c_Type']);
			$total =htmlentities($row['c_Total']);
			$discount =htmlentities($row['c_Discount']);
			$net =$total-$discount;
			$date =htmlentities($row['c_Date']);

			$color ='';
			if ( $type =='Sale' || $type =='R Sale' || $type =='Income' ){
				$color = 'green';
			}
			if ( $type =='Purchase' || $type =='R Purchase' || $type=='Outcome' ){
				$color = 'red';
			}
			
			$invoice="
				<div class='item $color' data-id='$id' data-account-name='$account_name' data-type='$type'>		
					<span class='bolder'>$account_name #$id</span>
					<span class='light'>$branch</span>
					<section class='level2'>
					<span class='light'>$type</span>
					<span class='light'>$date</span>
					</section>
					<span class='bold'>$net</span>
					<span class='more more-invoice-btn'><i class='fas fa-ellipsis-h'></i> More</span>		
				</div>
			";
			
			$allow ='true';
			if ($type=='Sale'){
				if ( !($authnication_user_view_sale=='true') ){
					$allow ='false';
				}
			}			
			if ($type=='R Sale'){
				if ( !($authnication_user_view_r_sale=='true') ){
					$allow ='false';
				}
			}
			if ($type=='Purchase'){
				if ( !($authnication_user_view_purchase=='true') ){
					$allow ='false';
				}
			}			
			if ($type=='R Purchase'){
				if ( !($authnication_user_view_r_purchase=='true') ){
					$allow ='false';
				}
			}			
			if ($type=='Income'){
				if ( !($authnication_user_view_income=='true') ){
					$allow ='false';
				}
			}		
			if ($type=='Outcome'){
				if ( !($authnication_user_view_outcome=='true') ){
					$allow ='false';
				}
			}
			
			if ($allow!='true'){
				$invoice= '';
				$i--;
			}
			
			$invoices .=$invoice;
		
		}
	
	}
	
	if ( mysqli_num_rows($data) > ($page_limit+$off_set) ){
		$invoices .="<i class='fas fa-chevron-down load-btn' onclick='invoices_body();' > Load More</i>";
	}
	
	
	$response['data'] =$invoices;
	$response['error'] ='0';
	die(json_encode($response));
	
}
if ( $action == 'refresh_invoice' ){

	if ( !( isset($_POST['id']) ) ){
		$response['error']='13200';
		die(json_encode($response));
	}
	
	$id =$_POST['id'];
	
	if ( !($response =select_invoice( $id )) ){
		$response['error'] ='13001';
		die(json_encode($response));
	}
	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row = $data ->fetch_assoc();

	$id =htmlentities($row['c_ID']);
	$branch =htmlentities($row['c_Branch']);
	$account_name =htmlentities($row['c_AccountName']);
	$type =htmlentities($row['c_Type']);
	$total =htmlentities($row['c_Total']);
	$discount =htmlentities($row['c_Discount']);
	$net =$total-$discount;
	$date =htmlentities($row['c_Date']);

	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	$color ='';
	if ( $type =='Sale' || $type =='R Sale' || $type =='Income' ){
		$color = 'green';
	}
	if ( $type =='Purchase' || $type =='R Purchase' || $type =='Outcome' ){
		$color = 'red';
	}
	

	$invoice="
		<div class='item $color' data-id='$id' data-account-name='$account_name' data-type='$type'>		
			<span class='bolder'>$account_name #$id</span>
			<span class='light'>$branch</span>
			<section class='level2'>
			<span class='light'>$type</span>
			<span class='light'>$date</span>
			</section>
			<span class='bold'>$net</span>
			<span class='more more-invoice-btn'><i class='fas fa-ellipsis-h'></i> More</span>		
		</div>
	";
	
	if ($type=='Sale'){
		if ( !($authnication_user_view_sale=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if ($type=='R Sale'){
		if ( !($authnication_user_view_r_sale=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ($type=='Purchase'){
		if ( !($authnication_user_view_purchase=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if ($type=='R Purchase'){
		if ( !($authnication_user_view_r_purchase=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ($type=='Income'){
		if ( !($authnication_user_view_income=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if ($type=='Outcome'){
		if ( !($authnication_user_view_outcome=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	$response['data'] =$invoice;
	$response['error'] ='0';
	die(json_encode($response));
	
}
if ( $action == 'insert_invoice_modal' ){	
	
	if ( !( isset($_POST['account_id']) && isset($_POST['type']) ) ){
		$response['error']='13100';
		die(json_encode($response));
	}
	
	$account_id =$_POST['account_id'];
	$type =$_POST['type'];
	
	if ( $type!='Sale' && $type!='R Sale' && $type!='Purchase' && $type!='R Purchase' ){
		$type='Sale';
	}
	
	if ($type=='Sale'){
		if ( !($authnication_user_insert_sale=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ($type=='R Sale'){
		if ( !($authnication_user_insert_r_sale=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if ($type=='Purchase'){
		if ( !($authnication_user_insert_purchase=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ($type=='R Purchase'){
		if ( !($authnication_user_insert_r_purchase=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ($type=="Sale" || $type=="R Purchase"){
		$payment_label = 'Receipt';
	}else{
		$payment_label = 'Payment';
	}
	
	$basic_account = 'Sale';
	$invoice_from = 'Sale';
	$from_label = 'From';
	if ( $type == 'Purchase' || $type == 'R Purchase' ){
		$basic_account = 'Purchase';
		$invoice_from = 'Purchase';
		$from_label = 'To';
	}


	if ( !( $response =select_account($account_id) ) ){
		$response['error']='13101';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$account_name =htmlentities($row['c_Name']);
	$branch =htmlentities($row['c_Branch']);
	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if ( !( $response =select_basic_account($basic_account, $branch) ) ){
		$response['error']='12101';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$second_account_id =htmlentities($row['c_ID']);
	
	$response['data'] ='
		
			<form class="invoice-modal modal" onsubmit="event.preventDefault();remove_focus();insert_invoice();">
			<input type="submit" style="display:none;">
				
				<div class="header">
					
					<div class="logo">
					<img src="logo.png" >
					</div>
					
					<i onclick="insert_invoice();" class="fas fa-check insert-btn"></i>
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
					<i onclick="show_items();" class="fas fa-cube stock-btn"></i>
					
				</div>
		

				<div class="invoice-container">
	
					<h5>
					New '.$type.':
					</h5>
					
					<div class="invoice-items">

						
		
					</div>
					
					<div class="invoice-action">
	
						<input id="invoice_type" type="hidden" value="'.$type.'" >
					
						<section>
						<h6>Branch:</h6>
						<input type="text" value="'.$branch.'" readonly>
						</section>
						
						<section>
						<input id="invoice_account_id" class="account" type="hidden" value="'.$account_id.'" >
						<h6>Account:</h6>
						<input id="" class="account-input" type="text" value="'.$account_name.'" readonly  style="cursor:pointer;" onclick="show_account_modal(this);">
						</section>
						
						<section>
						<input id="invoice-second-account" class="account" type="hidden" value="'.$second_account_id.'" >
						<h6>'.$from_label.':</h6>
						<input id="invoice_from" class="account-input" type="text" value="'.$invoice_from.'" readonly  style="cursor:pointer;" onclick="show_account_modal(this);">
						</section>
					
						<section>
						<h6>Total:</h6>
						<input id="invoice_total" class="autofocus" type="number" value="0" readonly>
						</section>
						
						<section>
						<h6>Discount:</h6>
						<input id="invoice_discount" type="number" value="0">
						</section>
						
						<section>
						<h6>NET:</h6>
						<input id="invoice_net" type="number" value="0" readonly>
						</section>

						<section>
						<h6>Memo:</h6>
						<input id="invoice_memo" type="text" value="">
						</section>
						
						<div>
						<label>Auto '.$payment_label.'<input type="checkbox" id="invoice_auto_payment"></label>
						</div>
						
						<i onclick="insert_invoice();" class="fas fa-check insert-btn"></i>
						<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
						<i onclick="show_items();" class="fas fa-cube stock-btn"></i>

					</div>
				</div>
				
				
				<div class="invoice-stock">
				
					<input type="hidden" class="invoice-product-page-number" value="0">
					
					<input type="hidden" class="invoice-product-page-search-product" value="">
					<input type="hidden" class="invoice-product-page-search-category1" value="">
					<input type="hidden" class="invoice-product-page-search-category2" value="">
					<input type="hidden" class="invoice-product-page-search-category3" value="">
					<input type="hidden" class="invoice-product-page-search-category4" value="">
					<input type="hidden" class="invoice-product-page-search-category5" value="">
					<input type="hidden" class="invoice-product-page-search-category6" value="">
					<input type="hidden" class="invoice-product-page-search-category7" value="">
					<input type="hidden" class="invoice-product-page-search-category8" value="">
					
					<div class="search">
						<input type="text" placeholder="Product" class="invoice-product-page-search-input-product">
						<input type="text" placeholder="Category 1" class="invoice-product-page-search-input-category1">
						<input type="text" placeholder="Category 2" class="invoice-product-page-search-input-category2">
						<input type="text" placeholder="Category 3" class="invoice-product-page-search-input-category3">
						<input type="text" placeholder="Category 4" class="invoice-product-page-search-input-category4">
						<input type="text" placeholder="Category 5" class="invoice-product-page-search-input-category5">
						<input type="text" placeholder="Category 6" class="invoice-product-page-search-input-category6">
						<input type="text" placeholder="Category 7" class="invoice-product-page-search-input-category7">
						<input type="text" placeholder="Category 8" class="invoice-product-page-search-input-category8">
						
						<i class="fas fa-search invoice-stock-search" onclick="
						loader_show();
						
						document.getElementsByClassName(`invoice-product-page-search-product`)[0].value =document.getElementsByClassName(`invoice-product-page-search-input-product`)[0].value;
						document.getElementsByClassName(`invoice-product-page-search-category1`)[0].value =document.getElementsByClassName(`invoice-product-page-search-input-category1`)[0].value;
						document.getElementsByClassName(`invoice-product-page-search-category2`)[0].value =document.getElementsByClassName(`invoice-product-page-search-input-category2`)[0].value;
						document.getElementsByClassName(`invoice-product-page-search-category3`)[0].value =document.getElementsByClassName(`invoice-product-page-search-input-category3`)[0].value;
						document.getElementsByClassName(`invoice-product-page-search-category4`)[0].value =document.getElementsByClassName(`invoice-product-page-search-input-category4`)[0].value;
						document.getElementsByClassName(`invoice-product-page-search-category5`)[0].value =document.getElementsByClassName(`invoice-product-page-search-input-category5`)[0].value;
						document.getElementsByClassName(`invoice-product-page-search-category6`)[0].value =document.getElementsByClassName(`invoice-product-page-search-input-category6`)[0].value;
						document.getElementsByClassName(`invoice-product-page-search-category7`)[0].value =document.getElementsByClassName(`invoice-product-page-search-input-category7`)[0].value;
						document.getElementsByClassName(`invoice-product-page-search-category8`)[0].value =document.getElementsByClassName(`invoice-product-page-search-input-category8`)[0].value;

						document.getElementsByClassName(`invoice-product-page-number`)[0].value =0;
						
						document.getElementsByClassName(`invoice-products-body`)[0].innerHTML =``;
						
						invoice_products_body();
						
						"></i>
						
					</div>

					<div class="stock-item-container">
						<table class="invoice-products-body">
						</table>
					</div>
					
					<div class="action">
						<i  onclick="save_items();"class="fas fa-plus save-items"></i>
						<i  onclick="cancel_items();" class="fas fa-times cancel-items"></i>
						<i  onclick="insert_product_modal();" class="fas fa-plus insert-product-items"></i>
					</div>
					
				</div>
				
				<div class="account-id-modal">
				
					<input type="hidden" class="account-page-number" value="0">
					<input type="hidden" class="account-page-search" value="">
				
					<div class="search">
						<input type="text" placeholder="Name" class="account-page-search-input">
						<i class="fas fa-search" onclick="
						loader_show();
						document.getElementsByClassName(`account-page-search`)[0].value =document.getElementsByClassName(`account-page-search-input`)[0].value;
						document.getElementsByClassName(`account-page-number`)[0].value =0;
						document.getElementsByClassName(`account-body`)[0].innerHTML =``;
						account_body();
						"></i>
					</div>

					<div class="account-item-container">
						<table class="account-body"></table>
					</div>
					
					<div class="action">
						<i  onclick="save_account_modal();"class="fas fa-plus save-account"></i>
						<i  onclick="cancel_account_modal();" class="fas fa-times cancel-account"></i>
					</div>
					
				</div>
				
			</form>';
	
	$response['error'] ='0';
	die(json_encode($response));
	
}
if ( $action == 'update_invoice_modal' ){

	if ( !( isset($_POST['id']) ) ){
		$response['error']='13200';
		die(json_encode($response));
	}
	
	$id =$_POST['id'];

	if ( !($response =select_invoice( $id )) ){
		$response ='13201';
		die(json_encode($response));
	}

	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}

	$data =$response['data'];
	$row =$data ->fetch_assoc();

	$account_id =htmlentities($row['c_AccountID']);
	$type =htmlentities($row['c_Type']);
	$branch =htmlentities($row['c_Branch']);
	$account_name =htmlentities($row['c_AccountName']);
	$invoice_from =htmlentities($row['c_SecondAccountName']);
	$total =htmlentities($row['c_Total']);
	$discount =htmlentities($row['c_Discount']);
	$net =$total-$discount;
	$memo =htmlentities($row['c_Memo']);

	if ($type=='Sale'){
		if ( !($authnication_user_update_sale=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ($type=='R Sale'){
		if ( !($authnication_user_update_r_sale=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if ($type=='Purchase'){
		if ( !($authnication_user_update_purchase=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ($type=='R Purchase'){
		if ( !($authnication_user_update_r_purchase=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	$from_label = 'From';
	if ( $type == 'Purchase'  || $type == 'R Sale' ){
		$from_label = 'To';
	}

	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ($type != 'Sale' && $type != 'R Sale' && $type != 'Purchase' && $type != 'R Purchase'){
		$response['error']='13202';
		die(json_encode($response));
	}

	if ( !( $response =select_invoice_items($id) ) ){
		$response['error']='13203';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$items ='';
	while ( $row =$data ->fetch_assoc() ){
		
		$item_id =htmlentities($row['c_StockID']);
		$item_name =htmlentities($row['c_StockName']);
		$item_qty =htmlentities($row['c_Qty']);
		$item_price =htmlentities($row['c_Price']);
		$item_discount =htmlentities($row['c_Discount']);
		
		$items .='
				<div class="invoice-item">
					<input  class="item-id" type="hidden" value="'.$item_id.'">
					<section class="item-name"><i class="fas fa-caret-down"> '.$item_name.'</i><i class="fas fa-trash delete-item"></i></section>
					<section><h6>Qty.</h6><input class="item-qty" type="number" value="'.$item_qty.'"></section>
					<section><h6>Price</h6><input class="item-price" type="number" value="'.$item_price.'"></section>
					<section><h6>Disc.%.</h6><input  class="item-discount" type="number" value="'.$item_discount.'"></section>
				</div>
		';
		
	}

	$response['data'] ='
		
			<form class="invoice-modal modal" onsubmit="event.preventDefault();remove_focus();update_invoice();">
			<input type="submit" style="display:none;">

				
				<div class="header">
					
					<div class="logo">
					<img src="logo.png" >
					</div>
					
					<i onclick="update_invoice();" class="fas fa-check insert-btn"></i>
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
					<i onclick="show_items();" class="fas fa-cube stock-btn"></i>
					
				</div>
		

				<div class="invoice-container">
	
					<h5>
					Edit '.$type.':
					</h5>
					
					<div class="invoice-items">

					'.$items.'
		
					</div>
					
					<div class="invoice-action">
	
						<input id="invoice_id" type="hidden" value="'.$id.'" >
						<input id="invoice_type" type="hidden" value="'.$type.'" >
						
						<section>
						<h6>Branch:</h6>
						<input type="text" value="'.$branch.'" readonly>
						</section>
						
						<section>
						<h6>ID:</h6>
						<input type="text" value="'.$id.'" readonly>
						</section>

						<section>
					
						<section>
						<input id="invoice_account_id" class="account" type="hidden" value="'.$account_id.'" >
						<h6>Account:</h6>
						<input type="text" value="'.$account_name.'" readonly>
						</section>
						
						<section>
						<h6>'.$from_label.':</h6>
						<input type="text" value="'.$invoice_from.'" readonly>
						</section>
					
						<section>
						<h6>Total:</h6>
						<input id="invoice_total" type="number" class="autofocus" value="'.$total.'" readonly>
						</section>
						
						<section>
						<h6>Discount:</h6>
						<input id="invoice_discount" type="number" value="'.$discount.'">
						</section>
						
						<section>
						<h6>NET:</h6>
						<input id="invoice_net" type="number" value="'.$net.'" readonly>
						</section>
						
						<section>
						<h6>Memo:</h6>
						<input id="invoice_memo" type="text" value="'.$memo.'">
						</section>

						
						<i onclick="update_invoice();" class="fas fa-check insert-btn"></i>
						<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
						<i onclick="show_items();" class="fas fa-cube stock-btn"></i>

					</div>
				</div>
				
				<div class="invoice-stock">
				
					<input type="hidden" class="invoice-product-page-number" value="0">
					
					<input type="hidden" class="invoice-product-page-search-product" value="">
					<input type="hidden" class="invoice-product-page-search-category1" value="">
					<input type="hidden" class="invoice-product-page-search-category2" value="">
					<input type="hidden" class="invoice-product-page-search-category3" value="">
					<input type="hidden" class="invoice-product-page-search-category4" value="">
					<input type="hidden" class="invoice-product-page-search-category5" value="">
					<input type="hidden" class="invoice-product-page-search-category6" value="">
					<input type="hidden" class="invoice-product-page-search-category7" value="">
					<input type="hidden" class="invoice-product-page-search-category8" value="">
					
					<div class="search">
						<input type="text" placeholder="Product" class="invoice-product-page-search-input-product">
						<input type="text" placeholder="Category 1" class="invoice-product-page-search-input-category1">
						<input type="text" placeholder="Category 2" class="invoice-product-page-search-input-category2">
						<input type="text" placeholder="Category 3" class="invoice-product-page-search-input-category3">
						<input type="text" placeholder="Category 4" class="invoice-product-page-search-input-category4">
						<input type="text" placeholder="Category 5" class="invoice-product-page-search-input-category5">
						<input type="text" placeholder="Category 6" class="invoice-product-page-search-input-category6">
						<input type="text" placeholder="Category 7" class="invoice-product-page-search-input-category7">
						<input type="text" placeholder="Category 8" class="invoice-product-page-search-input-category8">
						
						<i class="fas fa-search invoice-stock-search" onclick="
						loader_show();
						
						document.getElementsByClassName(`invoice-product-page-search-product`)[0].value =document.getElementsByClassName(`invoice-product-page-search-input-product`)[0].value;
						document.getElementsByClassName(`invoice-product-page-search-category1`)[0].value =document.getElementsByClassName(`invoice-product-page-search-input-category1`)[0].value;
						document.getElementsByClassName(`invoice-product-page-search-category2`)[0].value =document.getElementsByClassName(`invoice-product-page-search-input-category2`)[0].value;
						document.getElementsByClassName(`invoice-product-page-search-category3`)[0].value =document.getElementsByClassName(`invoice-product-page-search-input-category3`)[0].value;
						document.getElementsByClassName(`invoice-product-page-search-category4`)[0].value =document.getElementsByClassName(`invoice-product-page-search-input-category4`)[0].value;
						document.getElementsByClassName(`invoice-product-page-search-category5`)[0].value =document.getElementsByClassName(`invoice-product-page-search-input-category5`)[0].value;
						document.getElementsByClassName(`invoice-product-page-search-category6`)[0].value =document.getElementsByClassName(`invoice-product-page-search-input-category6`)[0].value;
						document.getElementsByClassName(`invoice-product-page-search-category7`)[0].value =document.getElementsByClassName(`invoice-product-page-search-input-category7`)[0].value;
						document.getElementsByClassName(`invoice-product-page-search-category8`)[0].value =document.getElementsByClassName(`invoice-product-page-search-input-category8`)[0].value;

						document.getElementsByClassName(`invoice-product-page-number`)[0].value =0;
						
						document.getElementsByClassName(`invoice-products-body`)[0].innerHTML =``;
						
						invoice_products_body();
						
						"></i>
						
					</div>

					<div class="stock-item-container">
						<table class="invoice-products-body">
						</table>
					</div>
					
					<div class="action">
						<i  onclick="save_items();"class="fas fa-plus save-items"></i>
						<i  onclick="cancel_items();" class="fas fa-times cancel-items"></i>
						<i  onclick="insert_product_modal();" class="fas fa-plus insert-product-items"></i>
					</div>
					
				</div>
				
			</form>';
	
	$response['error'] ='0';
	die(json_encode($response));
	
}
if ( $action == 'more_invoice_modal' ){
	
	if ( !( isset($_POST['id']) ) ){
		$response['error']='13200';
		die(json_encode($response));
	}
	
	$id =$_POST['id'];

	if ( !($response =select_invoice( $id )) ){
		$response ='13201';
		die(json_encode($response));
	}
		
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();

	$ID =htmlentities($row['c_ID']);
	$type =htmlentities($row['c_Type']);
	$branch =htmlentities($row['c_Branch']);
	$account_name =htmlentities($row['c_AccountName']);
	$invoice_from =htmlentities($row['c_SecondAccountName']);
	$total =htmlentities($row['c_Total']);
	$discount =htmlentities($row['c_Discount']);
	$net =$total-$discount;
	$memo =htmlentities($row['c_Memo']);
	
	if ($type=='Sale'){
		if ( !($authnication_user_view_sale=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ($type=='R Sale'){
		if ( !($authnication_user_view_r_sale=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if ($type=='Purchase'){
		if ( !($authnication_user_view_purchase=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ($type=='R Purchase'){
		if ( !($authnication_user_view_r_purchase=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	
	$from_label = 'From';
	if ( $type == 'Purchase'  || $type == 'R Sale' ){
		$from_label = 'To';
	}
	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ($type != 'Sale' && $type != 'R Sale' && $type != 'Purchase' && $type != 'R Purchase'){
		$response['error']='13202';
		die(json_encode($response));
	}

	if ( !( $response =select_invoice_items($id) ) ){
		$response['error']='13203';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$items ='';
	while ( $row =$data ->fetch_assoc() ){
		
		$item_id =htmlentities($row['c_StockID']);
		$item_name =htmlentities($row['c_StockName']);
		$item_qty =htmlentities($row['c_Qty']);
		$item_price =htmlentities($row['c_Price']);
		$item_discount =htmlentities($row['c_Discount']);
		
		$items .='
				<div class="invoice-item">
					<section class="item-name"><i class="fas fa-caret-down"> '.$item_name.'</i></section>
					<section><h6>Qty.</h6><input class="item-qty" type="number" value="'.$item_qty.'" readonly></section>
					<section><h6>Price</h6><input class="item-price" type="number" value="'.$item_price.'" readonly></section>
					<section><h6>Disc.%.</h6><input  class="item-discount" type="number" value="'.$item_discount.'" readonly></section>
				</div>
		';
		
	}

	$response['data'] ='
		
			<form class="invoice-modal modal" onsubmit="event.preventDefault();remove_focus();cancel_modal();">
			<input type="submit" style="display:none;">
				
				<div class="header">
					
					<div class="logo">
					<img src="logo.png" >
					</div>
					
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
					<a href="reports/invoice.php?invoice='.$id.'" target="_blank" class="fas fa-print print-btn"></a>
					
				</div>
		

				<div class="invoice-container">
	
					<h5>
					'.$type.':
					</h5>
					
					<div class="invoice-items">

					'.$items.'
		
					</div>
					
					<div class="invoice-action">
					
						<section>
						<h6>Branch:</h6>
						<input type="text" value="'.$branch.'" readonly>
						</section>
						
						<section>
						<h6>ID:</h6>
						<input type="text" value="'.$id.'" readonly>
						</section>
					
						<section>
						<h6>Account:</h6>
						<input type="text" value="'.$account_name.'" readonly>
						</section>
						
						<section>
						<h6>'.$from_label.':</h6>
						<input type="text" value="'.$invoice_from.'" readonly>
						</section>
					
						<section>
						<h6>Total:</h6>
						<input type="number" class="autofocus" value="'.$total.'" readonly>
						</section>
						
						<section>
						<h6>Discount:</h6>
						<input type="number" value="'.$discount.'" readonly>
						</section>
						
						<section>
						<h6>NET:</h6>
						<input type="number" value="'.$net.'" readonly>
						</section>

						<section>
						<h6>Memo:</h6>
						<input type="text" value="'.$memo.'" readonly>
						</section>

						
						<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
					<a href="reports/invoice.php?invoice='.$id.'" target="_blank" class="fas fa-print print-btn"></a>

					</div>
				</div>
				
			</form>';
	
	$response['error'] ='0';
	die(json_encode($response));
	
}
if ( $action == 'insert_income_modal' ){	

	if ( !( isset($_POST['account_id']) && isset($_POST['account_id']) ) ){
		$response['error']='13300';
		die(json_encode($response));
	}
	
	$account_id =$_POST['account_id'];
	$type =$_POST['type'];

	if ($type=='Income'){
		if ( !($authnication_user_insert_income=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ($type=='Outcome'){
		if ( !($authnication_user_insert_outcome=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ( !( $response =select_account($account_id) ) ){
		$response['error']='13301';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$account_name =htmlentities($row['c_Name']);
	$branch =htmlentities($row['c_Branch']);

	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	$basic_account = 'Sale';
	$invoice_from = 'Sale';
	$from_label = 'From';
	if ( $type == 'Outcome' ){
		$basic_account = 'Purchase';
		$invoice_from = 'Purchase';
		$from_label = 'To';
	}
	
	if ( !( $response =select_basic_account($basic_account, $branch) ) ){
		$response['error']='12101';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}

	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$second_account_id =htmlentities($row['c_ID']);
	
	$response['error'] ='0';
	$response['data']=
			'<form class="insert-income-modal modal" onsubmit="event.preventDefault();remove_focus();insert_income();">
			<input type="submit" style="display:none;">
				
				<div class="header">
					
					<div class="logo">
					<img src="logo.png" >
					</div>
					
					<i onclick="insert_income();" class="fas fa-check insert-btn"></i>
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
					
				</div>
		

		
				<div class="input-container">
				
					<input id="invoice_type" type="hidden" value="'.$type.'" >
					
					<h5>
					New '.$type.':
					</h5>

					<section>
					<h6>Branch:</h6>
					<input type="text" value="'.$branch.'" readonly>	
					</section>
					
					<section>
					<input id="income_account_id" class="account" type="hidden" value="'.$account_id.'" >
					<h6>Account:</h6>
					<input id="" class="account-input" type="text" value="'.$account_name.'" readonly  style="cursor:pointer;" onclick="show_account_modal(this);">
					</section>
					
					<section>
					<input id="income-second-account" class="account" type="hidden" value="'.$second_account_id.'" >				
					<h6>'.$from_label.':</h6>
					<input id="income_from" class="account-input" type="text" value="'.$basic_account.'" readonly  style="cursor:pointer;" onclick="show_account_modal(this);">
					</section>
				
					<section class="required">
					<h6>Ammount:</h6>
					<input id="income_ammount" class="autofocus" type="number" value="">
					</section>

					<section>
					<h6>Memo:</h6>
					<input id="income_memo" type="text" value="">
					</section>
					
					<i onclick="insert_income();" class="fas fa-check insert-btn"></i>
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>

				</div>
				
				<div class="account-id-modal">
				
					<input type="hidden" class="account-page-number" value="0">
					<input type="hidden" class="account-page-search" value="">
				
					<div class="search">
						<input type="text" placeholder="Name" class="account-page-search-input">
						<i class="fas fa-search" onclick="
						loader_show();
						document.getElementsByClassName(`account-page-search`)[0].value =document.getElementsByClassName(`account-page-search-input`)[0].value;
						document.getElementsByClassName(`account-page-number`)[0].value =0;
						document.getElementsByClassName(`account-body`)[0].innerHTML =``;
						account_body();
						"></i>
					</div>

					<div class="account-item-container">
						<table class="account-body"></table>
					</div>
					
					<div class="action">
						<i  onclick="save_account_modal();"class="fas fa-plus save-account"></i>
						<i  onclick="cancel_account_modal();" class="fas fa-times cancel-account"></i>
					</div>
					
				</div>

			</form>';
	die(json_encode($response));
	
}
if ( $action == 'update_income_modal' ){

	if ( !( isset($_POST['id']) ) ){
		$response['error']='13400';
		die(json_encode($response));
	}
	
	$id =$_POST['id'];
	

	
	if ( !($response =select_invoice( $id )) ){
		$response ='13201';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$branch =htmlentities($row['c_Branch']);
	$account_name =htmlentities($row['c_AccountName']);
	$second_account =htmlentities($row['c_SecondAccountName']);
	$type =htmlentities($row['c_Type']);
	$ammount =htmlentities($row['c_Total']);
	$memo =htmlentities($row['c_Memo']);

	if ($type=='Income'){
		if ( !($authnication_user_update_income=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ($type=='Outcome'){
		if ( !($authnication_user_update_outcome=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if ($type != 'Income' && $type != 'Outcome'){
		$response['error']='13402';
		die(json_encode($response));
	}
	
	$from_label = 'From';
	if ( $type == 'Outcome' ){
		$from_label = 'To';
	}

	$response['error'] ='0';
	$response['data']=
			'<form class="update-income-modal modal" onsubmit="event.preventDefault();remove_focus();update_income();">
			<input type="submit" style="display:none;">

				
				<div class="header">
					
					<div class="logo">
					<img src="logo.png" >
					</div>
					
					<i onclick="update_income();" class="fas fa-check insert-btn"></i>
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
					
				</div>
		

		
				<div class="input-container">
				
					<input id="income_id" type="hidden" value="'.$id.'" >
				
					<h5>
					Edit '.$type.':
					</h5>
					
					<section>
					<h6>Branch:</h6>
					<input type="text" value="'.$branch.'" readonly>
					</section>
					
					<section>
					<h6>ID:</h6>
					<input type="text" value="'.$id.'" readonly>
					</section>

					<section>
					<h6>Account:</h6>
					<input type="text" value="'.$account_name.'" readonly>
					</section>
					
					<section>
					<h6>'.$from_label.':</h6>
					<input type="text" value="'.$second_account.'" readonly>
					</section>
				
					<section class="required">
					<h6>Ammount:</h6>
					<input id="income_ammount" class="autofocus" type="number" value="'.$ammount.'">
					</section>

					<section>
					<h6>Memo:</h6>
					<input id="income_memo" type="text" value="'.$memo.'">
					</section>
					

					<i onclick="update_income();" class="fas fa-check insert-btn"></i>
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>

				</div>
				

			</form>';
	die(json_encode($response));
	
}
if ( $action == 'more_income_modal' ){
	
	if ( !( isset($_POST['id']) ) ){
		$response['error']='13400';
		die(json_encode($response));
	}
	
	$id =$_POST['id'];

	if ( !($response =select_invoice( $id )) ){
		$response ='13201';
		die(json_encode($response));
	}

	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	

	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$id =htmlentities($row['c_ID']);
	$branch =htmlentities($row['c_Branch']);
	$account_name =htmlentities($row['c_AccountName']);
	$second_account =htmlentities($row['c_SecondAccountName']);
	$type =htmlentities($row['c_Type']);
	$ammount =htmlentities($row['c_Total']);
	$memo =htmlentities($row['c_Memo']);

	if ($type=='Income'){
		if ( !($authnication_user_view_income=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ($type=='Outcome'){
		if ( !($authnication_user_view_outcome=='true') ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if ($type != 'Income' && $type != 'Outcome'){
		$response['error']='13402';
		die(json_encode($response));
	}

	$from_label = 'From';
	if ( $type == 'Outcome' ){
		$from_label = 'To';
	}
	
	$response['error'] ='0';
	$response['data']=
			'<form class="more-income-modal modal" onsubmit="event.preventDefault();remove_focus();cancel_modal();">
			<input type="submit" style="display:none;">

				
				<div class="header">
					
					<div class="logo">
					<img src="logo.png" >
					</div>
					
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
					<a href="reports/invoice.php?income='.$id.'" target="_blank" class="fas fa-print print-btn"></a>
					
					
				</div>
		

		
				<div class="input-container">
				
				
					<h5>
					'.$type.':
					</h5>
					
					<section>
					<h6>Branch:</h6>
					<input type="text" value="'.$branch.'" readonly>
					</section>
					
					<section>
					<h6>ID:</h6>
					<input type="text" value="'.$id.'" readonly>
					</section>
					
					<section>
					<h6>Account:</h6>
					<input type="text" value="'.$account_name.'" readonly>
					</section>
					
					<section>
					<h6>'.$from_label.':</h6>
					<input type="text" value="'.$second_account.'" readonly>
					</section>
				
					<section class="required">
					<h6>Ammount:</h6>
					<input type="number" class="autofocus" value="'.$ammount.'" readonly>
					</section>

					<section>
					<h6>Memo:</h6>
					<input type="text" value="'.$memo.'" readonly>
					</section>


					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
					<a href="reports/invoice.php?income='.$id.'" target="_blank" class="fas fa-print print-btn"></a>

				</div>
				

			</div>';
	die(json_encode($response));
	
}
#t_items
if ( $action == 'select_all_items_modal' ){
	
	if ( !( $authnication_user_all_items == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	
	
	$modal =
		'<div class="invoice-stock all-items" style="display:block;">
				
					<input type="hidden" class="all-items-page-number" value="0">
					
					<input type="hidden" class="all-items-page-search-branch" value="">
					<input type="hidden" class="all-items-page-search-from" value="">
					<input type="hidden" class="all-items-page-search-to" value="">
					<input type="hidden" class="all-items-page-search-product" value="">
					<input type="hidden" class="all-items-page-search-category1" value="">
					<input type="hidden" class="all-items-page-search-category2" value="">
					<input type="hidden" class="all-items-page-search-category3" value="">
					<input type="hidden" class="all-items-page-search-category4" value="">
					<input type="hidden" class="all-items-page-search-category5" value="">
					<input type="hidden" class="all-items-page-search-category6" value="">
					<input type="hidden" class="all-items-page-search-category7" value="">
					<input type="hidden" class="all-items-page-search-category8" value="">
					
					<div class="search">
						<input type="text" placeholder="Branch" class="all-items-page-search-input-branch">
						<input type="date" class="all-items-page-search-input-from">
						<input type="date" class="all-items-page-search-input-to">
						<input type="text" placeholder="Product" class="all-items-page-search-input-product">
						<input type="text" placeholder="Category 1" class="all-items-page-search-input-category1">
						<input type="text" placeholder="Category 2" class="all-items-page-search-input-category2">
						<input type="text" placeholder="Category 3" class="all-items-page-search-input-category3">
						<input type="text" placeholder="Category 4" class="all-items-page-search-input-category4">
						<input type="text" placeholder="Category 5" class="all-items-page-search-input-category5">
						<input type="text" placeholder="Category 6" class="all-items-page-search-input-category6">
						<input type="text" placeholder="Category 7" class="all-items-page-search-input-category7">
						<input type="text" placeholder="Category 8" class="all-items-page-search-input-category8">
						
						<i class="fas fa-search" onclick="
						loader_show();
						
						document.getElementsByClassName(`all-items-page-search-branch`)[0].value =document.getElementsByClassName(`all-items-page-search-input-branch`)[0].value;
						document.getElementsByClassName(`all-items-page-search-from`)[0].value =document.getElementsByClassName(`all-items-page-search-input-from`)[0].value;
						document.getElementsByClassName(`all-items-page-search-to`)[0].value =document.getElementsByClassName(`all-items-page-search-input-to`)[0].value;
						document.getElementsByClassName(`all-items-page-search-product`)[0].value =document.getElementsByClassName(`all-items-page-search-input-product`)[0].value;
						document.getElementsByClassName(`all-items-page-search-category1`)[0].value =document.getElementsByClassName(`all-items-page-search-input-category1`)[0].value;
						document.getElementsByClassName(`all-items-page-search-category2`)[0].value =document.getElementsByClassName(`all-items-page-search-input-category2`)[0].value;
						document.getElementsByClassName(`all-items-page-search-category3`)[0].value =document.getElementsByClassName(`all-items-page-search-input-category3`)[0].value;
						document.getElementsByClassName(`all-items-page-search-category4`)[0].value =document.getElementsByClassName(`all-items-page-search-input-category4`)[0].value;
						document.getElementsByClassName(`all-items-page-search-category5`)[0].value =document.getElementsByClassName(`all-items-page-search-input-category5`)[0].value;
						document.getElementsByClassName(`all-items-page-search-category6`)[0].value =document.getElementsByClassName(`all-items-page-search-input-category6`)[0].value;
						document.getElementsByClassName(`all-items-page-search-category7`)[0].value =document.getElementsByClassName(`all-items-page-search-input-category7`)[0].value;
						document.getElementsByClassName(`all-items-page-search-category8`)[0].value =document.getElementsByClassName(`all-items-page-search-input-category8`)[0].value;

						document.getElementsByClassName(`all-items-page-number`)[0].value =0;
						
						
						all_items_body();
						
						"></i>
						
					</div>

					<div class="all-items-container">
						
					</div>
					
					<div class="action">
						<i  onclick="cancel_items();" class="fas fa-times cancel-items"></i>
					</div>
					
				</div>';
	
	$response['data'] =$modal;
	$response['error'] ='0';
	die(json_encode($response));	
	
}
if ( $action == 'select_all_items' ){
	
	if ( !( isset($_POST['page_search_branch']) ) ){
		$page_search_branch ='';
	}else{
		$page_search_branch =$_POST['page_search_branch'];
	}
	
	if ( !( isset($_POST['page_search_from']) ) ){
		$page_search_from ='';
	}else{
		$page_search_from =$_POST['page_search_from'];
	}
	
	if ( !( isset($_POST['page_search_to']) ) ){
		$page_search_to ='';
	}else{
		$page_search_to =$_POST['page_search_to'];
	}
	
	if ( !( isset($_POST['page_search_product']) ) ){
		$page_search_product ='';
	}else{
		$page_search_product =$_POST['page_search_product'];
	}
	
	if ( !( isset($_POST['page_search_category1']) ) ){
		$page_search_category1 ='';
	}else{
		$page_search_category1 =$_POST['page_search_category1'];
	}
	
	if ( !( isset($_POST['page_search_category2']) ) ){
		$page_search_category2 ='';
	}else{
		$page_search_category2 =$_POST['page_search_category2'];
	}
	
	if ( !( isset($_POST['page_search_category3']) ) ){
		$page_search_category3 ='';
	}else{
		$page_search_category3 =$_POST['page_search_category3'];
	}
	
	if ( !( isset($_POST['page_search_category4']) ) ){
		$page_search_category4 ='';
	}else{
		$page_search_category4 =$_POST['page_search_category4'];
	}
	
	if ( !( isset($_POST['page_search_category5']) ) ){
		$page_search_category5 ='';
	}else{
		$page_search_category5 =$_POST['page_search_category5'];
	}
	
	if ( !( isset($_POST['page_search_category6']) ) ){
		$page_search_category6 ='';
	}else{
		$page_search_category6 =$_POST['page_search_category6'];
	}
	
	if ( !( isset($_POST['page_search_category7']) ) ){
		$page_search_category7 ='';
	}else{
		$page_search_category7 =$_POST['page_search_category7'];
	}
	
	if ( !( isset($_POST['page_search_category8']) ) ){
		$page_search_category8 ='';
	}else{
		$page_search_category8 =$_POST['page_search_category8'];
	}

	
	if ( !( $authnication_user_all_items == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !($authnication_user_all_branches=='true') ){
		if ( !($response =select_user_all_items( $page_search_branch, $page_search_from, $page_search_to, $page_search_product, $page_search_category1, $page_search_category2, $page_search_category3, $page_search_category4, $page_search_category5, $page_search_category6, $page_search_category7, $page_search_category8, $authnication_user_branch )) ){
			$response ='14000';
			die(json_encode($response));
		}
	}else{
		if ( !($response =select_all_items( $page_search_branch, $page_search_from, $page_search_to, $page_search_product, $page_search_category1, $page_search_category2, $page_search_category3, $page_search_category4, $page_search_category5, $page_search_category6, $page_search_category7, $page_search_category8)) ){
			$response ='14000';
			die(json_encode($response));
		}
	}
	

	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	$all_items ='';
	$sale_qty=0;
	$r_sale_qty=0;
	$purchase_qty=0;
	$r_purchase_qty=0;
	$sale_total=0;
	$r_sale_total=0;
	$purchase_total=0;
	$r_purchase_total=0;
	$sale_profit=0;
	$r_sale_profit=0;
	$data =$response['data'];
	while ( $row= $data ->fetch_assoc() ){
		
			$id =htmlentities($row['c_ID']);
			$name =htmlentities($row['c_StockName']);
			$branch =htmlentities($row['c_Branch']);
			$invoice_date =htmlentities($row['c_InvoiceDate']);
			$qty =htmlentities($row['c_Qty']);
			$invoice_type =htmlentities($row['c_InvoiceType']);
			$price =htmlentities($row['c_Price']);
			$average_cost =htmlentities($row['c_StockAverageCost']);
			$discount =htmlentities($row['c_Discount']);
			
			$total = ($qty*$price)-( ($qty*$price)*($discount/100) );
			
			$profit = ( $total-($average_cost*$qty) );
			
			
			if ($invoice_type=='Sale'){
				$sale_qty+=$qty;
				$sale_total+=$total;
				$sale_profit+= $profit;
			}
			if ($invoice_type=='R Sale'){
				$r_sale_qty+=$qty;
				$r_sale_total+=$total;
				$r_sale_profit+= $profit;
			}
			
			if ($invoice_type=='Purchase'){
				$purchase_qty+=$qty;
				$purchase_total+=$total;
			}
			if ($invoice_type=='R Purchase'){
				$r_purchase_qty+=$qty;
				$r_purchase_total+=$total;
			}
			
			
			if ($invoice_type=='Purchase' || $invoice_type=='R Purchase'){
				$profit= '';
				$average_cost= '-';
			}else{
				$profit = ' ('.$profit.')';
			}
			
			$total = ' ('.$total.')';
			
			$all_items .="
				<tr>
				<td>$name</td>
				<td>$invoice_type</td>
				<td>$qty$total</td>
				<td>$average_cost$profit</td>
				<td>$invoice_date</td>
				<td>$branch</td>
				</tr>
			";
		
	}
	
	$header = '
		<th>Product</th>
		<th>Type</th>
		<th>Qty. (Ammount)</th>
		<th>Cost (Profit)</th>
		<th>Date</th>
		<th>Branch</th>
	';
	
	$total_tr = "
		<tr class='total-tr' style='background-color:orange;'>
			<td>Sale<section>$sale_qty ($sale_total)</section></td>
			<td>R Sale<section>$r_sale_qty ($r_sale_total)</section></td>
			<td>Purchase<section>$purchase_qty ($purchase_total)</section></td>
			<td>R Purchase<section>$r_purchase_qty ($r_purchase_total)</section></td>
			<td>Sale L/P<section>$sale_profit</section></td>
			<td>R Sale L/P<section>$r_sale_profit</section></td>
		</tr>
	";

	$response['data'] ='<table class="all-items-body">'.$total_tr.$header.$all_items.'</table>';
	$response['error'] ='0';
	die(json_encode($response));		
	
}
if ( $action == 'select_inventory_modal' ){
	
	if ( !( $authnication_user_cost == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !( $authnication_user_all_branches == 'true' ) ){
		$branches = "<option value='$authnication_user_branch'>$authnication_user_branch</option>";
	}else{

		if ( !($response =select_branches()) ){
			$response ='16000';
			die(json_encode($response));
		}
		
		if ( !( $response['error'] ==0 ) ){
			die(json_encode($response));
		}
		
		$branches ='';
		$data =$response['data'];
		
		while($row= $data->fetch_assoc()){
			$branch = $row['c_Branch'];
			$branches .="<option value='$branch'>$branch</option>";
		}
	
	}

	$modal =
		'<div class="loss-profit-modal inventory-modal modal">

				
				<div class="header">
					
					<div class="logo">
					<img src="logo.png" >
					</div>
					
					<i onclick="loader_show();inventory();" style="color:orange;" class="fas fa-search insert-btn"></i>
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
					
				</div>
		

		
				<div class="input-container">
				
				
					<h5>
					Total
					</h5>
					
					<section>
					<h6>Branch:</h6>
					<select class="inventory-page-search-branch">
					'.$branches.'
					</select>
					</section>

					<textarea class="response-textarea" readonly></textarea>

					<i onclick="loader_show();inventory();" style="background-color:orange;" class="fas fa-search insert-btn"></i>
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>

				</div>
				
				

			</div>';
	
	$response['data'] =$modal;
	$response['error'] ='0';
	die(json_encode($response));	
	
}
if ( $action == 'select_inventory' ){
	
	
	if ( !( isset($_POST['page_search_branch']) ) ){
		$page_search_branch ='';
	}else{
		$page_search_branch =$_POST['page_search_branch'];
	}
	
	
	if ( !( $authnication_user_cost == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !( $authnication_user_all_branches == 'true' ) ){
		$branches = "<option value='$authnication_user_branch'>$authnication_user_branch</option>";
	}else{

		if ( !($response =select_branches()) ){
			$response ='16000';
			die(json_encode($response));
		}
		
		if ( !( $response['error'] ==0 ) ){
			die(json_encode($response));
		}
		
		$branches ='';
		$data =$response['data'];
		
		while($row= $data->fetch_assoc()){
			$branch = $row['c_Branch'];
			$branches .="<option value='$branch'>$branch</option>";
		}
		
	}
	
	if ( !($authnication_user_all_branches=='true') ){
		if ( !($response =select_user_inventory( $page_search_branch, $authnication_user_branch )) ){
			$response ='12001';
			die(json_encode($response));
		}
	}else{
		if ( !($response =select_inventory( $page_search_branch )) ){
			$response ='12001';
			die(json_encode($response));
		}
	}
	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	
	$data =$response['data'];
	
	while($row= $data->fetch_assoc()){
		$inventory = $row['s_Inventory'];
	}
	
	if ( !($authnication_user_all_branches=='true') ){
		if ( !($response =select_user_account_type_balance( $page_search_branch, 'Customer', $authnication_user_branch )) ){
			$response ='12081';
			die(json_encode($response));
		}
	}else{
		if ( !($response =select_account_type_balance( $page_search_branch, 'Customer' )) ){
			$response ='12701';
			die(json_encode($response));
		}
	}
	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	
	$data =$response['data'];
	
	while($row= $data->fetch_assoc()){
		$customers_total = $row['s_Balance'];
	}
	
	if ( !($authnication_user_all_branches=='true') ){
		if ( !($response =select_user_account_type_balance( $page_search_branch, 'Supplier', $authnication_user_branch )) ){
			$response ='12081';
			die(json_encode($response));
		}
	}else{
		if ( !($response =select_account_type_balance( $page_search_branch, 'Supplier' )) ){
			$response ='12701';
			die(json_encode($response));
		}
	}
	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	
	$data =$response['data'];
	
	while($row= $data->fetch_assoc()){
		$suppliers_total = $row['s_Balance'];
	}
	
	$data ="Inventory Total: $inventory
Customers Total: $customers_total
Suppliers Total: $suppliers_total";
	
	$response['data'] =$data;
	$response['error'] ='0';
	die(json_encode($response));	
	
}
if ( $action == 'select_loss_profit_modal' ){
	
	if ( !( $authnication_user_loss_profit == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !( $authnication_user_all_branches == 'true' ) ){
		$branches = "<option value='$authnication_user_branch'>$authnication_user_branch</option>";
	}else{

		if ( !($response =select_branches()) ){
			$response ='16000';
			die(json_encode($response));
		}
		
		if ( !( $response['error'] ==0 ) ){
			die(json_encode($response));
		}
		
		$branches ='';
		$data =$response['data'];
		
		while($row= $data->fetch_assoc()){
			$branch = $row['c_Branch'];
			$branches .="<option value='$branch'>$branch</option>";
		}
	
	}

	$modal =
		'<div class="loss-profit-modal modal">

				
				<div class="header">
					
					<div class="logo">
					<img src="logo.png" >
					</div>
					
					<i onclick="loader_show();loss_profit();" style="color:orange;" class="fas fa-search insert-btn"></i>
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
					
				</div>
		

		
				<div class="input-container">
				
				
					<h5>
					Loss & Profit
					</h5>
					
					<section>
					<h6>Branch:</h6>
					<select class="loss-porfit-page-search-branch">
					'.$branches.'
					</select>
					</section>
					
					<section>
					<h6>From Date:</h6>
					<input class="loss-porfit-page-search-from" type="date">
					</section>
					
					<section>
					<h6>To Date:</h6>
					<input class="loss-porfit-page-search-to" type="date">
					</section>

					<textarea class="response-textarea" readonly></textarea>

					<i onclick="loader_show();loss_profit();" style="background-color:orange;" class="fas fa-search insert-btn"></i>
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>

				</div>
				
				

			</div>';
	
	$response['data'] =$modal;
	$response['error'] ='0';
	die(json_encode($response));	
	
}
if ( $action == 'select_loss_profit' ){
	
	
	if ( !( isset($_POST['page_search_branch']) ) ){
		$page_search_branch ='';
	}else{
		$page_search_branch =$_POST['page_search_branch'];
	}
	
	if ( !( isset($_POST['page_search_from']) ) ){
		$page_search_from ='';
	}else{
		$page_search_from =$_POST['page_search_from'];
	}
	
	if ( !( isset($_POST['page_search_to']) ) ){
		$page_search_to ='';
	}else{
		$page_search_to =$_POST['page_search_to'];
	}

	
	if ( !( $authnication_user_loss_profit == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !( $authnication_user_all_branches == 'true' ) ){
		$branches = "<option value='$authnication_user_branch'>$authnication_user_branch</option>";
	}else{

		if ( !($response =select_branches()) ){
			$response ='16000';
			die(json_encode($response));
		}
		
		if ( !( $response['error'] ==0 ) ){
			die(json_encode($response));
		}
		
		$branches ='';
		$data =$response['data'];
		
		while($row= $data->fetch_assoc()){
			$branch = $row['c_Branch'];
			$branches .="<option value='$branch'>$branch</option>";
		}
		
	}
	
	if ( !($authnication_user_all_branches=='true') ){
		if ( !($response =select_user_items_profit( $page_search_branch, $page_search_from, $page_search_to, $authnication_user_branch )) ){
			$response ='12001';
			die(json_encode($response));
		}
	}else{
		if ( !($response =select_items_profit( $page_search_branch, $page_search_from, $page_search_to )) ){
			$response ='12001';
			die(json_encode($response));
		}
	}
	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	
	$data =$response['data'];
	
	while($row= $data->fetch_assoc()){
		$sale_profit = $row['s_SaleProfit'];
		$r_sale_profit = $row['s_RSaleProfit'];
	}
	
	if ( !($authnication_user_all_branches=='true') ){
		if ( !($response =select_user_invoices_profit( $page_search_branch, $page_search_from, $page_search_to, $authnication_user_branch )) ){
			$response ='12001';
			die(json_encode($response));
		}
	}else{
		if ( !($response =select_invoices_profit( $page_search_branch, $page_search_from, $page_search_to )) ){
			$response ='12001';
			die(json_encode($response));
		}
	}
	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	
	$data =$response['data'];
	
	while($row= $data->fetch_assoc()){
		$income = $row['s_Income'];
		$outcome = $row['s_Outcome'];
	}
	
	if ( !($authnication_user_all_branches=='true') ){
		if ( !($response =select_user_expense_total( $page_search_branch, $page_search_from, $page_search_to, $authnication_user_branch )) ){
			$response ='12001';
			die(json_encode($response));
		}
	}else{
		if ( !($response =select_expense_total( $page_search_branch, $page_search_from, $page_search_to )) ){
			$response ='12001';
			die(json_encode($response));
		}
	}
	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	
	$data =$response['data'];
	
	while($row= $data->fetch_assoc()){
		$expense_total = $row['s_Total'];
	}
	
	$total = $sale_profit-$r_sale_profit;
	
	$data ='Sale Profit: '.$sale_profit.'
R Sale Profit: '.$r_sale_profit.'
***************************
Total Sale Profit: '.$total.'
Income: '.$income.'
Outcome: '.$outcome.'
Expense Total: '.$expense_total.'';
	
	$response['data'] =$data;
	$response['error'] ='0';
	die(json_encode($response));	
	
}
#t_stock
if ( $action == 'select_products' ){
	
	if ( !( $authnication_user_view_stock == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}	
	
	if ( !( isset($_POST['page_search_branch']) ) ){
		$page_search_branch ='';
	}else{
		$page_search_branch =$_POST['page_search_branch'];
	}
	
	if ( !( isset($_POST['page_search_product']) ) ){
		$page_search_product ='';
	}else{
		$page_search_product =$_POST['page_search_product'];
	}
	
	if ( !( isset($_POST['page_search_category1']) ) ){
		$page_search_category1 ='';
	}else{
		$page_search_category1 =$_POST['page_search_category1'];
	}
	
	if ( !( isset($_POST['page_search_category2']) ) ){
		$page_search_category2 ='';
	}else{
		$page_search_category2 =$_POST['page_search_category2'];
	}
	
	if ( !( isset($_POST['page_search_category3']) ) ){
		$page_search_category3 ='';
	}else{
		$page_search_category3 =$_POST['page_search_category3'];
	}
	
	if ( !( isset($_POST['page_search_category4']) ) ){
		$page_search_category4 ='';
	}else{
		$page_search_category4 =$_POST['page_search_category4'];
	}
	
	if ( !( isset($_POST['page_search_category5']) ) ){
		$page_search_category5 ='';
	}else{
		$page_search_category5 =$_POST['page_search_category5'];
	}
	
	if ( !( isset($_POST['page_search_category6']) ) ){
		$page_search_category6 ='';
	}else{
		$page_search_category6 =$_POST['page_search_category6'];
	}
	
	if ( !( isset($_POST['page_search_category7']) ) ){
		$page_search_category7 ='';
	}else{
		$page_search_category7 =$_POST['page_search_category7'];
	}
	
	if ( !( isset($_POST['page_search_category8']) ) ){
		$page_search_category8 ='';
	}else{
		$page_search_category8 =$_POST['page_search_category8'];
	}
	
	if ( !( isset($_POST['page_search_order']) ) ){
		$page_search_order ='';
	}else{
		$page_search_order =$_POST['page_search_order'];
	}


	if ( !( isset($_POST['page_number']) ) ){
		$page_number =0;
	}else{
		$page_number =$_POST['page_number'];
		if ( !( $page_number>=0 ) ){
			$page_number =0;
		}
	}
	
	$page_limit =25;
	$off_set =$page_limit * $page_number;
	$i =0;
	
	if ( !($authnication_user_all_branches=='true') ){
		if ( !($response =select_user_products( $page_search_branch, $page_search_product, $page_search_category1, $page_search_category2, $page_search_category3, $page_search_category4, $page_search_category5, $page_search_category6, $page_search_category7, $page_search_category8, $page_search_order, $authnication_user_branch )) ){
			$response ='14000';
			die(json_encode($response));
		}
	}else{
		if ( !($response =select_products( $page_search_branch, $page_search_product, $page_search_category1, $page_search_category2, $page_search_category3, $page_search_category4, $page_search_category5, $page_search_category6, $page_search_category7, $page_search_category8, $page_search_order )) ){
			$response ='14000';
			die(json_encode($response));
		}
	}
	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	$products ='';
	$data =$response['data'];
	for ( $i=0 ; $row =$data ->fetch_assoc() ; $i++ ){

		if ( $i>$off_set-1 && $i<($page_limit+$off_set) ){

			$id =htmlentities($row['c_ID']);
			$name =htmlentities($row['c_Name']);
			$branch =htmlentities($row['c_Branch']);
			$price =htmlentities($row['c_Price']);
			$opening_qty =htmlentities($row['c_OpeningQty']);
			$purchase_qty =htmlentities($row['c_PurchaseQty']);
			$sale_qty =htmlentities($row['c_SaleQty']);
			$minimum =htmlentities($row['c_Minimum']);
			$maximum =htmlentities($row['c_Maximum']);
	
			$stock = ($purchase_qty - $sale_qty) + $opening_qty;

			
			if ( $sale_qty >0 || $purchase_qty >0){
				$activity ='true';
			}
			else{
				$activity ='false';
			}
			
			$color ='';
			if ( $stock <$minimum ){
				$color = 'red';
			}
			if ( $stock >$minimum ){
				$color = 'green';
			}
			
			$products .="
				<div class='item $color' data-id='$id' data-name='$name' data-activity ='$activity'>		
					<span class='bolder'>$name</span>
					<span class='light'>$branch</span>
					<span class='light'>price: $price</span>
					<section class='level2'>
					<span class='light'>Sale: $sale_qty</span>
					<span class='light'>Purchase: $purchase_qty</span>
					</section>
					<span class='bold'>Qty: $stock</span>
					<span class='more more-product-btn'><i class='fas fa-ellipsis-h'></i> More</span>		
				</div>
			";
		
		}
	
	}
	
	if ( mysqli_num_rows($data) > ($page_limit+$off_set) ){
		$products .="<i class='fas fa-chevron-down load-btn' onclick='products_body();' > Load More</i>";
	}
	
	
	$response['data'] =$products;
	$response['error'] ='0';
	die(json_encode($response));	
}
if ( $action == 'refresh_product' ){
	
	if ( !( $authnication_user_view_stock == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !( isset($_POST['id']) ) ){
		$response['error'] ='14200';
		die(json_encode($response));
	}

	$id =$_POST['id'];
	
	if ( !($response =select_product( $id )) ){
		$response ='14000';
		die(json_encode($response));
	}
	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();


	$id =htmlentities($row['c_ID']);	
	$branch =htmlentities($row['c_Branch']);
	$name =htmlentities($row['c_Name']);
	$price =htmlentities($row['c_Price']);
	$opening_qty =htmlentities($row['c_OpeningQty']);
	$purchase_qty =htmlentities($row['c_PurchaseQty']);
	$sale_qty =htmlentities($row['c_SaleQty']);
	$minimum =htmlentities($row['c_Minimum']);
	$maximum =htmlentities($row['c_Maximum']);

	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	$stock = ($purchase_qty - $sale_qty) + $opening_qty ;

	
	if ( $sale_qty >0 || $purchase_qty >0 ){
		$activity ='true';
	}
	else{
		$activity ='false';
	}

	$color ='';
	if ( $stock <$minimum ){
		$color = 'red';
	}
	if ( $stock >$minimum ){
		$color = 'green';
	}
			
	$product="
		<div class='item $color' data-id='$id' data-name='$name' data-activity ='$activity'>		
			<span class='bolder'>$name</span>
			<span class='light'>$branch</span>
			<span class='light'>price: $price</span>
			<section class='level2'>
			<span class='light'>Sale: $sale_qty</span>
			<span class='light'>Purchase: $purchase_qty</span>
			</section>
			<span class='bold'>Qty: $stock</span>
			<span class='more more-product-btn'><i class='fas fa-ellipsis-h'></i> More</span>		
		</div>
	";
	
	$response['data'] =$product;
	$response['error'] ='0';
	die(json_encode($response));	
}
if ( $action == 'insert_product_modal' ){
	
	if ( !( $authnication_user_insert_stock == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !( $authnication_user_all_branches == 'true' ) ){
		$branches = "<option value='$authnication_user_branch'>$authnication_user_branch</option>";
	}else{

		if ( !($response =select_branches()) ){
			$response ='16000';
			die(json_encode($response));
		}
		
		if ( !( $response['error'] ==0 ) ){
			die(json_encode($response));
		}
		
		$branches ='';
		$data =$response['data'];
		
		while($row= $data->fetch_assoc()){
			$branch = $row['c_Branch'];
			$branches .="<option value='$branch'>$branch</option>";
		}
		
	}	
	
	$response['error'] ='0';
	$response['data'] =
			'<form class="insert-product-modal modal" onsubmit="event.preventDefault();remove_focus();insert_product();">
			<input type="submit" style="display:none;">

				
				<div class="header">
					
					<div class="logo">
					<img src="logo.png" >
					</div>
					
					<i onclick="insert_product();" class="fas fa-check insert-btn"></i>
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
					
				</div>
				

				<div class="input-container">
				
					<h5>
					New Product: Product
					</h5>
					
					<div class="inside-input-container">
						<section>
						<h6>Branch:</h6>
						<select id="product_branch">
						'.$branches.'
						</select>
						</section>
						
						<section class="required">
						<h6>Name:</h6>
						<input id="product_name" class="autofocus" type="text" value="">
						</section>
						
						<section>
						<h6>Opening Qty:</h6>
						<input id="product_opening_qty" type="number" value="">
						</section>
						
						<section>
						<h6>Opening Cost:</h6>
						<input id="product_opening_cost" type="number" value="">
						</section>
						
						<section>
						<h6>Price:</h6>
						<input id="product_price" type="number" value="">
						</section>
						
						<section>
						<h6>Minimum:</h6>
						<input id="product_minimum" type="number" value="">
						</section>
						
						<section>
						<h6>Maximum:</h6>
						<input id="product_maximum" type="number" value="">
						</section>

						<section>
						<h6>Memo:</h6>
						<input id="product_memo" type="text" value="">
						</section>
					
					</div>
				
					<div class="inside-input-container">
					
						<section>
						<h6>Category 1:</h6>
						<input id="product_category1" type="text" value="">
						</section>
						
						<section>
						<h6>Category 2:</h6>
						<input id="product_category2" type="text" value="">
						</section>
						
						<section>
						<h6>Category 3:</h6>
						<input id="product_category3" type="text" value="">
						</section>
						
						<section>
						<h6>Category 4:</h6>
						<input id="product_category4" type="text" value="">
						</section>
						
						<section>
						<h6>Category 5:</h6>
						<input id="product_category5" type="text" value="">
						</section>
						
						<section>
						<h6>Category 6:</h6>
						<input id="product_category6" type="text" value="">
						</section>
						
						<section>
						<h6>Category 7:</h6>
						<input id="product_category7" type="text" value="">
						</section>
						
						<section>
						<h6>Category 8:</h6>
						<input id="product_category8" type="text" value="">
						</section>


					</div>
				
						<i onclick="insert_product();" class="fas fa-check insert-btn"></i>
						<i onclick="cancel_modal();"class="fas fa-times cancel-btn"></i>

			</form>';
	die(json_encode($response));
	
}
if ( $action == 'update_product_modal' ){
	
	if ( !( $authnication_user_update_stock == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !( isset($_POST['id']) ) ){
		$response['error'] ='14200';
		die(json_encode($response));
	}

	$id =$_POST['id'];
	
	if ( !( $response =select_product($id) ) ){
		$response['error'] ='14201';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$branch =htmlentities($row['c_Branch']);
	$name =htmlentities($row['c_Name']);
	$sale_qty =htmlentities($row['c_SaleQty']);
	$purchase_qty =htmlentities($row['c_PurchaseQty']);
	$qty =htmlentities($row['c_OpeningQty']);
	$cost =htmlentities($row['c_OpeningCost']);
	$price =htmlentities($row['c_Price']);
	$minimum =htmlentities($row['c_Minimum']);
	$maximum =htmlentities($row['c_Maximum']);
	$category1 =htmlentities($row['c_Category1']);
	$category2 =htmlentities($row['c_Category2']);
	$category3 =htmlentities($row['c_Category3']);
	$category4 =htmlentities($row['c_Category4']);
	$category5 =htmlentities($row['c_Category5']);
	$category6 =htmlentities($row['c_Category6']);
	$category7 =htmlentities($row['c_Category7']);
	$category8 =htmlentities($row['c_Category8']);
	$memo =htmlentities($row['c_Memo']);
	
	$input_type='number';
	$input_readonly='';
	if ( $authnication_user_cost!='true' ){
		$cost='**********';
		$input_type='text';
		$input_readonly='readonly';
	}
	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	$allow_name_update='';
	if ($sale_qty!=0 || $purchase_qty!=0){
		$allow_name_update='readonly';
	}
	
	$response['error'] ='0';
	$response['data'] =
			'<form class="update-product-modal modal" onsubmit="event.preventDefault();remove_focus();update_product();">
			<input type="submit" style="display:none;">

				
				<div class="header">
					
					<div class="logo">
					<img src="logo.png" >
					</div>
					
					<i onclick="update_product();" class="fas fa-check insert-btn"></i>
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
					
				</div>
				
				<input id="product_id" type="hidden" value="'.$id.'">

				<div class="input-container">
				
					<h5>
					Edit Product: '.$name.'
					</h5>
					
					<div class="inside-input-container">
						
						<section>
						<h6>Branch:</h6>
						<input id="product_branch" type="text" value="'.$branch.'" readonly>
						</section>
						
						<section class="required">
						<h6>Name:</h6>
						<input id="product_name" class="autofocus" type="text" value="'.$name.'" '.$allow_name_update.'>
						</section>
						
						<section>
						<h6>Opening Qty:</h6>
						<input id="product_opening_qty" type="number" value="'.$qty.'">
						</section>
				
						<section>
						<h6>Opening Cost:</h6>
						<input id="product_opening_cost" type="'.$input_type.'" value="'.$cost.'" '.$input_readonly.'>
						</section>
						
						<section>
						<h6>Price:</h6>
						<input id="product_price" type="number" value="'.$price.'">
						</section>
						
						<section>
						<h6>Minimum:</h6>
						<input id="product_minimum" type="number" value="'.$minimum.'">
						</section>
						
						<section>
						<h6>Maximum:</h6>
						<input id="product_maximum" type="text" value="'.$maximum.'">
						</section>
						
						<section>
						<h6>Memo:</h6>
						<input id="product_memo" type="text" value="'.$memo.'">
						</section>
					
					</div>
					
					<div class="inside-input-container">
					
						<section>
						<h6>Category 1:</h6>
						<input id="product_category1" type="text" value="'.$category1.'">
						</section>
						
						<section>
						<h6>Category 2:</h6>
						<input id="product_category2" type="text" value="'.$category2.'">
						</section>
						
						<section>
						<h6>Category 3:</h6>
						<input id="product_category3" type="text" value="'.$category3.'">
						</section>
						
						<section>
						<h6>Category 4:</h6>
						<input id="product_category4" type="text" value="'.$category4.'">
						</section>
						
						<section>
						<h6>Category 5:</h6>
						<input id="product_category5" type="text" value="'.$category5.'">
						</section>
						
						<section>
						<h6>Category 6:</h6>
						<input id="product_category6" type="text" value="'.$category6.'">
						</section>
						
						<section>
						<h6>Category 7:</h6>
						<input id="product_category7" type="text" value="'.$category7.'">
						</section>
						
						<section>
						<h6>Category 8:</h6>
						<input id="product_category8" type="text" value="'.$category8.'">
						</section>					
					
					</div>
					
					<i onclick="update_product();" class="fas fa-check insert-btn"></i>
					<i onclick="cancel_modal();"class="fas fa-times cancel-btn"></i>

				</div>
				

			</form>';
	die(json_encode($response));
	
}
if ( $action == 'more_product_modal' ){
	
	if ( !( $authnication_user_view_stock == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !( isset($_POST['id']) ) ){
		$response['error'] ='14200';
		die(json_encode($response));
	}

	$id =$_POST['id'];
	
	if ( !( $response =select_product($id) ) ){
		$response['error'] ='14201';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$branch =htmlentities($row['c_Branch']);
	$name =htmlentities($row['c_Name']);
	$opening_qty =htmlentities($row['c_OpeningQty']);
	$sale_qty =htmlentities($row['c_SaleQty']);
	$purchase_qty =htmlentities($row['c_PurchaseQty']);
	$opening_qty =htmlentities($row['c_OpeningQty']);
	$opening_cost =htmlentities($row['c_OpeningCost']);
	$last_cost =htmlentities($row['c_LastCost']);
	$average_cost =htmlentities($row['c_AverageCost']);
	$price =htmlentities($row['c_Price']);
	$minimum =htmlentities($row['c_Minimum']);
	$maximum =htmlentities($row['c_Maximum']);
	$category1 =htmlentities($row['c_Category1']);
	$category2 =htmlentities($row['c_Category2']);
	$category3 =htmlentities($row['c_Category3']);
	$category4 =htmlentities($row['c_Category4']);
	$category5 =htmlentities($row['c_Category5']);
	$category6 =htmlentities($row['c_Category6']);
	$category7 =htmlentities($row['c_Category7']);
	$category8 =htmlentities($row['c_Category8']);
	$memo =htmlentities($row['c_Memo']);
	$sale_loss_profit =htmlentities($row['c_SaleLossProfit']);
	$r_sale_loss_profit =htmlentities($row['c_RSaleLossProfit']);

	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	$stock = ($purchase_qty - $sale_qty) + $opening_qty ;

	$stock_total = $average_cost*$stock;

	if ( $authnication_user_cost!='true' ){
		$opening_cost='**********';
		$average_cost='**********';
		$last_cost='**********';
		$stock_total='**********';
		$sale_loss_profit='**********';
		$r_sale_loss_profit='**********';
	}

	if ( !( isset($_POST['page_search']) ) ){
		$page_search ='';
	}else{
		$page_search =$_POST['page_search'];
	}

	if ( !( isset($_POST['page_number']) ) ){
		$page_number =0;
	}else{
		$page_number =$_POST['page_number'];
		if ( !( $page_number>=0 ) ){
			$page_number =0;
		}
	}
	
	
	$page_limit =500;
	$off_set =$page_limit * $page_number;
	$i =0;
	
	if ( !($response =select_product_items( $id )) ){
		$response ='11202';
		die(json_encode($response));
	}
	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	$product_items ='';
	$data =$response['data'];
	for ( $i=0 ; $row =$data ->fetch_assoc() ; $i++ ){

		if ( $i>$off_set-1 && $i<($page_limit+$off_set) ){

			$item_invoice_id =htmlentities($row['c_InvoiceID']);
			$item_type =htmlentities($row['c_InvoiceType']);
			$item_account_name =htmlentities($row['c_AccountName']);
			$item_qty =htmlentities($row['c_Qty']);
			$item_price =htmlentities($row['c_Price']);
			$item_discount =htmlentities($row['c_Discount']);
			$item_invoice_date =htmlentities($row['c_InvoiceDate']);
			
			$item_ammount = ($item_price*$item_qty)-( ($item_price*$item_qty)*($item_discount/100) );
			
			$product_item="
				<tr>
					<input type='hidden' value='$item_invoice_id' class='invoice-id' >
					<td>$item_account_name</td>
					<td>$item_type</td>
					<td>$item_qty</td>
					<td>$item_ammount</td>
					<td>$item_invoice_date</td>
				</tr>
			";
			
			$allow='true';
			if ($item_type=='Sale'){
				if ( !($authnication_user_view_sale=='true') ){
					$allow ='false';
				}
			}			
			if ($item_type=='R Sale'){
				if ( !($authnication_user_view_r_sale=='true') ){
					$allow ='false';
				}
			}
			if ($item_type=='Purchase'){
				if ( !($authnication_user_view_purchase=='true') ){
					$allow ='false';
				}
			}			
			if ($item_type=='R Purchase'){
					if ( !($authnication_user_view_r_purchase=='true') ){
					$allow ='false';
				}
			}	
			if ($allow!='true'){
				$product_item= '';
				$i--;
			}

			$product_items .=$product_item;
		
		}
	
	}

	
	$response['error'] ='0';
	$response['data'] =
			'<form class="more-product-modal modal more-modal" onsubmit="event.preventDefault();remove_focus();cancel_modal();">
			<input type="submit" style="display:none;">

				
				<div class="header">
					
					<div class="logo">
					<img src="logo.png" >
					</div>
					
					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
					
				</div>
				
				<div class="input-container">
				
					<h5>
					Product: '.$name.'
					</h5>
					
					<div class="left-div">
						
						<div class="inside-input-container">

							<section>
							<h6>Branch:</h6>
							<input type="text" value="'.$branch.'" readonly>
							</section>
							
							<section>
							<h6>Name:</h6>
							<input type="text" class="autofocus" value="'.$name.'" readonly>
							</section>

							<section>
							<h6>Opening Qty:</h6>
							<input type="text" value="'.$opening_qty.'" readonly>
							</section>
							
							<section>
							<h6>Sale Qty:</h6>
							<input type="text" value="'.$sale_qty.'" readonly>
							</section>
							
							<section>
							<h6>Purchase Qty:</h6>
							<input type="text" value="'.$purchase_qty.'" readonly>
							</section>
							
							<section>
							<h6>Qty:</h6>
							<input type="text" value="'.$stock.'" readonly>
							</section>
							
							<section>
							<h6>Total:</h6>
							<input type="text" value="'.$stock_total.'" readonly>
							</section>
							
							<section>
							<h6>Last Cost:</h6>
							<input type="text" value="'.$last_cost.'" readonly>
							</section>
							
							<section>
							<h6>Opening Cost:</h6>
							<input type="text" value="'.$opening_cost.'" readonly>
							</section>
							
							<section>
							<h6>Average Cost:</h6>
							<input type="text" value="'.$average_cost.'" readonly>
							</section>	
							
							<section>
							<h6>Price:</h6>
							<input type="text" value="'.$price.'" readonly>
							</section>
						
						
						</div>
						
						<div class="inside-input-container">
							
							<section>
							<h6>Memo:</h6>
							<input type="text" value="'.$memo.'" readonly>
							</section>
						
							<section>
							<h6>Sale Loss Profit:</h6>
							<input type="text" value="'.$sale_loss_profit.'" readonly>
							</section>
							
							<section>
							<h6>R Sale Loss Profit:</h6>
							<input type="text" value="'.$r_sale_loss_profit.'" readonly>
							</section>
							
							<section>
							<h6>Category 1:</h6>
							<input type="text" value="'.$category1.'" readonly>
							</section>
							
							<section>
							<h6>Category 2:</h6>
							<input type="text" value="'.$category2.'" readonly>
							</section>
							
							<section>
							<h6>Category 3:</h6>
							<input type="text" value="'.$category3.'" readonly>
							</section>
							
							<section>
							<h6>Category 4:</h6>
							<input type="text" value="'.$category4.'" readonly>
							</section>
							
							<section>
							<h6>Category 5:</h6>
							<input type="text" value="'.$category5.'" readonly>
							</section>
							
							<section>
							<h6>Category 6:</h6>
							<input type="text" value="'.$category6.'" readonly>
							</section>
							
							<section>
							<h6>Category 7:</h6>
							<input type="text" value="'.$category7.'" readonly>
							</section>
							
							<section>
							<h6>Category 8:</h6>
							<input type="text" value="'.$category8.'" readonly>
							</section>					
						
						</div>						
					</div>
					
					<div class="activity-table-container">
						<table class="activity-table product-activity">
							<tr>
								<td>Account</td>
								<td>Type</td>
								<td>Qty.</td>
								<td>Ammount</td>
								<td>Date</td>
							</tr>
							'.$product_items.'
						</table>
					</div>
					
					<i onclick="cancel_modal();"class="fas fa-times cancel-btn"></i>

				</div>
				

			</form>';
	die(json_encode($response));
	
}
if ( $action == 'select_invoice_products' ){

	if ( !( isset($_POST['page_search_branch']) ) ){
		$page_search_branch ='';
	}else{
		$page_search_branch =$_POST['page_search_branch'];
	}

	if ( !( isset($_POST['page_search_product']) ) ){
		$page_search_product ='';
	}else{
		$page_search_product =$_POST['page_search_product'];
	}
	
	if ( !( isset($_POST['page_search_category1']) ) ){
		$page_search_category1 ='';
	}else{
		$page_search_category1 =$_POST['page_search_category1'];
	}
	
	if ( !( isset($_POST['page_search_category2']) ) ){
		$page_search_category2 ='';
	}else{
		$page_search_category2 =$_POST['page_search_category2'];
	}
	
	if ( !( isset($_POST['page_search_category3']) ) ){
		$page_search_category3 ='';
	}else{
		$page_search_category3 =$_POST['page_search_category3'];
	}
	
	if ( !( isset($_POST['page_search_category4']) ) ){
		$page_search_category4 ='';
	}else{
		$page_search_category4 =$_POST['page_search_category4'];
	}
	
	if ( !( isset($_POST['page_search_category5']) ) ){
		$page_search_category5 ='';
	}else{
		$page_search_category5 =$_POST['page_search_category5'];
	}
	
	if ( !( isset($_POST['page_search_category6']) ) ){
		$page_search_category6 ='';
	}else{
		$page_search_category6 =$_POST['page_search_category6'];
	}
	
	if ( !( isset($_POST['page_search_category7']) ) ){
		$page_search_category7 ='';
	}else{
		$page_search_category7 =$_POST['page_search_category7'];
	}
	
	if ( !( isset($_POST['page_search_category8']) ) ){
		$page_search_category8 ='';
	}else{
		$page_search_category8 =$_POST['page_search_category8'];
	}
	
	if ( !( isset($_POST['page_search_order']) ) ){
		$page_search_order ='';
	}else{
		$page_search_order =$_POST['page_search_order'];
	}

	if ( !( isset($_POST['type']) ) ){
		$type ='Sale';
	}else{
		$type =$_POST['type'];
	}

	if ( !( isset($_POST['account_id']) ) ){
		$account_id =0;
	}else{
		$account_id =$_POST['account_id'];
	}

	if ( !( isset($_POST['page_number']) ) ){
		$page_number =0;
	}else{
		$page_number =$_POST['page_number'];
		if ( !( $page_number>=0 ) ){
			$page_number =0;
		}
	}
	
	$page_limit =50;
	$off_set =$page_limit * $page_number;
	$i =0;
	
	if ( !($authnication_user_insert_sale=='true') && !($authnication_user_update_sale=='true') && !($authnication_user_insert_r_sale=='true') && !($authnication_user_update_r_sale=='true') && !($authnication_user_insert_purchase=='true') && !($authnication_user_update_purchase=='true') && !($authnication_user_insert_r_purchase=='true') && !($authnication_user_update_r_purchase=='true') ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !( $response =select_account($account_id) ) ){
		$response['error']='13101';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$account_name =htmlentities($row['c_Name']);
	$branch =htmlentities($row['c_Branch']);
	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ( !($response =select_user_products( '', $page_search_product, $page_search_category1, $page_search_category2, $page_search_category3, $page_search_category4, $page_search_category5, $page_search_category6, $page_search_category7, $page_search_category8, $page_search_order, $branch )) ){
		$response ='14000';
		die(json_encode($response));
	}		

	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	$invoice_products ='';
	$data =$response['data'];
	for ( $i=0 ; $row =$data ->fetch_assoc() ; $i++ ){

		if ( $i>$off_set-1 && $i<($page_limit+$off_set) ){

			$id =htmlentities($row['c_ID']);
			$name =htmlentities($row['c_Name']);
			
			if ( $type =='Sale' || $type =='R Sale' ){
			$price =htmlentities($row['c_Price']);
			}else{
			$price =htmlentities($row['c_LastCost']);
			}
			
			$opening_qty =htmlentities($row['c_OpeningQty']);
			$purchase_qty =htmlentities($row['c_PurchaseQty']);
			$sale_qty =htmlentities($row['c_SaleQty']);

			$stock = ($purchase_qty - $sale_qty)+$opening_qty;

			$in_stock = "<div>(Stock : $stock)</div>";

			$invoice_products .="
				
				<tr data-id='$id' data-name='$name' data-price='$price'>
					<td>$name $in_stock</td>
				</tr>
				
			";
		
		}
	
	}	
	
	$response['data'] =$invoice_products;
	$response['error'] ='0';
	die(json_encode($response));	
}
#t_journal
if ( $action == 'select_journal' ){

	if ( $authnication_user_view_sale!='true' && $authnication_user_view_r_sale!='true' && $authnication_user_view_purchase!='true' && $authnication_user_view_r_purchase!='true' && $authnication_user_view_income!='true' && $authnication_user_view_outcome!='true' && $authnication_user_view_receipt!='true' && $authnication_user_view_payment!='true' ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}

	if ( !( $authnication_user_journal == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}

	if ( !( isset($_POST['page_search_branch']) ) ){
		$page_search_branch ='';
	}else{
		$page_search_branch =$_POST['page_search_branch'];
	}
	
	if ( !( isset($_POST['page_search_from']) ) ){
		$page_search_from ='';
	}else{
		$page_search_from =$_POST['page_search_from'];
	}
	
	if ( !( isset($_POST['page_search_to']) ) ){
		$page_search_to ='';
	}else{
		$page_search_to =$_POST['page_search_to'];
	}

	if ( !( isset($_POST['page_search_account']) ) ){
		$page_search_account ='';
	}else{
		$page_search_account =$_POST['page_search_account'];
	}
	
	if ( !( isset($_POST['page_search_type']) ) ){
		$page_search_type ='';
	}else{
		$page_search_type =$_POST['page_search_type'];
	}
	
	if ( !( isset($_POST['page_search_order']) ) ){
		$page_search_order ='';
	}else{
		$page_search_order =$_POST['page_search_order'];
	}

	if ( !( isset($_POST['page_number']) ) ){
		$page_number =0;
	}else{
		$page_number =$_POST['page_number'];
		if ( !( $page_number>=0 ) ){
			$page_number =0;
		}
	}
	
	$page_limit =30;
	$off_set =$page_limit * $page_number;
	$i =0;
	
	if ( !($authnication_user_all_branches=='true') ){
		if ( !($response =select_user_journal( $page_search_branch, $page_search_from, $page_search_to, $page_search_account, $page_search_type, $page_search_order, $authnication_user_branch )) ){
			$response ='13001';
			die(json_encode($response));
		}
	}else{
		if ( !($response =select_journal( $page_search_branch, $page_search_from, $page_search_to, $page_search_account, $page_search_type, $page_search_order )) ){
			$response ='13001';
			die(json_encode($response));
		}
	}
	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	$total_bar = '';
	$total_debit = 0;
	$total_credit = 0;
	$journal ='';
	$data =$response['data'];
	for ( $i=0 ; $row =$data ->fetch_assoc() ; $i++ ){

		$debit =htmlentities($row['c_Debit']);
		$credit =htmlentities($row['c_Credit']);
		$type =htmlentities($row['c_Type']);
		$allow ='true';
		if ($type=='Sale'){
			if ( !($authnication_user_view_sale=='true') ){
				$allow ='false';
			}
		}			
		if ($type=='R Sale'){
			if ( !($authnication_user_view_r_sale=='true') ){
					$allow ='false';
			}
		}
		if ($type=='Purchase'){
			if ( !($authnication_user_view_purchase=='true') ){
				$allow ='false';
			}
		}			
		if ($type=='R Purchase'){
				if ( !($authnication_user_view_r_purchase=='true') ){
				$allow ='false';
			}
		}			
		if ($type=='Income'){
				if ( !($authnication_user_view_income=='true') ){
				$allow ='false';
			}
		}		
		if ($type=='Outcome'){
			if ( !($authnication_user_view_outcome=='true') ){
				$allow ='false';
			}
		}
		if ($type=='Receipt'){
			if ( !($authnication_user_view_receipt=='true') ){
				$allow ='false';
			}
		}		
		if ($type=='Payment'){
			if ( !($authnication_user_view_payment=='true') ){
				$allow ='false';
			}
		}
		if ($allow =='true'){
			$total_debit+= $debit;
			$total_credit+= $credit;
		}
	
		if ( $i>$off_set-1 && $i<($page_limit+$off_set) ){

			$id =htmlentities($row['c_ID']);
			$branch =htmlentities($row['c_Branch']);
			$parent_id =htmlentities($row['c_ParentID']);
			$account_name =htmlentities($row['c_AccountName']);
			$date =htmlentities($row['c_Date']);

			
			$color ='';
			if ( $debit>$credit ){
				$color = 'green';
				$debit_credit = "
				<span class='light'>Credit: $credit</span>
				<span class='bold'>Debit: $debit</span> ";
			}else{
				$color = 'red';
				$debit_credit = "
				<span class='bold'>Credit: $credit</span>
				<span class='light'>Debit: $debit</span> ";
			}
	
			
			$this_record="
				<div class='item $color' data-id='$parent_id' data-account-name='$account_name' data-type='$type'>		
					<span class='bolder'>$account_name</span>
					<span class='light'>$branch</span>
					<section class='level2'>
					<span class='light'>$type</span>
					<span class='light'>date: $date</span>
					</section>
					$debit_credit
					<span class='more more-journal-btn'><i class='fas fa-ellipsis-h'></i> More</span>		
				</div>
			";
			
			
			if ($allow!='true'){
				$this_record= '';
				$i--;
			}
			
			$journal .=$this_record;
		
		}
	
	}
	
	if ( mysqli_num_rows($data) > ($page_limit+$off_set) ){
		$journal .="<i class='fas fa-chevron-down load-btn' onclick='journal_body();' > Load More</i>";
	}

	$total_total = $total_debit - $total_credit;
	
	if ($total_total>0){
		$style = 'color: rgb(76,175,80);';
	}
	if ($total_total<0){
		$style = 'color: rgb(255,114,111);';
	}
	if ($total_total==0){
		$style = '';
	}
	
	if ( $page_number==0 ){
		
		$total_bar = '
			<h6><b style="margin-right:20px;">Debit :'.$total_debit.'</b><b>Credit :'.$total_credit.'</b></h6>
			<h6><b style="'.$style.'">Total :'.$total_total.'</b></h6>
		';
		
	}
	
	$response['data'] =$total_bar.$journal;
	$response['error'] ='0';
	die(json_encode($response));
	
}
#t_users
if ( $action == 'select_users' ){
	
	if ( !( $authnication_user_users == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !( isset($_POST['page_search']) ) ){
		$page_search ='';
	}else{
		$page_search =$_POST['page_search'];
	}

	if ( !( isset($_POST['page_number']) ) ){
		$page_number =0;
	}else{
		$page_number =$_POST['page_number'];
		if ( !( $page_number>=0 ) ){
			$page_number =0;
		}
	}
	
	$page_limit =1000;
	$off_set =$page_limit * $page_number;
	$i =0;
	
	if ( !($response =select_users( $page_search )) ){
		$response ='16000';
		die(json_encode($response));
	}
	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	$users ='';
	$data =$response['data'];

	for ( $i=0 ; $row =$data ->fetch_assoc() ; $i++ ){

		if ( $i>$off_set-1 && $i<($page_limit+$off_set) ){

			$id =htmlentities($row['c_ID']);
			$name =htmlentities($row['c_Name']);

			$users .='
				<div class="order-item">

							<input  class="user-id" type="hidden" value="'.$id.'">
							<section class="order-item-name">'.$name.'<i class="fas fa-trash-alt delete-user-btn"></i><i class="fas fa-pen update-user-btn"></i></i></section>
							
				</div>
			';
		
		}
	
	}
	
	if ( mysqli_num_rows($data) > ($page_limit+$off_set) ){
		$items .="<i class='fas fa-chevron-down load-btn' onclick='order_body();' > Load More</i>";
	}
	
	
	$modal =
		'<form class="order-modal modal"onsubmit="event.preventDefault();remove_focus();cancel_modal();">
		<input type="submit" style="display:none;">
				<div class="header">
					
					<div class="logo">
					<img src="logo.png" >
					</div>

					<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
					
				</div>
				
				
				<div class="order-container">
					<h5>
						<i onclick="cancel_modal();" class="fas fa-times cancel-btn"></i>
						Users
					</h5>
				
					<div class="order-items">
						<div style="font-weight:bold;padding:5px;background-color:lightgray;color:green;cursor:pointer;"><i class="fas fa-user-plus" style="padding:5px 15px;background-color:;border-radius:4px;" onclick="insert_user_modal()"></i></div>
						'.$users.'
					</div>
				
				</div>
				
	</form>';
	
	$response['data'] =$modal;
	$response['error'] ='0';
	die(json_encode($response));	
	
}
if ( $action == 'insert_user_modal' ){
	
	if ( !( $authnication_user_users == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}

	if ( !($response =select_branches()) ){
		$response ='16000';
		die(json_encode($response));
	}
	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	$branches ='';
	$data =$response['data'];
	
	while($row= $data->fetch_assoc()){
		$branch = $row['c_Branch'];
		$branches .="<option value='$branch'>$branch</option>";
	}


	$response['error'] ='0';
	$response['data']=
			'<form class="insert-user-modal user-modal modal" onsubmit="event.preventDefault();remove_focus();insert_user();">
			<input type="submit" style="display:none;">

				
				<div class="header">
					
					<div class="logo">
					<img src="logo.png" >
					</div>
					
					<i onclick="insert_user();" class="fas fa-check insert-btn"></i>
					<i onclick="cancel_user_modal();" class="fas fa-times cancel-btn"></i>
					
				</div>
		

		
				<div class="input-container">
				
					<h5>
					New User
					</h5>
					
					<section class="required">
					<h6>Name:</h6>
					<input id="user_name" class="autofocus" type="text" value="">
					</section>

					<section  class="required">
					<h6>Password:</h6>
					<input id="user_password" type="password" value="">
					</section>
					
					<section>
					<h6>Branch:</h6>
					<select id="user_branch">
					'.$branches.'
					</select>
					</section>
					
					<div>
					<h6>Accounts :</h6>
					<label>View
					<input id="user_view_account" type="checkbox">
					</label>
					
					<label>New
					<input id="user_insert_account" type="checkbox">
					</label>
					
					<label>Update
					<input id="user_update_account" type="checkbox">
					</label>
					
					<label>Delete
					<input id="user_delete_account" type="checkbox">
					</label>
					
					<label>Export
					<input id="user_export_accounts" type="checkbox">
					</label>
					
					</div>
					
					<div>
					<h6>Stock :</h6>
					<label>View
					<input id="user_view_stock" type="checkbox">
					</label>
					
					<label>New
					<input id="user_insert_stock" type="checkbox">
					</label>
					
					<label>Update
					<input id="user_update_stock" type="checkbox">
					</label>
					
					<label>Delete
					<input id="user_delete_stock" type="checkbox">
					</label>
					
					<label>Cost
					<input id="user_cost" type="checkbox">
					</label>
					
					<label>All Items
					<input id="user_all_items" type="checkbox">
					</label>
					
					<label>Export
					<input id="user_export_stock" type="checkbox">
					</label>
					
					</div>
					
					<div>
					<h6>Sale :</h6>
					<label>View
					<input id="user_view_sale" type="checkbox">
					</label>
					
					<label>New
					<input id="user_insert_sale" type="checkbox">
					</label>
					
					<label>Update
					<input id="user_update_sale" type="checkbox">
					</label>
					
					<label>Delete
					<input id="user_delete_sale" type="checkbox">
					</label>
					
					</div>
					
					<div>
					<h6>R Sale :</h6>
					<label>View
					<input id="user_view_r_sale" type="checkbox">
					</label>
					
					<label>New
					<input id="user_insert_r_sale" type="checkbox">
					</label>
					
					<label>Update
					<input id="user_update_r_sale" type="checkbox">
					</label>
					
					<label>Delete
					<input id="user_delete_r_sale" type="checkbox">
					</label>
					
					</div>
					
					<div>
					<h6>Purchase :</h6>
					<label>View
					<input id="user_view_purchase" type="checkbox">
					</label>
					
					<label>New
					<input id="user_insert_purchase" type="checkbox">
					</label>
					
					<label>Update
					<input id="user_update_purchase" type="checkbox">
					</label>
					
					<label>Delete
					<input id="user_delete_purchase" type="checkbox">
					</label>
					
					</div>
					
					<div>
					<h6>R Purchase :</h6>
					<label>View
					<input id="user_view_r_purchase" type="checkbox">
					</label>
					
					<label>New
					<input id="user_insert_r_purchase" type="checkbox">
					</label>
					
					<label>Update
					<input id="user_update_r_purchase" type="checkbox">
					</label>
					
					<label>Delete
					<input id="user_delete_r_purchase" type="checkbox">
					</label>
					
					</div>
					
					<div>
					<h6>Income :</h6>
					<label>View
					<input id="user_view_income" type="checkbox">
					</label>
					
					<label>New
					<input id="user_insert_income" type="checkbox">
					</label>
					
					<label>Update
					<input id="user_update_income" type="checkbox">
					</label>
					
					<label>Delete
					<input id="user_delete_income" type="checkbox">
					</label>
					
					</div>
					
					<div>
					<h6>Outcome :</h6>
					<label>View
					<input id="user_view_outcome" type="checkbox">
					</label>
					
					<label>New
					<input id="user_insert_outcome" type="checkbox">
					</label>
					
					<label>Update
					<input id="user_update_outcome" type="checkbox">
					</label>
					
					<label>Delete
					<input id="user_delete_outcome" type="checkbox">
					</label>

					</div>
					
					<div>
					<h6>Receipt :</h6>
					<label>View
					<input id="user_view_receipt" type="checkbox">
					</label>
					
					<label>New
					<input id="user_insert_receipt" type="checkbox">
					</label>
					
					<label>Update
					<input id="user_update_receipt" type="checkbox">
					</label>
					
					<label>Delete
					<input id="user_delete_receipt" type="checkbox">
					</label>
	
					</div>
					
					<div>
					<h6>Payment :</h6>
					<label>View
					<input id="user_view_payment" type="checkbox">
					</label>
					
					<label>New
					<input id="user_insert_payment" type="checkbox">
					</label>
					
					<label>Update
					<input id="user_update_payment" type="checkbox">
					</label>
					
					<label>Delete
					<input id="user_delete_payment" type="checkbox">
					</label>
					
					</div>
					
					<div>
					<h6>Other :</h6>
				
					<label>All Branches
					<input id="user_all_branches" type="checkbox">
					</label>
					
					<label>Journal
					<input id="user_journal" type="checkbox">
					</label>
					
					<label>Export Journal
					<input id="user_export_journal" type="checkbox">
					</label>
					
					
					<label>Loss Profit
					<input id="user_loss_profit" type="checkbox">
					</label>
					
					
					<label>Users
					<input id="user_users" type="checkbox">
					</label>

					
					<label>BackUp
					<input id="user_backup" type="checkbox">
					</label>
					
					<label>Restore
					<input id="user_restore" type="checkbox">
					</label>

					</div>

					<i onclick="insert_user();" class="fas fa-check insert-btn"></i>
					<i onclick="cancel_user_modal();" class="fas fa-times cancel-btn"></i>

				</div>
				
				

			</form>';
	die(json_encode($response));
	
}
if ( $action == 'update_user_modal' ){
	
	if ( !( isset($_POST['id']) ) ){
		$response['error']='13400';
		die(json_encode($response));
	}
	
	$id =$_POST['id'];
	
	if ( !( $response =select_user($id) ) ){
		$response['error']='13401';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$user_id=htmlentities($row['c_ID']);
	
	$user_name=htmlentities($row['c_Name']);
	$user_password=htmlentities($row['c_Password']);
	$user_branch=htmlentities($row['c_Branch']);
	
	$user_view_account=htmlentities($row['c_ViewAccount']);
	$user_insert_account=htmlentities($row['c_InsertAccount']);
	$user_update_account=htmlentities($row['c_UpdateAccount']);
	$user_delete_account=htmlentities($row['c_DeleteAccount']);
	$user_export_accounts=htmlentities($row['c_ExportAccounts']);

	$user_view_stock=htmlentities($row['c_ViewStock']);
	$user_insert_stock=htmlentities($row['c_InsertStock']);
	$user_update_stock=htmlentities($row['c_UpdateStock']);
	$user_delete_stock=htmlentities($row['c_DeleteStock']);
	$user_cost=htmlentities($row['c_Cost']);
	$user_all_items=htmlentities($row['c_AllItems']);
	$user_export_stock=htmlentities($row['c_ExportStock']);
	
	$user_view_sale=htmlentities($row['c_ViewSale']);
	$user_insert_sale=htmlentities($row['c_InsertSale']);
	$user_update_sale=htmlentities($row['c_UpdateSale']);
	$user_delete_sale=htmlentities($row['c_DeleteSale']);
	
	$user_view_r_sale=htmlentities($row['c_ViewRSale']);
	$user_insert_r_sale=htmlentities($row['c_InsertRSale']);
	$user_update_r_sale=htmlentities($row['c_UpdateRSale']);
	$user_delete_r_sale=htmlentities($row['c_DeleteRSale']);
	
	$user_view_purchase=htmlentities($row['c_ViewPurchase']);
	$user_insert_purchase=htmlentities($row['c_InsertPurchase']);
	$user_update_purchase=htmlentities($row['c_UpdatePurchase']);
	$user_delete_purchase=htmlentities($row['c_DeletePurchase']);
	
	$user_view_r_purchase=htmlentities($row['c_ViewRPurchase']);
	$user_insert_r_purchase=htmlentities($row['c_InsertRPurchase']);
	$user_update_r_purchase=htmlentities($row['c_UpdateRPurchase']);
	$user_delete_r_purchase=htmlentities($row['c_DeleteRPurchase']);
	
	$user_view_income=htmlentities($row['c_ViewIncome']);
	$user_insert_income=htmlentities($row['c_InsertIncome']);
	$user_update_income=htmlentities($row['c_UpdateIncome']);
	$user_delete_income=htmlentities($row['c_DeleteIncome']);
	
	$user_view_outcome=htmlentities($row['c_ViewOutcome']);
	$user_insert_outcome=htmlentities($row['c_InsertOutcome']);
	$user_update_outcome=htmlentities($row['c_UpdateOutcome']);
	$user_delete_outcome=htmlentities($row['c_DeleteOutcome']);
	
	$user_view_receipt=htmlentities($row['c_ViewReceipt']);
	$user_insert_receipt=htmlentities($row['c_InsertReceipt']);
	$user_update_receipt=htmlentities($row['c_UpdateReceipt']);
	$user_delete_receipt=htmlentities($row['c_DeleteReceipt']);
	
	$user_view_payment=htmlentities($row['c_ViewPayment']);
	$user_insert_payment=htmlentities($row['c_InsertPayment']);
	$user_update_payment=htmlentities($row['c_UpdatePayment']);
	$user_delete_payment=htmlentities($row['c_DeletePayment']);
	
	$user_all_branches=htmlentities($row['c_AllBranches']);
	$user_journal=htmlentities($row['c_Journal']);
	$user_export_journal=htmlentities($row['c_ExportJournal']);
	$user_loss_profit=htmlentities($row['c_LossProfit']);
	$user_users=htmlentities($row['c_Users']);
	$user_backup=htmlentities($row['c_BackUp']);
	$user_restore=htmlentities($row['c_Restore']);

	if ($user_view_account == 'true'){
		$user_view_account = 'checked';
	}
	if ($user_insert_account == 'true'){
		$user_insert_account = 'checked';
	}
	if ($user_update_account == 'true'){
		$user_update_account = 'checked';
	}
	if ($user_delete_account == 'true'){
		$user_delete_account = 'checked';
	}
	if ($user_export_accounts == 'true'){
		$user_export_accounts = 'checked';
	}

	if ($user_view_stock == 'true'){
		$user_view_stock = 'checked';
	}
	if ($user_insert_stock == 'true'){
		$user_insert_stock = 'checked';
	}
	if ($user_update_stock == 'true'){
		$user_update_stock = 'checked';
	}
	if ($user_delete_stock == 'true'){
		$user_delete_stock = 'checked';
	}
	if ($user_cost == 'true'){
		$user_cost = 'checked';
	}
	if ($user_all_items == 'true'){
		$user_all_items = 'checked';
	}
	if ($user_export_stock == 'true'){
		$user_export_stock = 'checked';
	}
	
	if ($user_view_sale == 'true'){
		$user_view_sale = 'checked';
	}
	if ($user_insert_sale == 'true'){
		$user_insert_sale = 'checked';
	}
	if ($user_update_sale == 'true'){
		$user_update_sale = 'checked';
	}
	if ($user_delete_sale == 'true'){
		$user_delete_sale = 'checked';
	}
	
	if ($user_view_r_sale == 'true'){
		$user_view_r_sale = 'checked';
	}
	if ($user_insert_r_sale == 'true'){
		$user_insert_r_sale = 'checked';
	}
	if ($user_update_r_sale == 'true'){
		$user_update_r_sale = 'checked';
	}
	if ($user_delete_r_sale == 'true'){
		$user_delete_r_sale = 'checked';
	}

	if ($user_view_purchase == 'true'){
		$user_view_purchase = 'checked';
	}
	if ($user_insert_purchase == 'true'){
		$user_insert_purchase = 'checked';
	}
	if ($user_update_purchase == 'true'){
		$user_update_purchase = 'checked';
	}
	if ($user_delete_purchase == 'true'){
		$user_delete_purchase = 'checked';
	}
	
	if ($user_view_r_purchase == 'true'){
		$user_view_r_purchase = 'checked';
	}
	if ($user_insert_r_purchase == 'true'){
		$user_insert_r_purchase = 'checked';
	}
	if ($user_update_r_purchase == 'true'){
		$user_update_r_purchase = 'checked';
	}
	if ($user_delete_r_purchase == 'true'){
		$user_delete_r_purchase = 'checked';
	}
	
	if ($user_view_income == 'true'){
		$user_view_income = 'checked';
	}
	if ($user_insert_income == 'true'){
		$user_insert_income = 'checked';
	}
	if ($user_update_income == 'true'){
		$user_update_income = 'checked';
	}
	if ($user_delete_income == 'true'){
		$user_delete_income = 'checked';
	}

	if ($user_view_outcome == 'true'){
		$user_view_outcome = 'checked';
	}
	if ($user_insert_outcome == 'true'){
		$user_insert_outcome = 'checked';
	}
	if ($user_update_outcome == 'true'){
		$user_update_outcome = 'checked';
	}
	if ($user_delete_outcome == 'true'){
		$user_delete_outcome = 'checked';
	}
	
	if ($user_view_receipt == 'true'){
		$user_view_receipt = 'checked';
	}
	if ($user_insert_receipt == 'true'){
		$user_insert_receipt = 'checked';
	}
	if ($user_update_receipt == 'true'){
		$user_update_receipt = 'checked';
	}
	if ($user_delete_receipt == 'true'){
		$user_delete_receipt = 'checked';
	}
	
	if ($user_view_payment == 'true'){
		$user_view_payment = 'checked';
	}
	if ($user_insert_payment == 'true'){
		$user_insert_payment = 'checked';
	}
	if ($user_update_payment == 'true'){
		$user_update_payment = 'checked';
	}
	if ($user_delete_payment == 'true'){
		$user_delete_payment = 'checked';
	}

	if ($user_all_branches == 'true'){
		$user_all_branches = 'checked';
	}
	if ($user_journal == 'true'){
		$user_journal = 'checked';
	}
	if ($user_export_journal == 'true'){
		$user_export_journal = 'checked';
	}
	if ($user_loss_profit == 'true'){
		$user_loss_profit = 'checked';
	}
	if ($user_users == 'true'){
		$user_users = 'checked';
	}
	if ($user_backup == 'true'){
		$user_backup = 'checked';
	}
	if ($user_restore == 'true'){
		$user_restore = 'checked';
	}

	if ( !( $authnication_user_users == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}

	if ( !($response =select_branches()) ){
		$response ='16000';
		die(json_encode($response));
	}
	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	$branches ='';
	$data =$response['data'];
	
	while($row= $data->fetch_assoc()){
		
		$branch = $row['c_Branch'];
		
		if ($user_branch==$branch){
			$selected='SELECTED';
		}else{
			$selected='';
		}
		
		$branches .="<option value='$branch' $selected>$branch</option>";
		
	}


	$response['error'] ='0';
	$response['data']=
			'<form class="insert-user-modal user-modal modal" onsubmit="event.preventDefault();remove_focus();update_user();">
			<input type="submit" style="display:none;">

				
				<div class="header">
					
					<div class="logo">
					<img src="logo.png" >
					</div>
					
					<i onclick="update_user();" class="fas fa-check insert-btn"></i>
					<i onclick="cancel_user_modal();" class="fas fa-times cancel-btn"></i>
					
				</div>
		
					<input id="user_id" type="hidden" value="'.$user_id.'">

		
				<div class="input-container">
				
					<h5>
					Update User
					</h5>
					
					<section class="required">
					<h6>Name:</h6>
					<input id="user_name" class="autofocus" type="text" value="'.$user_name.'" readonly>
					</section>

					<section  class="required">
					<h6>Password:</h6>
					<input id="user_password" type="password">
					</section>
					
					<section>
					<h6>Branch:</h6>
					<select id="user_branch">
					'.$branches.'
					</select>
					</section>
					
					<div>
					<h6>Accounts :</h6>
					<label>View
					<input id="user_view_account" type="checkbox" '.$user_view_account.'>
					</label>
					
					<label>New
					<input id="user_insert_account" type="checkbox" '.$user_insert_account.'>
					</label>
					
					<label>Update
					<input id="user_update_account" type="checkbox" '.$user_update_account.'>
					</label>
					
					<label>Delete
					<input id="user_delete_account" type="checkbox"  '.$user_delete_account.'>
					</label>
					
					<label>Export
					<input id="user_export_accounts" type="checkbox"  '.$user_export_accounts.'>
					</label>
					
					</div>
					
					<div>
					<h6>Stock :</h6>
					<label>View
					<input id="user_view_stock" type="checkbox" '.$user_view_stock.'>
					</label>
					
					<label>New
					<input id="user_insert_stock" type="checkbox" '.$user_insert_stock.'>
					</label>
					
					<label>Update
					<input id="user_update_stock" type="checkbox" '.$user_update_stock.'>
					</label>
					
					<label>Delete
					<input id="user_delete_stock" type="checkbox" '.$user_delete_stock.'>
					</label>
					
					<label>Cost
					<input id="user_cost" type="checkbox" '.$user_cost.'>
					</label>
					
					<label>All Items
					<input id="user_all_items" type="checkbox" '.$user_all_items.'>
					</label>
					
					<label>Export
					<input id="user_export_stock" type="checkbox" '.$user_export_stock.'>
					</label>
					
					</div>
					
					<div>
					<h6>Sale :</h6>
					<label>View
					<input id="user_view_sale" type="checkbox" '.$user_view_sale.'>
					</label>
					
					<label>New
					<input id="user_insert_sale" type="checkbox" '.$user_insert_sale.'>
					</label>
					
					<label>Update
					<input id="user_update_sale" type="checkbox" '.$user_update_sale.'>
					</label>
					
					<label>Delete
					<input id="user_delete_sale" type="checkbox" '.$user_delete_sale.'>
					</label>
					
					</div>
					
					<div>
					<h6>R Sale :</h6>
					<label>View
					<input id="user_view_r_sale" type="checkbox" '.$user_view_r_sale.'>
					</label>
					
					<label>New
					<input id="user_insert_r_sale" type="checkbox" '.$user_insert_r_sale.'>
					</label>
					
					<label>Update
					<input id="user_update_r_sale" type="checkbox" '.$user_update_r_sale.'>
					</label>
					
					<label>Delete
					<input id="user_delete_r_sale" type="checkbox" '.$user_delete_r_sale.'>
					</label>
					
					</div>
					
					<div>
					<h6>Purchase :</h6>
					<label>View
					<input id="user_view_purchase" type="checkbox" '.$user_view_purchase.'>
					</label>
					
					<label>New
					<input id="user_insert_purchase" type="checkbox" '.$user_update_purchase.'>
					</label>
					
					<label>Update
					<input id="user_update_purchase" type="checkbox" '.$user_delete_purchase.'>
					</label>
					
					<label>Delete
					<input id="user_delete_purchase" type="checkbox" '.$user_delete_purchase.'>
					</label>
					
					</div>
					
					<div>
					<h6>R Purchase :</h6>
					<label>View
					<input id="user_view_r_purchase" type="checkbox" '.$user_view_r_purchase.'>
					</label>
					
					<label>New
					<input id="user_insert_r_purchase" type="checkbox" '.$user_insert_r_purchase.'>
					</label>
					
					<label>Update
					<input id="user_update_r_purchase" type="checkbox" '.$user_update_r_purchase.'>
					</label>
					
					<label>Delete
					<input id="user_delete_r_purchase" type="checkbox" '.$user_delete_r_purchase.'>
					</label>
					
					</div>
					
					<div>
					<h6>Income :</h6>
					<label>View
					<input id="user_view_income" type="checkbox" '.$user_view_income.'>
					</label>
					
					<label>New
					<input id="user_insert_income" type="checkbox" '.$user_insert_income.'>
					</label>
					
					<label>Update
					<input id="user_update_income" type="checkbox" '.$user_update_income.'>
					</label>
					
					<label>Delete
					<input id="user_delete_income" type="checkbox" '.$user_delete_income.'>
					</label>
					
					</div>
					
					<div>
					<h6>Outcome :</h6>
					<label>View
					<input id="user_view_outcome" type="checkbox" '.$user_view_outcome.'>
					</label>
					
					<label>New
					<input id="user_insert_outcome" type="checkbox" '.$user_insert_outcome.'>
					</label>
					
					<label>Update
					<input id="user_update_outcome" type="checkbox" '.$user_update_outcome.'>
					</label>
					
					<label>Delete
					<input id="user_delete_outcome" type="checkbox" '.$user_delete_outcome.'>
					</label>

					</div>
					
					<div>
					<h6>Receipt :</h6>
					<label>View
					<input id="user_view_receipt" type="checkbox" '.$user_view_receipt.'>
					</label>
					
					<label>New
					<input id="user_insert_receipt" type="checkbox" '.$user_insert_receipt.'>
					</label>
					
					<label>Update
					<input id="user_update_receipt" type="checkbox" '.$user_update_receipt.'>
					</label>
					
					<label>Delete
					<input id="user_delete_receipt" type="checkbox" '.$user_delete_receipt.'>
					</label>
	
					</div>
					
					<div>
					<h6>Payment :</h6>
					<label>View
					<input id="user_view_payment" type="checkbox" '.$user_view_payment.'>
					</label>
					
					<label>New
					<input id="user_insert_payment" type="checkbox" '.$user_insert_payment.'>
					</label>
					
					<label>Update
					<input id="user_update_payment" type="checkbox" '.$user_update_payment.'>
					</label>
					
					<label>Delete
					<input id="user_delete_payment" type="checkbox" '.$user_delete_payment.'>
					</label>
					
					</div>
					
					<div>
					<h6>Other :</h6>
				
					<label>All Branches
					<input id="user_all_branches" type="checkbox" '.$user_all_branches.'>
					</label>
					
					<label>Journal
					<input id="user_journal" type="checkbox" '.$user_journal.'>
					</label>
					
					<label>Export Journal
					<input id="user_export_journal" type="checkbox" '.$user_export_journal.'>
					</label>
					
					
					<label>Loss Profit
					<input id="user_loss_profit" type="checkbox" '.$user_loss_profit.'>
					</label>
					
					
					<label>Users
					<input id="user_users" type="checkbox" '.$user_users.'>
					</label>

					
					<label>BackUp
					<input id="user_backup" type="checkbox" '.$user_backup.'>
					</label>
					
					<label>Restore
					<input id="user_restore" type="checkbox" '.$user_restore.'>
					</label>

					</div>

					<i onclick="update_user();" class="fas fa-check insert-btn"></i>
					<i onclick="cancel_user_modal();" class="fas fa-times cancel-btn"></i>

				</div>

			</form>';
	die(json_encode($response));
	
}


$response['error'] ='1500';
die(json_encode($response));
?>