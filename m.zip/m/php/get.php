<?php
#t_accounts
function select_accounts( $search_branch, $account, $type, $order )
{
	
	require 'connection.php'; 
	
	$search_branch ='%'.$search_branch.'%';
	$account ='%'.$account.'%';
	$type ='%'.$type.'%';
	
	if ( $order!='DESC' && $order!='ASC' ){
		$order= 'DESC';
	}
	
	if ( !( $sql =$connection ->prepare("SELECT * FROM t_accounts WHERE c_Branch LIKE ? AND c_Name LIKE ? AND c_Type LIKE ? ORDER BY ( c_OpeningBalance+(c_Debit-c_Credit) ) $order;") ) ){
		$response['error'] ='11500';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'sss', $search_branch, $account, $type )  ) ){
		$response['error'] ='11501';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='11502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='11503';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
function select_user_accounts( $search_branch, $account, $type, $order, $branch )
{
	
	require 'connection.php'; 
	
	$search_branch ='%'.$search_branch.'%';
	$account ='%'.$account.'%';
	$type ='%'.$type.'%';
	
	if ( $order!='DESC' && $order!='ASC' ){
		$order= 'DESC';
	}
	
	if ( !( $sql =$connection ->prepare("SELECT * FROM t_accounts WHERE c_Branch= ? AND c_Branch LIKE ? AND c_Name LIKE ? AND c_Type LIKE ? ORDER BY ( c_OpeningBalance+(c_Debit-c_Credit) ) $order;") ) ){
		$response['error'] ='11500';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'ssss', $branch, $search_branch, $account, $type )  ) ){
		$response['error'] ='11501';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='11502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='11503';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
function select_account( $id )
{
	
	require 'connection.php'; 
	
	if ( !( $sql =$connection ->prepare("SELECT * FROM t_accounts WHERE c_ID =?;") ) ){
		$response['error'] ='11600';
		return $response;
	}
	
	if ( !( $sql->bind_param( 's', $id )  ) ){
		$response['error'] ='11601';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='11602';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='11603';
		return $response;
	}
	
	if ( !( mysqli_num_rows($response['data']) ==1 ) ){
		$response['error'] ='11604';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
function select_basic_account( $type, $branch )
{
	
	require 'connection.php'; 
	
	if ( !( $sql =$connection ->prepare("SELECT * FROM t_accounts WHERE c_Basic =? AND c_Branch = ?;") ) ){
		$response['error'] ='11600';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'ss', $type , $branch )  ) ){
		$response['error'] ='11601';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='11602';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='11603';
		return $response;
	}
	
	if ( !( mysqli_num_rows($response['data']) ==1 ) ){
		$response['error'] ='11604';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
function select_account_type_balance( $search_branch, $account_type )
{
	
	require 'connection.php'; 
	
	$search_branch ='%'.$search_branch.'%';
	
	
	if ( !( $sql =$connection ->prepare("SELECT IFNULL( SUM( (c_Debit+c_OpeningBalance)-c_Credit ), 0 ) AS s_Balance FROM t_accounts WHERE c_Branch LIKE ? AND c_Type = ?;") ) ){
		$response['error'] ='11500';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'ss', $search_branch, $account_type )  ) ){
		$response['error'] ='11501';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='11502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='11503';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
function select_user_account_type_balance( $search_branch, $account_type, $branch )
{
	
	require 'connection.php'; 
	
	$search_branch ='%'.$search_branch.'%';
	
	if ( !( $sql =$connection ->prepare("SELECT IFNULL( SUM( (c_Debit+c_OpeningBalance)-c_Credit ), 0 ) AS s_Balance FROM t_accounts WHERE c_Branch = ? AND c_Branch LIKE ? AND c_Type = ?;") ) ){
		$response['error'] ='11500';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'sss', $branch, $search_branch, $account_type )  ) ){
		$response['error'] ='11501';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='11502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='11503';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
#t_payments
function select_payments( $search_branch, $id, $account, $type, $order )
{
	
	require 'connection.php'; 
	
	$search_branch ='%'.$search_branch.'%';
	$id ='%'.$id.'%';
	$account ='%'.$account.'%';
	$type ='%'.$type.'%';

	if ( $order!='DESC' && $order!='ASC' ){
		$order= 'DESC';
	}

	if ( !( $sql =$connection ->prepare("SELECT * FROM t_payments WHERE c_Branch LIKE ? AND c_ID LIKE ? AND c_AccountName LIKE ? AND c_Type LIKE ? ORDER BY c_ID $order;") ) ){
		$response['error'] ='12500';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'ssss', $search_branch, $id, $account, $type )  ) ){
		$response['error'] ='12501';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='12502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='12503';
		return $response;
	}

	
	$response['error'] ='0';
	return $response;
	
}
function select_user_payments( $search_branch, $id, $account, $type, $order, $branch )
{
	
	require 'connection.php'; 
	
	$search_branch ='%'.$search_branch.'%';
	$id ='%'.$id.'%';
	$account ='%'.$account.'%';
	$type ='%'.$type.'%';

	if ( $order!='DESC' && $order!='ASC' ){
		$order= 'DESC';
	}
	if ( !( $sql =$connection ->prepare("SELECT * FROM t_payments WHERE c_Branch = ? AND c_Branch LIKE ? AND c_ID LIKE ? AND c_AccountName LIKE ? AND c_Type LIKE ? ORDER BY c_ID $order;") ) ){
		$response['error'] ='12500';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'sssss', $branch, $search_branch, $id, $account, $type )  ) ){
		$response['error'] ='12501';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='12502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='12503';
		return $response;
	}

	
	$response['error'] ='0';
	return $response;
	
}
function select_payment( $id )
{
	
	require 'connection.php'; 
	
	if ( !( $sql =$connection ->prepare("SELECT * FROM t_payments WHERE c_ID =?;") ) ){
		$response['error'] ='12600';
		return $response;
	}
	
	if ( !( $sql->bind_param( 's', $id )  ) ){
		$response['error'] ='12601';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='12602';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='12603';
		return $response;
	}
	
	if ( !( mysqli_num_rows($response['data']) >0 ) ){
		$response['error'] ='12604';
		return $response;
	}
	
	
	$response['error'] ='0';
	return $response;
	
}
#t_invoices
function select_invoices( $search_branch, $id, $account, $type, $order )
{
	
	require 'connection.php'; 

	$search_branch ='%'.$search_branch.'%';
	$id ='%'.$id.'%';
	$account ='%'.$account.'%';
	$type ='%'.$type.'%';

	if ( $order!='DESC' && $order!='ASC' ){
		$order= 'DESC';
	}
	
	if ( !( $sql =$connection ->prepare("SELECT * FROM t_invoices WHERE c_Branch LIKE ? AND c_id LIKE ? AND c_AccountName LIKE ? AND c_Type LIKE ? ORDER BY c_ID $order;") ) ){
		$response['error'] ='13500';
		return $response;
	}

	if ( !( $sql->bind_param( 'ssss', $search_branch, $id, $account, $type )  ) ){
		$response['error'] ='13501';
		return $response;
	}

	if ( !( $sql->execute() )){
		$response['error'] ='13502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='13503';
		return $response;
	}

	$response['error'] ='0';
	return $response;
	
}
function select_user_invoices( $search_branch, $id, $account, $type, $order, $branch )
{
	
	require 'connection.php'; 

	$search_branch ='%'.$search_branch.'%';
	$id ='%'.$id.'%';
	$account ='%'.$account.'%';
	$type ='%'.$type.'%';

	if ( $order!='DESC' && $order!='ASC' ){
		$order= 'DESC';
	}

	if ( !( $sql =$connection ->prepare("SELECT * FROM t_invoices WHERE c_Branch = ? AND c_Branch LIKE ? AND c_ID LIKE ? AND c_AccountName LIKE ? AND c_Type LIKE ? ORDER BY c_ID $order;") ) ){
		$response['error'] ='13500';
		return $response;
	}

	if ( !( $sql->bind_param( 'sssss', $branch, $search_branch, $id, $account, $type )  ) ){
		$response['error'] ='13501';
		return $response;
	}

	if ( !( $sql->execute() )){
		$response['error'] ='13502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='13503';
		return $response;
	}

	$response['error'] ='0';
	return $response;
	
}
function select_invoice( $id )
{
	
	require 'connection.php'; 
	
	if ( !( $sql =$connection ->prepare("SELECT * FROM t_invoices WHERE c_ID =?;") ) ){
		$response['error'] ='13600';
		return $response;
	}
	
	if ( !( $sql->bind_param( 's', $id )  ) ){
		$response['error'] ='13601';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='13602';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='13603';
		return $response;
	}
	
	if ( !( mysqli_num_rows($response['data']) >0 ) ){
		$response['error'] ='13604';
		return $response;
	}
	
	
	$response['error'] ='0';
	return $response;
	
}
function select_invoices_profit( $search_branch, $from, $to )
{
	
	require 'connection.php'; 

	$search_branch ='%'.$search_branch.'%';

	if ($from==''){
		$from="0000-00-00";
	}
	
	$from=date_create($from);
	$from = date_format($from,"Y-m-d");
	
	$to=date_create($to);
	$to= date_format($to,"Y-m-d");
	
	if ( !( $sql =$connection ->prepare("SELECT IFNULL( ( SUM( CASE WHEN c_Type = 'Income' THEN c_Total - c_Discount END ) ), 0) as s_Income, IFNULL( ( SUM( CASE WHEN c_Type = 'Outcome' THEN c_Total - c_Discount END ) ), 0) as s_Outcome FROM t_invoices WHERE c_Branch Like ? AND ( c_Date BETWEEN ? AND ? );") ) ){
		$response['error'] ='13500';
		return $response;
	}

	if ( !( $sql->bind_param( 'sss', $search_branch, $from, $to )  ) ){
		$response['error'] ='13501';
		return $response;
	}

	if ( !( $sql->execute() )){
		$response['error'] ='13502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='13503';
		return $response;
	}

	$response['error'] ='0';
	return $response;
	
}
function select_user_invoices_profit( $search_branch, $from, $to, $branch )
{
	
	require 'connection.php'; 

	$search_branch ='%'.$search_branch.'%';
	
	if ($from==''){
		$from="0000-00-00";
	}
	
	$from=date_create($from);
	$from = date_format($from,"Y-m-d");
	
	$to=date_create($to);
	$to= date_format($to,"Y-m-d");

	if ( !( $sql =$connection ->prepare("SELECT IFNULL( ( SUM( CASE WHEN c_Type = 'Income' THEN c_Total - c_Discount END ) ), 0) as s_Income, IFNULL( ( SUM( CASE WHEN c_Type = 'Outcome' THEN c_Total - c_Discount END ) ), 0) as s_Outcome FROM t_invoices WHERE c_Branch = ? AND c_Branch Like ? AND ( c_Date BETWEEN ? AND ? );") ) ){
		$response['error'] ='13500';
		return $response;
	}

	if ( !( $sql->bind_param( 'ssss', $branch, $search_branch, $from, $to )  ) ){
		$response['error'] ='13501';
		return $response;
	}

	if ( !( $sql->execute() )){
		$response['error'] ='13502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='13503';
		return $response;
	}

	$response['error'] ='0';
	return $response;
	
}
#t_items
function select_invoice_items( $invoice_id )
{
	
	require 'connection.php'; 
	
	if ( !( $sql =$connection ->prepare("SELECT * FROM t_items WHERE c_InvoiceID =?;") ) ){
		$response['error'] ='14600';
		return $response;
	}
	
	if ( !( $sql->bind_param( 's', $invoice_id )  ) ){
		$response['error'] ='14601';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='14602';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='14603';
		return $response;
	}

	
	$response['error'] ='0';
	return $response;
	
}
function select_product_items( $product_id )
{
	
	require 'connection.php'; 
	
	if ( !( $sql =$connection ->prepare("SELECT * FROM t_items WHERE c_StockID =? ORDER BY c_InvoiceID DESC;") ) ){
		$response['error'] ='17600';
		return $response;
	}
	
	if ( !( $sql->bind_param( 's', $product_id )  ) ){
		$response['error'] ='17601';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='17602';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='17603';
		return $response;
	}
	

	
	
	$response['error'] ='0';
	return $response;
	
}
function select_account_items( $account_id )
{
	
	require 'connection.php'; 
	
	if ( !( $sql =$connection ->prepare("SELECT * FROM t_items WHERE c_AccountID =? ORDER BY c_InvoiceID DESC;") ) ){
		$response['error'] ='17600';
		return $response;
	}
	
	if ( !( $sql->bind_param( 's', $account_id )  ) ){
		$response['error'] ='17601';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='17602';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='17603';
		return $response;
	}
	

	
	
	$response['error'] ='0';
	return $response;
	
}
function select_all_items( $search_branch, $from, $to, $product, $category1, $category2, $category3, $category4, $category5, $category6, $category7, $category8 )
{
	
	require 'connection.php'; 

	$search_branch ='%'.$search_branch.'%';
	$product ='%'.$product.'%';
	$category1 ='%'.$category1.'%';
	$category2 ='%'.$category2.'%';
	$category3 ='%'.$category3.'%';
	$category4 ='%'.$category4.'%';
	$category5 ='%'.$category5.'%';
	$category6 ='%'.$category6.'%';
	$category7 ='%'.$category7.'%';
	$category8 ='%'.$category8.'%';
	
	if ($from==''){
		$from="0000-00-00";
	}

	$from=date_create($from);
	$from = date_format($from,"Y-m-d");
	
	$to=date_create($to);
	$to= date_format($to,"Y-m-d");

	
	if ( !( $sql =$connection ->prepare("SELECT * FROM t_items WHERE c_Branch LIKE ? AND ( c_InvoiceDate BETWEEN ? AND ? ) AND c_StockName LIKE ? AND c_StockCategory1 LIKE ? AND c_StockCategory2 LIKE ? AND c_StockCategory3 LIKE ? AND c_StockCategory4 LIKE ? AND c_StockCategory5 LIKE ? AND c_StockCategory6 LIKE ? AND c_StockCategory7 LIKE ? AND c_StockCategory8 LIKE ? ORDER BY c_InvoiceID DESC;") ) ){
		$response['error'] ='15500';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'ssssssssssss', $search_branch, $from, $to, $product, $category1, $category2, $category3, $category4, $category5, $category6, $category7, $category8 )  ) ){
		$response['error'] ='15501';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='15502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='15503';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
function select_user_all_items( $search_branch, $from, $to, $product, $category1, $category2, $category3, $category4, $category5, $category6, $category7, $category8, $branch )
{
	
	require 'connection.php'; 

	$search_branch ='%'.$search_branch.'%';
	$product ='%'.$product.'%';
	$category1 ='%'.$category1.'%';
	$category2 ='%'.$category2.'%';
	$category3 ='%'.$category3.'%';
	$category4 ='%'.$category4.'%';
	$category5 ='%'.$category5.'%';
	$category6 ='%'.$category6.'%';
	$category7 ='%'.$category7.'%';
	$category8 ='%'.$category8.'%';
	
	if ($from==''){
		$from="0000-00-00";
	}

	$from=date_create($from);
	$from = date_format($from,"Y-m-d");
	
	$to=date_create($to);
	$to= date_format($to,"Y-m-d");

	
	if ( !( $sql =$connection ->prepare("SELECT * FROM t_items WHERE c_Branch = ? AND c_Branch LIKE ? AND ( c_InvoiceDate BETWEEN ? AND ? ) AND c_StockName LIKE ? AND c_StockCategory1 LIKE ? AND c_StockCategory2 LIKE ? AND c_StockCategory3 LIKE ? AND c_StockCategory4 LIKE ? AND c_StockCategory5 LIKE ? AND c_StockCategory6 LIKE ? AND c_StockCategory7 LIKE ? AND c_StockCategory8 LIKE ? ORDER BY c_InvoiceID DESC;") ) ){
		$response['error'] ='15500';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'sssssssssssss', $branch, $search_branch, $from, $to, $product, $category1, $category2, $category3, $category4, $category5, $category6, $category7, $category8 )  ) ){
		$response['error'] ='15501';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='15502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='15503';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
function select_items_profit( $search_branch, $from, $to )
{
	
	require 'connection.php'; 

	$search_branch ='%'.$search_branch.'%';

	if ($from==''){
		$from="0000-00-00";
	}


	$from=date_create($from);
	$from = date_format($from,"Y-m-d");
	
	$to=date_create($to);
	$to= date_format($to,"Y-m-d");

	
	if ( !( $sql =$connection ->prepare("SELECT IFNULL( ( SUM( Case WHEN c_InvoiceType = 'Sale' THEN ( ( c_Price - ( c_Price* ( c_Discount/100 ) ) ) - c_StockAverageCost ) * c_Qty END) ), 0) as s_SaleProfit, IFNULL( ( SUM( Case WHEN c_InvoiceType = 'R Sale' THEN ( ( c_Price - ( c_Price* ( c_Discount/100 ) ) ) - c_StockAverageCost ) * c_Qty END) ), 0) as s_RSaleProfit FROM t_items WHERE c_Branch Like ? AND ( c_InvoiceDate BETWEEN ? AND ? );") ) ){
		$response['error'] ='15500';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'sss', $search_branch, $from, $to )  ) ){
		$response['error'] ='15501';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='15502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='15503';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
function select_user_items_profit( $search_branch, $from, $to, $branch )
{
	
	require 'connection.php'; 

	$search_branch ='%'.$search_branch.'%';

	if ($from==''){
		$from="0000-00-00";
	}

	$from=date_create($from);
	$from = date_format($from,"Y-m-d");
	
	$to=date_create($to);
	$to= date_format($to,"Y-m-d");

	
	if ( !( $sql =$connection ->prepare("SELECT IFNULL( ( SUM( Case WHEN c_InvoiceType = 'Sale' THEN ( ( c_Price - ( c_Price* ( c_Discount/100 ) ) ) - c_StockAverageCost ) * c_Qty END) ), 0) as s_SaleProfit, IFNULL( ( SUM( Case WHEN c_InvoiceType = 'R Sale' THEN ( ( c_Price - ( c_Price* ( c_Discount/100 ) ) ) - c_StockAverageCost ) * c_Qty END) ), 0) as s_RSaleProfit FROM t_items WHERE c_Branch = ? AND c_Branch Like ? AND ( c_InvoiceDate BETWEEN ? AND ? );") ) ){
		$response['error'] ='15500';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'ssss', $branch, $search_branch, $from, $to )  ) ){
		$response['error'] ='15501';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='15502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='15503';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
#t_stock
function select_products( $search_branch, $product, $category1, $category2, $category3, $category4, $category5, $category6, $category7, $category8, $order )
{
	
	require 'connection.php'; 

	$search_branch ='%'.$search_branch.'%';
	$product ='%'.$product.'%';
	$category1 ='%'.$category1.'%';
	$category2 ='%'.$category2.'%';
	$category3 ='%'.$category3.'%';
	$category4 ='%'.$category4.'%';
	$category5 ='%'.$category5.'%';
	$category6 ='%'.$category6.'%';
	$category7 ='%'.$category7.'%';
	$category8 ='%'.$category8.'%';
	
	if ( $order!='DESC' && $order!='ASC' ){
		$order= 'DESC';
	}

	if ( !( $sql =$connection ->prepare("SELECT * FROM t_stock WHERE c_Branch LIKE ? AND c_Name LIKE ? AND c_Category1 LIKE ? AND c_Category2 LIKE ? AND c_Category3 LIKE ? AND c_Category4 LIKE ? AND c_Category5 LIKE ? AND c_Category6 LIKE ? AND c_Category7 LIKE ? AND c_Category8 LIKE ? ORDER BY ( c_OpeningQty+(c_PurchaseQty-c_SaleQty) ) $order;") ) ){
		$response['error'] ='15500';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'ssssssssss', $search_branch, $product, $category1, $category2, $category3, $category4, $category5, $category6, $category7, $category8 )  ) ){
		$response['error'] ='15501';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='15502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='15503';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
function select_user_products( $search_branch, $product, $category1, $category2, $category3, $category4, $category5, $category6, $category7, $category8, $order, $branch )
{
	
	require 'connection.php'; 

	$search_branch ='%'.$search_branch.'%';
	$product ='%'.$product.'%';
	$category1 ='%'.$category1.'%';
	$category2 ='%'.$category2.'%';
	$category3 ='%'.$category3.'%';
	$category4 ='%'.$category4.'%';
	$category5 ='%'.$category5.'%';
	$category6 ='%'.$category6.'%';
	$category7 ='%'.$category7.'%';
	$category8 ='%'.$category8.'%';
	
	if ( $order!='DESC' && $order!='ASC' ){
		$order= 'DESC';
	}
	
	if ( !( $sql =$connection ->prepare("SELECT * FROM t_stock WHERE c_Branch = ? AND c_Branch LIKE ? AND c_Name LIKE ? AND c_Category1 LIKE ? AND c_Category2 LIKE ? AND c_Category3 LIKE ? AND c_Category4 LIKE ? AND c_Category5 LIKE ? AND c_Category6 LIKE ? AND c_Category7 LIKE ? AND c_Category8 LIKE ? ORDER BY ( c_OpeningQty+(c_PurchaseQty-c_SaleQty) ) $order;") ) ){
		$response['error'] ='15500';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'sssssssssss', $branch, $search_branch, $product, $category1, $category2, $category3, $category4, $category5, $category6, $category7, $category8 )  ) ){
		$response['error'] ='15501';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='15502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='15503';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
function select_product( $id )
{
	
	require 'connection.php'; 
	
	if ( !( $sql =$connection ->prepare("SELECT * FROM t_stock WHERE c_ID =?;") ) ){
		$response['error'] ='15600';
		return $response;
	}
	
	if ( !( $sql->bind_param( 's', $id )  ) ){
		$response['error'] ='15601';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='15602';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='15603';
		return $response;
	}
	
	if ( !( mysqli_num_rows($response['data']) >0 ) ){
		$response['error'] ='15604';
		return $response;
	}
	
	
	$response['error'] ='0';
	return $response;
	
}
function select_inventory( $search_branch )
{
	
	require 'connection.php'; 

	$search_branch ='%'.$search_branch.'%';
	
	if ( !( $sql =$connection ->prepare("SELECT IFNULL( SUM( ( (c_PurchaseQty+c_OpeningQty)-(c_SaleQty) ) * c_AverageCost ), 0) AS s_Inventory FROM t_stock WHERE c_Branch LIKE ?") ) ){
		$response['error'] ='15500';
		return $response;
	}
	
	if ( !( $sql->bind_param( 's', $search_branch )  ) ){
		$response['error'] ='15501';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='15502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='15503';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
function select_user_inventory( $search_branch, $branch )
{
	
	require 'connection.php'; 

	$search_branch ='%'.$search_branch.'%';

	if ( !( $sql =$connection ->prepare("SELECT IFNULL( SUM( ( (c_PurchaseQty+c_OpeningQty)-(c_SaleQty) ) * c_AverageCost ), 0) AS s_Inventory FROM t_stock WHERE c_Branch = ? AND c_Branch LIKE ?") ) ){
		$response['error'] ='15500';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'ss', $branch, $search_branch )  ) ){
		$response['error'] ='15501';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='15502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='15503';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
#t_journal
function select_journal( $search_branch, $from, $to, $account, $type, $order )
{
	
	require 'connection.php'; 

	$search_branch ='%'.$search_branch.'%';
	$account ='%'.$account.'%';
	$type ='%'.$type.'%';

	if ($from==''){
		$from="0000-00-00";
	}
	
	$from=date_create($from);
	$from = date_format($from,"Y-m-d");
	
	$to=date_create($to);
	$to= date_format($to,"Y-m-d");
	
	if ( $order!='DESC' && $order!='ASC' ){
		$order= 'DESC';
	}

	if ( !( $sql =$connection ->prepare("SELECT * FROM t_journal WHERE c_Branch LIKE ? AND ( c_Date BETWEEN ? AND ? ) AND c_AccountName LIKE ? AND c_Type LIKE ? ORDER BY c_Date $order, c_ID $order;") ) ){
		$response['error'] ='17500';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'sssss', $search_branch, $from, $to, $account, $type )  ) ){
		$response['error'] ='17501';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='17502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='17503';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
function select_user_journal( $search_branch, $from, $to, $account, $type, $order, $branch )
{
	
	require 'connection.php'; 

	$search_branch ='%'.$search_branch.'%';
	$account ='%'.$account.'%';
	$type ='%'.$type.'%';

	if ($from==''){
		$from="0000-00-00";
	}
	
	$from=date_create($from);
	$from = date_format($from,"Y-m-d");
	
	$to=date_create($to);
	$to= date_format($to,"Y-m-d");	
	
	if ( $order!='DESC' && $order!='ASC' ){
		$order= 'DESC';
	}

	if ( !( $sql =$connection ->prepare("SELECT * FROM t_journal WHERE c_Branch = ? AND c_Branch LIKE ? AND ( c_Date BETWEEN ? AND ? ) AND c_AccountName LIKE ? AND c_Type LIKE ? ORDER BY c_Date $order, c_ID $order;") ) ){
		$response['error'] ='17500';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'ssssss', $branch, $search_branch, $from, $to, $account, $type )  ) ){
		$response['error'] ='17501';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='17502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='17503';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
function select_total( $from_date, $to_date, $this_user )
{
	
	require 'connection.php'; 

	if ( !( $sql =$connection ->prepare("
	
	SELECT c_ID, (c_Total-c_Discount) as c_Total, c_Type, c_Date, c_DriverName, c_AccountName FROM `t_invoices` WHERE c_DriverID = ? AND c_Date>= ? AND c_Date<= ? AND c_Active = 'false'
	UNION
	SELECT c_ID, c_Ammount, c_Type, c_Date, c_DriverName, c_AccountName FROM `t_payments` WHERE c_DriverID = ? AND c_Date>= ? AND c_Date<= ? AND c_Active = 'false';
	
	") ) ){
		$response['error'] ='17500';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'ssssss', $this_user, $from_date, $to_date, $this_user, $from_date, $to_date )  ) ){
		$response['error'] ='17501';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='17502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='17503';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
function select_account_journal( $account_id )
{
	
	require 'connection.php'; 
	
	if ( !( $sql =$connection ->prepare("SELECT * FROM t_journal WHERE c_AccountID =? ORDER BY c_ID DESC;") ) ){
		$response['error'] ='17600';
		return $response;
	}
	
	if ( !( $sql->bind_param( 's', $account_id )  ) ){
		$response['error'] ='17601';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='17602';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='17603';
		return $response;
	}
	

	
	
	$response['error'] ='0';
	return $response;
	
}
function select_expense_total( $search_branch, $from, $to )
{
	
	require 'connection.php'; 
	
	$search_branch ='%'.$search_branch.'%';
	
	if ($from==''){
		$from="0000-00-00";
	}
	
	$from=date_create($from);
	$from = date_format($from,"Y-m-d");
	
	$to=date_create($to);
	$to= date_format($to,"Y-m-d");
	
	
	if ( !( $sql =$connection ->prepare("SELECT IFNULL( SUM( c_Debit-c_Credit ), 0 ) AS s_Total FROM t_journal WHERE c_Branch LIKE ? AND c_AccountType = 'Expense' AND ( c_Date BETWEEN ? AND ? );") ) ){
		$response['error'] ='11500';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'sss', $search_branch, $from, $to )  ) ){
		$response['error'] ='11501';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='11502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='11503';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
function select_user_expense_total( $search_branch, $from, $to, $branch )
{
	
	require 'connection.php'; 
	
	$search_branch ='%'.$search_branch.'%';
	
	if ($from==''){
		$from="0000-00-00";
	}
	
	$from=date_create($from);
	$from = date_format($from,"Y-m-d");
	
	$to=date_create($to);
	$to= date_format($to,"Y-m-d");
	
	
	if ( !( $sql =$connection ->prepare("SELECT IFNULL( SUM( c_Debit-c_Credit ), 0 ) AS s_Total FROM t_journal WHERE c_Branch = ? AND c_Branch LIKE ? AND c_AccountType = 'Expense' AND ( c_Date BETWEEN ? AND ? );") ) ){
		$response['error'] ='11500';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'ssss', $branch, $search_branch, $from, $to )  ) ){
		$response['error'] ='11501';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='11502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='11503';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
#t_branches
function select_branches()
{
	
	require 'connection.php'; 
	
	if ( !( $sql =$connection ->prepare("SELECT * FROM t_branches;") ) ){
		$response['error'] ='18600';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='18602';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='18603';
		return $response;
	}

	$response['error'] ='0';
	return $response;
	
}
function select_branch( $branch )
{
	
	require 'connection.php'; 
	
	if ( !( $sql =$connection ->prepare("SELECT * FROM t_branches WHERE c_Branch = ?;") ) ){
		$response['error'] ='18600';
		return $response;
	}
	
	if ( !( $sql->bind_param( 's', $branch )  ) ){
		$response['error'] ='18601';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='18602';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='18603';
		return $response;
	}


	if ( !( mysqli_num_rows($response['data']) >0 ) ){
		$response['error'] ='18604';
		return $response;
	}

	$response['error'] ='0';
	return $response;
	
}
#t_users
function select_users( $search )
{
	
	require 'connection.php'; 

	$search ='%'.$search.'%';

	if ( !( $sql =$connection ->prepare("SELECT * FROM t_users WHERE c_Name LIKE ? ORDER BY c_ID DESC;") ) ){
		$response['error'] ='18500';
		return $response;
	}
	
	if ( !( $sql->bind_param( 's', $search )  ) ){
		$response['error'] ='18501';
		return $response;
	}

	if ( !( $sql->execute() )){
		$response['error'] ='18502';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='18503';
		return $response;
	}

	$response['error'] ='0';
	return $response;
	
}
function select_user( $id )
{
	
	require 'connection.php'; 
	
	if ( !( $sql =$connection ->prepare("SELECT * FROM t_users WHERE c_ID =?;") ) ){
		$response['error'] ='18600';
		return $response;
	}
	
	if ( !( $sql->bind_param( 's', $id )  ) ){
		$response['error'] ='18601';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='18602';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='18603';
		return $response;
	}
	
	if ( !( mysqli_num_rows($response['data']) >0 ) ){
		$response['error'] ='18604';
		return $response;
	}
	

	$response['error'] ='0';
	return $response;
	
}
function check_user( $name, $my_password )
{

	require 'connection.php'; 
	
	if ( !( $sql =$connection ->prepare("SELECT * FROM t_users WHERE c_Name =? AND c_Password =?;") ) ){
		$response['error'] ='18600';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'ss', $name, $my_password )  ) ){
		$response['error'] ='18701';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='18702';
		return $response;
	}
	
	if ( !( $response['data'] =$sql->get_result() ) ){
		$response['error'] ='18703';
		return $response;
	}
	
	if ( !( mysqli_num_rows($response['data']) >0 ) ){
		$response['error'] ='18704';
		return $response;
	}
	
	
	$response['error'] ='0';
	return $response;
	
}
?>