<?php
#connection
$connection_host_name = 'localhost' ;
$connection_user_name = 'root' ;
$connection_password = '' ;
$connection_data_base = 'database3' ;
$connection = new mysqli( $connection_host_name, $connection_user_name, $connection_password, $connection_data_base );

$backup_file= dirname(__FILE__) . '/../../../../../clientbackup/'.$connection_data_base.'.sql';

#end connection
?>