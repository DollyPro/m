<?php
#t_accounts
function insert_account( $branch, $name, $type, $opening_balance, $contact, $address, $location, $memo, $user )
{
	
	require 'connection.php'; 
	
	if ( !( $sql =$connection ->prepare("INSERT INTO t_accounts (c_Branch, c_Name, c_Type, c_OpeningBalance, c_Contact, c_Address, c_Location, c_Memo, c_UserID) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ? );") ) ){
		$response['error'] ='1500';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'sssssssss', $branch, $name, $type, $opening_balance, $contact, $address, $location, $memo, $user)  ) ){
		$response['error'] ='1502';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='1503';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
function update_account( $name, $opening_balance, $contact, $address, $location, $memo, $id )
{
	
	require 'connection.php';
	
	if ( !( $sql =$connection ->prepare("UPDATE t_accounts SET c_Name = ?, c_OpeningBalance = ?, c_Contact =?, c_Address =?, c_Location =?, c_Memo =? WHERE c_ID =?") ) ){
		$response['error'] ='1601';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'sssssss', $name, $opening_balance, $contact, $address, $location, $memo, $id )  ) ){
		$response['error'] ='1602';
		return $response;
	}
	
	if ( !( $sql->execute() )){
		$response['error'] ='1603';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;

}
function delete_account( $id )
{

	require 'connection.php';
	
	if ( !( $sql =$connection ->prepare("DELETE FROM t_accounts WHERE c_ID =? AND c_Debit =0 AND c_Credit =0 AND c_Type!='Basic';") ) ){
		$response['error'] ='1701';
		return $response;
	}
	
	if ( !( $sql ->bind_param( 's', $id ) ) ){
		$response['error'] ='1702';
		return $response;
	}
	
	if ( !( $sql ->execute() ) ){
		$response['error'] ='1703';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;

}
#t_payments
function insert_payment( $account, $second_account, $type, $ammount, $memo, $user )
{
	
	require 'connection.php';
	
	if ( !( $sql =$connection ->prepare("INSERT INTO t_payments (c_AccountID, c_SecondAccountID, c_Type, c_Ammount, c_Memo, c_UserID) VALUES ( ?, ? , ?, ?, ?, ? );") ) ){
		$response['error'] ='2501';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'ssssss', $account, $second_account, $type, $ammount, $memo, $user)  ) ){
		$response['error'] ='2502';
		return $response;
	}	
	
	if ( !( $sql->execute() )){
		$response['error'] ='2503';
		$response['error'] =$connection->error;
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
function update_payment( $ammount, $memo, $id )
{
	
	require 'connection.php';
	
	if ( !( $sql =$connection ->prepare("UPDATE t_payments SET c_Ammount =?, c_Memo =? WHERE c_ID =?;") ) ){
		$response['error'] ='2601';
		return $response;
	}	

	if ( !( $sql->bind_param( 'sss', $ammount, $memo, $id)  ) ){
		$response['error'] ='2602';
		return $response;
	}	

	if ( !( $sql->execute() )){
		$response['error'] ='2603';
		return $response;
	}

	$response['error'] ='0';
	return $response;

}
function delete_payment( $id )
{

	require 'connection.php';
	
	if ( !( $sql =$connection ->prepare("DELETE FROM t_payments WHERE c_ID =?;") ) ){
		$response['error'] ='2701';
		return $response;
	}
	
	if ( !( $sql ->bind_param( 's', $id ) ) ){
		$response['error'] ='2702';
		return $response;
	}
	
	if ( !( $sql ->execute() ) ){
		$response['error'] ='2703';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;

}
#t_invoices
function insert_invoice( $account, $second_account, $type, $memo, $discount, $user )
{
	
	require 'connection.php';
	
	if ( !( $sql =$connection ->prepare("INSERT INTO t_invoices (c_AccountID, c_SecondAccountID, c_Type, c_Memo, c_Discount, c_UserID) VALUES ( ?, ?, ?, ?, ?, ? );") ) ){
		$response['error'] ='3501';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'ssssss', $account, $second_account, $type, $memo, $discount, $user )  ) ){
		$response['error'] ='3502';
		return $response;
	}	
	
	if ( !( $sql->execute() )){
		$response['error'] ='3503';
		$response['id'] ='';
		return $response;
	}

	$response['id'] =mysqli_insert_id( $connection );
	$response['error'] ='0';
	return $response;
	
}
function update_invoice( $memo, $discount, $id )
{
	
	require 'connection.php';
	
	if ( !( $sql =$connection ->prepare("UPDATE t_invoices SET c_Memo =?, c_Discount =? WHERE c_ID =? AND ( c_Type= 'Sale' OR  c_Type = 'R Sale' OR c_Type = 'Purchase' OR c_Type = 'R Purchase' ) ;") ) ){
		$response['error'] ='3601';
		return $response;
	}	

	if ( !( $sql->bind_param( 'sss', $memo, $discount, $id)  ) ){
		$response['error'] ='3602';
		return $response;
	}	

	if ( !( $sql->execute() )){
		$response['error'] ='3603';
		return $response;
	}

	$response['error'] ='0';
	return $response;

}
function insert_income( $type, $account, $second_account, $ammount, $memo, $user )
{
	
	require 'connection.php';
	
	if ( !( $sql =$connection ->prepare("INSERT INTO t_invoices ( c_Type, c_AccountID, c_SecondAccountID, c_Total, c_Memo, c_UserID ) VALUES ( ?, ?, ?, ?, ?, ? );") ) ){
		$response['error'] ='3701';
		$response['error'] =$connection ->error;
		return $response;
	}
	
	if ( !( $sql->bind_param( 'ssssss', $type, $account,  $second_account, $ammount, $memo, $user )  ) ){
		$response['error'] ='3702';
		return $response;
	}	
	
	if ( !( $sql->execute() )){
		$response['error'] ='3703';
		return $response;
	}
	
	$response['id'] =mysqli_insert_id( $connection );
	$response['error'] ='0';
	return $response;
	
}
function update_income( $ammount, $memo, $id )
{
	
	require 'connection.php';
	
	if ( !( $sql =$connection ->prepare("UPDATE t_invoices SET c_Total =?, c_Memo =? WHERE c_ID =? AND ( c_Type = 'Income' OR c_Type = 'Outcome' );") ) ){
		$response['error'] ='3801';
		return $response;
	}	

	if ( !( $sql->bind_param( 'sss', $ammount, $memo, $id)  ) ){
		$response['error'] ='3802';
		return $response;
	}	

	if ( !( $sql->execute() )){
		$response['error'] ='3803';
		return $response;
	}

	$response['error'] ='0';
	return $response;

}
function delete_invoice( $id )
{

	require 'connection.php';
	
	if ( !( $sql =$connection ->prepare("DELETE FROM t_invoices WHERE c_ID =?;") ) ){
		$response['error'] ='3901';
		return $response;
	}
	
	if ( !( $sql ->bind_param( 's', $id ) ) ){
		$response['error'] ='3902';
		return $response;
	}
	
	if ( !( $sql ->execute() ) ){
		$response['error'] ='3903';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;

}
#t_items
function insert_item( $invoice, $stock, $price, $qty, $discount )
{
	
	require 'connection.php';
	
	if ( !( $sql =$connection ->prepare("INSERT INTO t_items (c_InvoiceID, c_StockID, c_Price, c_Qty, c_Discount ) VALUES ( ?, ?, ?, ?, ? );") ) ){
		$response['error'] ='4501';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'sssss', $invoice, $stock, $price, $qty, $discount )  ) ){
		$response['error'] ='4502';
		return $response;
	}	
	
	if ( !( $sql->execute() )){
		$response['error'] ='4504';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
function delete_invoice_items( $invoice )
{

	require 'connection.php';
	
	if ( !( $sql =$connection ->prepare("DELETE FROM t_items WHERE c_InvoiceID =?;") ) ){
		$response['error'] ='4701';
		return $response;
	}
	
	if ( !( $sql ->bind_param( 's', $invoice ) ) ){
		$response['error'] ='4702';
		return $response;
	}
	
	if ( !( $sql ->execute() ) ){
		$response['error'] ='4704';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;

}
#t_stock
function insert_product( $branch, $name, $category1, $category2, $category3, $category4, $category5, $category6, $category7, $category8,  $opening_qty, $opening_cost, $price, $minimum, $maximum, $memo, $user )
{
	
	require 'connection.php';
	
	if ( !( $sql =$connection ->prepare("INSERT INTO t_stock ( c_Branch, c_Name, c_Category1, c_Category2, c_Category3, c_Category4, c_Category5, c_Category6, c_Category7, c_Category8, c_OpeningQty, c_OpeningCost, c_Price, c_Minimum, c_Maximum, c_Memo, c_UserID ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? );") ) ){
		$response['error'] ='6501';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'sssssssssssssssss', $branch, $name, $category1, $category2, $category3, $category4, $category5, $category6, $category7, $category8, $opening_qty, $opening_cost, $price, $minimum, $maximum, $memo, $user )  ) ){
		$response['error'] ='6502';
		return $response;
	}	
	
	if ( !( $sql->execute() )){
		$response['error'] ='6504';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
function update_product( $name, $category1, $category2, $category3, $category4, $category5, $category6, $category7, $category8, $opening_qty, $opening_cost, $price, $minimum, $maximum, $memo, $id )
{
	
	require 'connection.php';
	
	if ( !( $sql =$connection ->prepare("UPDATE t_stock SET c_Name =?, c_Category1 =?, c_Category2 =?, c_Category3 =?, c_Category4 =?, c_Category5 =?, c_Category6 =?, c_Category7 =?, c_Category8 =?, c_OpeningQty =?, c_OpeningCost =?, c_Price =?, c_Minimum =?, c_Maximum =?, c_Memo =? WHERE c_ID =?;") ) ){
		$response['error'] ='6601';
		$response['q'] =$connection->error;
		return $response;
	}	

	if ( !( $sql->bind_param( 'ssssssssssssssss', $name, $category1, $category2, $category3, $category4, $category5, $category6, $category7, $category8, $opening_qty, $opening_cost, $price, $minimum, $maximum, $memo, $id)  ) ){
		$response['error'] ='6602';
		return $response;
	}	

	if ( !( $sql->execute() )){
		$response['error'] ='6604';
		return $response;
	}

	$response['error'] ='0';
	return $response;

}
function delete_product( $id )
{

	require 'connection.php';
	
	if ( !( $sql =$connection ->prepare("DELETE FROM t_stock WHERE c_ID =? AND c_PurchaseQty =0 AND c_SaleQty =0 ;") ) ){
		$response['error'] ='6701';
		return $response;
	}
	
	if ( !( $sql ->bind_param( 's', $id ) ) ){
		$response['error'] ='6702';
		return $response;
	}
	
	if ( !( $sql ->execute() ) ){
		$response['error'] ='6704';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;

}
#t_stock
function insert_user( $user_name,$user_password, $user_branch, $user_view_account, $user_insert_account, $user_update_account, $user_delete_account, $user_export_accounts, $user_view_stock, $user_insert_stock, $user_update_stock, $user_delete_stock, $user_cost, $user_all_items, $user_export_stock, $user_view_sale, $user_insert_sale, $user_update_sale, $user_delete_sale, $user_view_r_sale, $user_insert_r_sale, $user_update_r_sale, $user_delete_r_sale, $user_view_purchase, $user_insert_purchase, $user_update_purchase, $user_delete_purchase, $user_view_r_purchase, $user_insert_r_purchase, $user_update_r_purchase, $user_delete_r_purchase, $user_view_income, $user_insert_income, $user_update_income, $user_delete_income, $user_view_outcome, $user_insert_outcome, $user_update_outcome, $user_delete_outcome, $user_view_receipt, $user_insert_receipt, $user_update_receipt, $user_delete_receipt, $user_view_payment, $user_insert_payment, $user_update_payment, $user_delete_payment, $user_all_branches, $user_journal, $user_export_journal, $user_loss_profit, $user_users, $user_backup, $user_restore )
{
	
	require 'connection.php';
	
	$user_password = hash('sha256', $user_password);
	
	if ( !( $sql =$connection ->prepare("INSERT INTO `t_users` ( `c_Name`, `c_Password`, `c_Branch`, `c_ViewAccount`, `c_InsertAccount`, `c_UpdateAccount`, `c_DeleteAccount`, `c_ExportAccounts`, `c_ViewStock`, `c_InsertStock`, `c_UpdateStock`, `c_DeleteStock`, `c_Cost`, `c_AllItems`, `c_ExportStock`, `c_ViewSale`, `c_InsertSale`, `c_UpdateSale`, `c_DeleteSale`, `c_ViewRSale`, `c_InsertRSale`, `c_UpdateRSale`, `c_DeleteRSale`, `c_ViewPurchase`, `c_InsertPurchase`, `c_UpdatePurchase`, `c_DeletePurchase`, `c_ViewRPurchase`, `c_InsertRPurchase`, `c_UpdateRPurchase`, `c_DeleteRPurchase`, `c_ViewIncome`, `c_InsertIncome`, `c_UpdateIncome`, `c_DeleteIncome`, `c_ViewOutcome`, `c_InsertOutcome`, `c_UpdateOutcome`, `c_DeleteOutcome`, `c_ViewReceipt`, `c_InsertReceipt`, `c_UpdateReceipt`, `c_DeleteReceipt`,`c_ViewPayment`, `c_InsertPayment`, `c_UpdatePayment`, `c_DeletePayment`, `c_AllBranches`, `c_Journal`, `c_ExportJournal`, `c_LossProfit`, `c_Users`, `c_BackUp`, `c_Restore`) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? );") ) ){
		$response['error'] ='7501';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'ssssssssssssssssssssssssssssssssssssssssssssssssssssss', $user_name,$user_password, $user_branch, $user_view_account, $user_insert_account, $user_update_account, $user_delete_account, $user_export_accounts, $user_view_stock, $user_insert_stock, $user_update_stock, $user_delete_stock, $user_cost, $user_all_items, $user_export_stock, $user_view_sale, $user_insert_sale, $user_update_sale, $user_delete_sale, $user_view_r_sale, $user_insert_r_sale, $user_update_r_sale, $user_delete_r_sale, $user_view_purchase, $user_insert_purchase, $user_update_purchase, $user_delete_purchase, $user_view_r_purchase, $user_insert_r_purchase, $user_update_r_purchase, $user_delete_r_purchase, $user_view_income, $user_insert_income, $user_update_income, $user_delete_income, $user_view_outcome, $user_insert_outcome, $user_update_outcome, $user_delete_outcome, $user_view_receipt, $user_insert_receipt, $user_update_receipt, $user_delete_receipt, $user_view_payment, $user_insert_payment, $user_update_payment, $user_delete_payment, $user_all_branches, $user_journal, $user_export_journal, $user_loss_profit, $user_users, $user_backup, $user_restore )  ) ){
		$response['error'] ='7502';
		return $response;
	}	
	
	if ( !( $sql->execute() ) ){
		$response['error'] ='7504';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
function update_user( $user_password, $user_branch, $user_view_account, $user_insert_account, $user_update_account, $user_delete_account, $user_export_accounts, $user_view_stock, $user_insert_stock, $user_update_stock, $user_delete_stock, $user_cost, $user_all_items, $user_export_stock, $user_view_sale, $user_insert_sale, $user_update_sale, $user_delete_sale, $user_view_r_sale, $user_insert_r_sale, $user_update_r_sale, $user_delete_r_sale, $user_view_purchase, $user_insert_purchase, $user_update_purchase, $user_delete_purchase, $user_view_r_purchase, $user_insert_r_purchase, $user_update_r_purchase, $user_delete_r_purchase, $user_view_income, $user_insert_income, $user_update_income, $user_delete_income, $user_view_outcome, $user_insert_outcome, $user_update_outcome, $user_delete_outcome, $user_view_receipt, $user_insert_receipt, $user_update_receipt, $user_delete_receipt, $user_view_payment, $user_insert_payment, $user_update_payment, $user_delete_payment, $user_all_branches, $user_journal, $user_export_journal, $user_loss_profit, $user_users, $user_backup, $user_restore, $id )
{


	require 'connection.php';
	
	$user_password = hash('sha256', $user_password);
	
	if ( !( $sql =$connection ->prepare("UPDATE `t_users` SET `c_Password`=?, `c_Branch`=?,`c_ViewAccount`=?,`c_InsertAccount`=?,`c_UpdateAccount`=?, `c_DeleteAccount`=?, `c_ExportAccounts`=?, `c_ViewStock`=?, `c_InsertStock`=?,`c_UpdateStock`=?, `c_DeleteStock`=?,`c_Cost`=?, `c_AllItems`=?,`c_ExportStock`=?,`c_ViewSale`=?,`c_InsertSale`=?,`c_UpdateSale`=?,`c_DeleteSale`=?,`c_ViewRSale`=?,`c_InsertRSale`=?,`c_UpdateRSale`=?,`c_DeleteRSale`=?,`c_ViewPurchase`=?,`c_InsertPurchase`=?,`c_UpdatePurchase`=?,`c_DeletePurchase`=?,`c_ViewRPurchase`=?,`c_InsertRPurchase`=?,`c_UpdateRPurchase`=?,`c_DeleteRPurchase`=?,`c_ViewIncome`=?,`c_InsertIncome`=?,`c_UpdateIncome`=?,`c_DeleteIncome`=?,`c_ViewOutcome`=?,`c_InsertOutcome`=?,`c_UpdateOutcome`=?,`c_DeleteOutcome`=?,`c_ViewReceipt`=?,`c_InsertReceipt`=?,`c_UpdateReceipt`=?,`c_DeleteReceipt`=?,`c_ViewPayment`=?,`c_InsertPayment`=?,`c_UpdatePayment`=?,`c_DeletePayment`=?, `c_AllBranches`=?, `c_Journal`=?, `c_ExportJournal`=?, `c_LossProfit`=?, `c_Users`=?, `c_BackUp`=?,`c_Restore`=? WHERE c_ID = ?;") ) ){
		$response['error'] ='7601';
		return $response;
	}
	
	if ( !( $sql->bind_param( 'ssssssssssssssssssssssssssssssssssssssssssssssssssssss', $user_password, $user_branch, $user_view_account, $user_insert_account, $user_update_account, $user_delete_account, $user_export_accounts, $user_view_stock, $user_insert_stock, $user_update_stock, $user_delete_stock, $user_cost, $user_all_items, $user_export_stock, $user_view_sale, $user_insert_sale, $user_update_sale, $user_delete_sale, $user_view_r_sale, $user_insert_r_sale, $user_update_r_sale, $user_delete_r_sale, $user_view_purchase, $user_insert_purchase, $user_update_purchase, $user_delete_purchase, $user_view_r_purchase, $user_insert_r_purchase, $user_update_r_purchase, $user_delete_r_purchase, $user_view_income, $user_insert_income, $user_update_income, $user_delete_income, $user_view_outcome, $user_insert_outcome, $user_update_outcome, $user_delete_outcome, $user_view_receipt, $user_insert_receipt, $user_update_receipt, $user_delete_receipt, $user_view_payment, $user_insert_payment, $user_update_payment, $user_delete_payment, $user_all_branches, $user_journal, $user_export_journal, $user_loss_profit, $user_users, $user_backup, $user_restore, $id )  ) ){
		$response['error'] ='7602';
		return $response;
	}	
	
	if ( !( $sql->execute() ) ){
		$response['error'] ='7604';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;
	
}
function delete_user( $id )
{

	require 'connection.php';
	
	if ( !( $sql =$connection ->prepare("DELETE FROM t_users WHERE c_ID =?;") ) ){
		$response['error'] ='7701';
		return $response;
	}
	
	if ( !( $sql ->bind_param( 's', $id ) ) ){
		$response['error'] ='7702';
		return $response;
	}
	
	if ( !( $sql ->execute() ) ){
		$response['error'] ='7704';
		return $response;
	}
	
	$response['error'] ='0';
	return $response;

}
?>