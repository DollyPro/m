<?php
require 'post.php';
require 'get.php';
#check user

session_start();

if ( isset($_SESSION['name']) && isset($_SESSION['password']) ){
	
	$name =$_SESSION['name'];
	$my_password =$_SESSION['password'];
	
	if ( !( $response =check_user( $name, $my_password ) ) ){
		$response['error']= '100000';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){

		unset($_SESSION['name']);
		unset($_SESSION['password']);
		$response['error'] ='10200';
		$response['sign-out'] ='true';
		die(json_encode($response));

	}


	$data =$response['data'];
	$row = $data ->fetch_assoc();
	$user = $row['c_ID'];
	
	$authnication_user_branch=htmlentities($row['c_Branch']);
	
	$authnication_user_view_account=htmlentities($row['c_ViewAccount']);
	$authnication_user_insert_account=htmlentities($row['c_InsertAccount']);
	$authnication_user_update_account=htmlentities($row['c_UpdateAccount']);
	$authnication_user_delete_account=htmlentities($row['c_DeleteAccount']);
	$authnication_user_export_accounts=htmlentities($row['c_ExportAccounts']);
	
	$authnication_user_view_stock=htmlentities($row['c_ViewStock']);
	$authnication_user_insert_stock=htmlentities($row['c_InsertStock']);
	$authnication_user_update_stock=htmlentities($row['c_UpdateStock']);
	$authnication_user_delete_stock=htmlentities($row['c_DeleteStock']);
	$authnication_user_cost=htmlentities($row['c_Cost']);
	$authnication_user_all_items=htmlentities($row['c_AllItems']);
	$authnication_user_export_stock=htmlentities($row['c_ExportStock']);
	
	$authnication_user_view_sale=htmlentities($row['c_ViewSale']);
	$authnication_user_insert_sale=htmlentities($row['c_InsertSale']);
	$authnication_user_update_sale=htmlentities($row['c_UpdateSale']);
	$authnication_user_delete_sale=htmlentities($row['c_DeleteSale']);
	
	$authnication_user_view_r_sale=htmlentities($row['c_ViewRSale']);
	$authnication_user_insert_r_sale=htmlentities($row['c_InsertRSale']);
	$authnication_user_update_r_sale=htmlentities($row['c_UpdateRSale']);
	$authnication_user_delete_r_sale=htmlentities($row['c_DeleteRSale']);
	
	$authnication_user_view_purchase=htmlentities($row['c_ViewPurchase']);
	$authnication_user_insert_purchase=htmlentities($row['c_InsertPurchase']);
	$authnication_user_update_purchase=htmlentities($row['c_UpdatePurchase']);
	$authnication_user_delete_purchase=htmlentities($row['c_DeletePurchase']);
	
	$authnication_user_view_r_purchase=htmlentities($row['c_ViewRPurchase']);
	$authnication_user_insert_r_purchase=htmlentities($row['c_InsertRPurchase']);
	$authnication_user_update_r_purchase=htmlentities($row['c_UpdateRPurchase']);
	$authnication_user_delete_r_purchase=htmlentities($row['c_DeleteRPurchase']);
	
	$authnication_user_view_income=htmlentities($row['c_ViewIncome']);
	$authnication_user_insert_income=htmlentities($row['c_InsertIncome']);
	$authnication_user_update_income=htmlentities($row['c_UpdateIncome']);
	$authnication_user_delete_income=htmlentities($row['c_DeleteIncome']);
	
	$authnication_user_view_outcome=htmlentities($row['c_ViewOutcome']);
	$authnication_user_insert_outcome=htmlentities($row['c_InsertOutcome']);
	$authnication_user_update_outcome=htmlentities($row['c_UpdateOutcome']);
	$authnication_user_delete_outcome=htmlentities($row['c_DeleteOutcome']);
	
	$authnication_user_view_receipt=htmlentities($row['c_ViewReceipt']);
	$authnication_user_insert_receipt=htmlentities($row['c_InsertReceipt']);
	$authnication_user_update_receipt=htmlentities($row['c_UpdateReceipt']);
	$authnication_user_delete_receipt=htmlentities($row['c_DeleteReceipt']);
	
	$authnication_user_view_payment=htmlentities($row['c_ViewPayment']);
	$authnication_user_insert_payment=htmlentities($row['c_InsertPayment']);
	$authnication_user_update_payment=htmlentities($row['c_UpdatePayment']);
	$authnication_user_delete_payment=htmlentities($row['c_DeletePayment']);
	
	$authnication_user_all_branches=htmlentities($row['c_AllBranches']);
	$authnication_user_journal=htmlentities($row['c_Journal']);
	$authnication_user_export_journal=htmlentities($row['c_ExportJournal']);
	$authnication_user_loss_profit=htmlentities($row['c_LossProfit']);
	$authnication_user_users=htmlentities($row['c_Users']);
	$authnication_user_backup=htmlentities($row['c_BackUp']);
	$authnication_user_restore=htmlentities($row['c_Restore']);
	
}else{
	$response['error'] ='10201';
	$response['sign-out'] ='true';
	die(json_encode($response));
}
#action type
if ( !( isset($_POST['action']) ) ){
	$response['error'] ='100';
	die(json_encode($response));
}
$action =$_POST['action'];
#t_accounts
if ( $action =='insert_account' ){
	
	if ( !( $authnication_user_insert_account == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}	
	
	if ( !( isset($_POST['branch']) &&isset($_POST['name']) && isset($_POST['type']) && isset($_POST['opening_balance']) && isset($_POST['contact']) && isset($_POST['address']) && isset($_POST['my_location']) && isset($_POST['memo']) ) ){
		$response['error'] ='1000';
		die(json_encode($response));
	}
	
	$branch =$_POST['branch'];
	if (!($authnication_user_all_branches=='true')){
		$branch= $authnication_user_branch;
	}
	$name =$_POST['name'];
	$type =$_POST['type'];
	$contact =$_POST['contact'];
	$address =$_POST['address'];
	$location =$_POST['my_location'];
	$memo =$_POST['memo'];
	$opening_balance =$_POST['opening_balance'];
	if ( $opening_balance == '' ){
		$opening_balance = 0;
	}

	if ( !( $response =insert_account( $branch, $name, $type, $opening_balance, $contact, $address, $location, $memo, $user ) ) ) {
		$response['error'] ='1001';
		die(json_encode($response));
	}
	
	if ( !( $response['error'] =='0' ) ){
		die(json_encode($response));
	}
	
	die(json_encode($response));
	
}
if ( $action =='update_account' ){
	
	if ( !( $authnication_user_update_account == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !( isset($_POST['id']) && isset($_POST['name']) && isset($_POST['opening_balance']) && isset($_POST['contact']) && isset($_POST['address']) && isset($_POST['my_location']) && isset($_POST['memo']) ) ){
		$response['error'] ='1100';
		die(json_encode($response));
	}
	
	$id =$_POST['id'];
	$name =$_POST['name'];
	$contact =$_POST['contact'];
	$address =$_POST['address'];
	$location =$_POST['my_location'];
	$memo =$_POST['memo'];
	$opening_balance =$_POST['opening_balance'];
	
	if ( $opening_balance == '' ){
		$opening_balance = 0;
	}
	
	if ( !( $response =select_account($id) ) ){
		$response['error']='13101';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$account_name =htmlentities($row['c_Name']);
	$branch =htmlentities($row['c_Branch']);
	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}	
	
	if ( !( $response = update_account( $name, $opening_balance, $contact, $address, $location, $memo, $id ) ) ){
		$response['error'] ='1101';
		die(json_encode($response));
	}

    if ( !( $response['error'] =='0' ) ){
		die(json_encode($response));
	}

	die(json_encode($response));
	
}
if ( $action =='delete_account' ){
	
	if ( !( $authnication_user_delete_account == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}	
	
	if ( !( isset($_POST['id']) ) ){			
		$response['error'] ='1202';
		die(json_encode($response));
	}
	
	$id =$_POST['id'];
	
	if ( !( $response =select_account($id) ) ){
		$response['error']='13101';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$account_name =htmlentities($row['c_Name']);
	$branch =htmlentities($row['c_Branch']);
	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}	
	
	if ( !( $response =delete_account( $id ) ) ){
		$response['error'] ='1201';
		die(json_encode($response));
	}
	
	die(json_encode($response));
	
}
#t_invoices
if ( $action =='insert_invoice' ){
	
	if ( !( isset($_POST['account']) && isset($_POST['second_account']) && isset($_POST['type']) && isset($_POST['memo']) && isset($_POST['discount']) && isset($_POST['auto_payment']) && isset($_POST['items']) ) ){
		$response['error'] ='3000';
		die(json_encode($response));
	}
	
	$account =$_POST['account'];
	$second_account =$_POST['second_account'];
	$type =$_POST['type'];
	$memo =$_POST['memo'];
	$discount =$_POST['discount'];	
	$auto_payment =$_POST['auto_payment'];	

	$items =json_decode($_POST['items'], true);

	if ($type =='Sale'){
		if ( !( $authnication_user_insert_sale == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	if ($type =='R Sale'){
		if ( !( $authnication_user_insert_r_sale == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	if ($type =='Purchase'){
		if ( !( $authnication_user_insert_purchase == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	if ($type =='R Purchase'){
		if ( !( $authnication_user_insert_r_purchase == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}


	if ( $discount=='' ){
		$discount ='0';
	}
	if ( $second_account=='' ){
		$second_account =null;
	}

	if ( !( $response =select_account($account) ) ){
		$response['error']='13101';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$account_name =htmlentities($row['c_Name']);
	$branch =htmlentities($row['c_Branch']);
	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if ($type != 'Sale' && $type != 'R Sale' && $type != 'Purchase' && $type != 'R Purchase'){
		$response['error']='3001';
		die(json_encode($response));
	}

	if (!( $response =insert_invoice( $account, $second_account, $type, $memo, $discount, $user ) )){
		$response['error'] ='3002';
		die(json_encode($response));
	}

	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	if ( !( $response['id'] >0 ) ){
		die(json_encode($response));
	}
	
	$invoice =$response['id'];

	for ( $i =0 ; sizeof($items)>$i ; $i++ ){
		
		 $stock =$items[$i]['id'];
		 $qty =$items[$i]['qty'];
		 $price =$items[$i]['price'];
		 $discount =$items[$i]['discount'];
		
    	if ( $qty=='' ){
    		$qty =0;
    	}
    	if ( $price=='' ){
    		$price ='0';
    	}
    	if ( $discount=='' ){
    		$discount ='0';
    	}
	
		if ( !( $response =insert_item( $invoice, $stock, $price, $qty, $discount ) ) ){
			delete_invoice( $invoice );
			delete_invoice_items( $invoice );
			$response['error'] ='3003';
			die(json_encode($response));
		}
		
		if ( $response['error']!=0  ){
			delete_invoice( $invoice );
			delete_invoice_items( $invoice );
			die(json_encode($response));
		}
	}
	
	if ( $auto_payment!='true' ){
		$response['error'] ='0';
		die(json_encode($response));
	}else{
		
		if ( $type=='Sale' || $type=='R Purchase' ){
			$type='Receipt';
		}else{
			$type='Payment';
		}
		
		$second_account=null;
		
		if ( !( $response =select_invoice($invoice) ) ){
		$response['error']='13101';
		die(json_encode($response));
		}
		
		if ( !( $response['error']==0 ) ){
			die(json_encode($response));
		}
		
		$data =$response['data'];
		$row =$data ->fetch_assoc();
		$ammount =$row['c_Total']-$row['c_Discount'];
		
		if (!( $response =insert_payment( $account, $second_account, $type, $ammount, $memo, $user ) )){
			delete_invoice( $invoice );
			$response['error'] ='2001';
			die(json_encode($response));
		}
		
		if ( !( $response['error'] =='0' ) ){
			delete_invoice( $invoice );
			die(json_encode($response));
		}
		
		$response['error']='0';
		die(json_encode($response));
		
	}
	

}
if ( $action =='update_invoice' ){
	
	if ( !( isset($_POST['id']) && isset($_POST['memo']) && isset($_POST['discount']) && isset($_POST['items']) ) ){
		$response['error'] ='3100';
		die(json_encode($response));
	}
	
	$id =$_POST['id'];
	$memo =$_POST['memo'];
	$discount =$_POST['discount'];	
	$items =json_decode($_POST['items'], true);

	if ( $discount=='' ){
		$discount ='0';
	}

	if ( !( $response =select_invoice($id) ) ){
		$response['error']='13101';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$branch =htmlentities($row['c_Branch']);
	$type =htmlentities($row['c_Type']);
	
	if ($type =='Sale'){
		if ( !( $authnication_user_update_sale == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	if ($type =='R Sale'){
		if ( !( $authnication_user_update_r_sale == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	if ($type =='Purchase'){
		if ( !( $authnication_user_update_purchase == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	if ($type =='R Purchase'){
		if ( !( $authnication_user_update_r_purchase == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}	

	if (!( $response =delete_invoice_items( $id ) )){
		$response['error'] ='3101';
		die(json_encode($response));
	}

	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}

	if (!( $response =update_invoice( $memo, $discount, $id ) )){
		delete_invoice( $id );
		$response['error'] ='3102';
		die(json_encode($response));
	}	
	
	if ( !( $response['error'] ==0 ) ){
		delete_invoice( $id );
		die(json_encode($response));
	}

	for ( $i =0 ; sizeof($items)>$i ; $i++ ){
		
		 $stock =$items[$i]['id'];
		 $qty =$items[$i]['qty'];
		 $price =$items[$i]['price'];
		 $discount =$items[$i]['discount'];
		
    	if ( $qty=='' ){
    		$qty =0;
    	}
    	if ( $price=='' ){
    		$price ='0';
    	}
    	if ( $discount=='' ){
    		$discount ='0';
    	}
	
		if ( !( $response =insert_item( $id, $stock, $price, $qty, $discount ) ) ){
			delete_invoice( $id );
			delete_invoice_items( $id );
			$response['error'] ='3103';
			die(json_encode($response));
		}
		
		if ( $response['error']!=0  ){
			delete_invoice( $id );
			delete_invoice_items( $id );
			die(json_encode($response));
		}
	}
	
	$response['error'] ='0';
	die(json_encode($response));

}
if ( $action =='insert_income' ){

	if ( !( isset($_POST['account']) && isset($_POST['second_account']) && isset($_POST['ammount']) && isset($_POST['memo']) && isset($_POST['type']) ) ){
		$response['error'] ='3200';
		die(json_encode($response));
	}
	
	$account =$_POST['account'];
	$second_account =$_POST['second_account'];
	$ammount =$_POST['ammount'];	
	$memo =$_POST['memo'];
	$type =$_POST['type'];

	if ($type =='Income'){
		if ( !( $authnication_user_insert_income == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	if ($type =='Outcome'){
		if ( !( $authnication_user_insert_outcome == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	

	if ( $second_account=='' ){
		$second_account =null;
	}

	if ( !( $response =select_account($account) ) ){
		$response['error']='13101';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$account_name =htmlentities($row['c_Name']);
	$branch =htmlentities($row['c_Branch']);
	

	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if (!( $response =insert_income( $type, $account, $second_account, $ammount, $memo, $user ) )){
		$response['error'] ='3201';
		die(json_encode($response));
	}
	
	if ( !( $response['error'] ==0 ) ){
		die(json_encode($response));
	}
	
	if ( !( $response['id'] >0 ) ){
		die(json_encode($response));
	}
	
	$invoice =$response['id'];
	
	$response['error'] ='0';
	die(json_encode($response));
	

}
if ( $action =='update_income' ){

	if ( !( isset($_POST['ammount']) && isset($_POST['memo']) && isset($_POST['id']) ) ){
		$response['error'] ='3300';
		die(json_encode($response));
	}

	$ammount =$_POST['ammount'];
	$memo =$_POST['memo'];
	$id =$_POST['id'];
	
	if ( !( $response =select_invoice($id) ) ){
		$response['error']='13101';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$branch =htmlentities($row['c_Branch']);
	$type =htmlentities($row['c_Type']);
	
	if ($type =='Income'){
		if ( !( $authnication_user_update_income == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	if ($type =='Outcome'){
		if ( !( $authnication_user_update_outcome == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if (!( $response =update_income( $ammount, $memo, $id ) )){
		$response['error'] ='3301';
		die(json_encode($response));
	}
	
	if ( !( $response['error'] =='0' ) ){
		die(json_encode($response));
	}
	
	die(json_encode($response));

}
if ( $action =='delete_invoice' ){

	if ( !( isset($_POST['id']) ) ){			
		$response['error'] ='3402';
		die(json_encode($response));
	}
	
	$id =$_POST['id'];
	
	if ( !( $response =select_invoice($id) ) ){
		$response['error']='13101';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$branch =htmlentities($row['c_Branch']);
	$type =htmlentities($row['c_Type']);
	
	if ($type =='Sale'){
		if ( !( $authnication_user_delete_sale == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	if ($type =='R Sale'){
		if ( !( $authnication_user_delete_r_sale == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	if ($type =='Purchase'){
		if ( !( $authnication_user_delete_purchase == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	if ($type =='R Purchase'){
		if ( !( $authnication_user_delete_r_purchase == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	if ($type =='Income'){
		if ( !( $authnication_user_delete_income == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	if ($type =='Outcome'){
		if ( !( $authnication_user_delete_outcome == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ( !( $response =delete_invoice( $id ) ) ){
		$response['error'] ='3401';
		die(json_encode($response));
	}

	
	die(json_encode($response));
	
}
#t_payments	
if ( $action =='insert_payment' ){
	
	if ( !( isset($_POST['account']) && isset($_POST['second_account']) && isset($_POST['type']) && isset($_POST['ammount']) && isset($_POST['memo']) ) ){
		$response['error'] ='2000';
		die(json_encode($response));
	}
	
	$type =$_POST['type'];
	$account =$_POST['account'];
	$second_account =$_POST['second_account'];
	$ammount =$_POST['ammount'];	
	$memo =$_POST['memo'];

	if ( $second_account=='' ){
		$second_account =null;
	}

	if ( !( $response =select_account($account) ) ){
		$response['error']='13101';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$branch =htmlentities($row['c_Branch']);
	
	if ($type =='Receipt'){
		if ( !( $authnication_user_insert_receipt == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	if ($type =='Payment'){
		if ( !( $authnication_user_insert_payment == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if (!( $response =insert_payment( $account, $second_account, $type, $ammount, $memo, $user ) )){
		$response['error'] ='2001';
		die(json_encode($response));
	}
	
	if ( !( $response['error'] =='0' ) ){
		die(json_encode($response));
	}
	
	$response['error']='0';
	die(json_encode($response));

}
if ( $action =='update_payment' ){
	
	if ( !( isset($_POST['ammount']) && isset($_POST['memo']) && isset($_POST['id']) ) ){
		$response['error'] ='2100';
		die(json_encode($response));
	}

	$ammount =$_POST['ammount'];	
	$memo =$_POST['memo'];
	$id =$_POST['id'];
	
	if ( !( $response =select_payment($id) ) ){
		$response['error']='13101';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$branch =htmlentities($row['c_Branch']);
	$type =htmlentities($row['c_Type']);
	
	if ($type =='Receipt'){
		if ( !( $authnication_user_update_receipt == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	if ($type =='Payment'){
		if ( !( $authnication_user_update_payment == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if (!( $response =update_payment( $ammount, $memo, $id ) )){
		$response['error'] ='2101';
		die(json_encode($response));
	}

	if ( !( $response['error'] =='0' ) ){
		die(json_encode($response));
	}
	
	die(json_encode($response));

}
if ( $action =='delete_payment' ){
	
	if ( !( isset($_POST['id']) ) ){			
		$response['error'] ='2202';
		die(json_encode($response));
	}
	
	$id =$_POST['id'];
	
	if ( !( $response =select_payment($id) ) ){
		$response['error']='13101';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$branch =htmlentities($row['c_Branch']);
	$type =htmlentities($row['c_Type']);
	
	if ($type =='Receipt'){
		if ( !( $authnication_user_delete_receipt == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	if ($type =='Payment'){
		if ( !( $authnication_user_delete_payment == 'true' ) ){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}

	if ( !( $response =delete_payment( $id ) ) ){
		$response['error'] ='2201';
		die(json_encode($response));
	}
	
	
	die(json_encode($response));
	
}
#t_stock
if ( $action =='insert_product' ){
	
	if ( !( $authnication_user_insert_stock == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !( isset($_POST['branch']) && isset($_POST['name']) && isset($_POST['category1']) && isset($_POST['category2']) && isset($_POST['category3']) && isset($_POST['category4']) && isset($_POST['category5']) && isset($_POST['category6']) && isset($_POST['category7']) && isset($_POST['category8']) && isset($_POST['opening_qty']) && isset($_POST['cost']) && isset($_POST['price']) && isset($_POST['minimum']) && isset($_POST['maximum']) && isset($_POST['memo'])  ) ){
		$response['error'] ='6000';
		die(json_encode($response));
	}
	
	$branch =$_POST['branch'];	
	
	if (!($authnication_user_all_branches=='true')){
		$branch= $authnication_user_branch;
	}
	
	$name =$_POST['name'];	
	$category1 =$_POST['category1'];		
	$category2 =$_POST['category2'];		
	$category3 =$_POST['category3'];		
	$category4 =$_POST['category4'];		
	$category5 =$_POST['category5'];		
	$category6 =$_POST['category6'];		
	$category7 =$_POST['category7'];		
	$category8 =$_POST['category8'];		
	$opening_qty =$_POST['opening_qty'];	
	$opening_cost =$_POST['cost'];
	$price =$_POST['price'];
	$minimum =$_POST['minimum'];	
	$maximum =$_POST['maximum'];	
	$memo =$_POST['memo'];	

	if ( $opening_cost=='' ){
		$opening_cost ='0';
	}
	if ( $price=='' ){
		$price ='0';
	}
	if ( $minimum=='' ){
		$minimum ='0';
	}
	if ( $maximum=='' ){
		$maximum ='0';
	}
	if ( $opening_qty=='' ){
		$opening_qty ='0';
	}
	
	if (!( $response =insert_product( $branch, $name, $category1, $category2, $category3, $category4, $category5, $category6, $category7, $category8, $opening_qty, $opening_cost, $price, $minimum, $maximum , $memo, $user ) )){
		$response['error'] ='6001';
		die(json_encode($response));
	}
	
	if ( !( $response['error'] =='0' ) ){
		die(json_encode($response));
	}
	
	die(json_encode($response));

}
if ( $action =='update_product' ){
	
	if ( !( $authnication_user_update_stock == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !( isset($_POST['name']) && isset($_POST['category1']) && isset($_POST['category2']) && isset($_POST['category3']) && isset($_POST['category4']) && isset($_POST['category5']) && isset($_POST['category6']) && isset($_POST['category7']) && isset($_POST['category8']) && isset($_POST['opening_qty']) && isset($_POST['cost'])  && isset($_POST['price']) && isset($_POST['minimum']) && isset($_POST['maximum']) && isset($_POST['memo']) && isset($_POST['id']) ) ){
		$response['error'] ='6100';
		die(json_encode($response));
	}

	$name =$_POST['name'];	
	$category1 =$_POST['category1'];		
	$category2 =$_POST['category2'];		
	$category3 =$_POST['category3'];		
	$category4 =$_POST['category4'];		
	$category5 =$_POST['category5'];		
	$category6 =$_POST['category6'];		
	$category7 =$_POST['category7'];		
	$category8 =$_POST['category8'];	
	$opening_qty =$_POST['opening_qty'];
	$opening_cost =$_POST['cost'];
	$price =$_POST['price'];
	$minimum =$_POST['minimum'];	
	$maximum =$_POST['maximum'];	
	$memo =$_POST['memo'];	
	$id =$_POST['id'];

	if ( $opening_cost=='' ){
		$opening_cost ='0';
	}
	if ( $price=='' ){
		$price ='0';
	}
	if ( $opening_qty=='' ){
		$opening_qty ='0';
	}
	if ( $minimum=='' ){
		$minimum ='0';
	}
	if ( $maximum=='' ){
		$maximum ='0';
	}
	
	if ( !( $response =select_product($id) ) ){
		$response['error']='13101';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$branch =htmlentities($row['c_Branch']);
	
	if ( !( $authnication_user_cost == 'true' ) ){
		$opening_cost = htmlentities($row['c_OpeningCost']);
	}
	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if (!( $response =update_product( $name, $category1, $category2, $category3, $category4, $category5, $category6, $category7, $category8, $opening_qty, $opening_cost, $price, $minimum, $maximum,  $memo, $id ) )){
		$response['error'] ='6101';
		die(json_encode($response));
	}
	
	if ( !( $response['error'] =='0' ) ){
		die(json_encode($response));
	}
	
	die(json_encode($response));

}
if ( $action =='delete_product' ){
	
	if ( !( $authnication_user_delete_stock == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !( isset($_POST['id']) ) ){			
		$response['error'] ='6202';
		die(json_encode($response));
	}
	
	$id =$_POST['id'];
	
	if ( !( $response =select_product($id) ) ){
		$response['error']='13101';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){
		die(json_encode($response));
	}
	
	$data =$response['data'];
	$row =$data ->fetch_assoc();
	
	$branch =htmlentities($row['c_Branch']);
	
	if ( !($authnication_user_all_branches=='true') ){
		if ($branch!=$authnication_user_branch){
			$response['error'] ='0';
			$response['not-authnicated'] ='true';
			die(json_encode($response));
		}
	}
	
	if ( !( $response =delete_product( $id ) ) ){
		$response['error'] ='6201';
		die(json_encode($response));
	}
	
	die(json_encode($response));
	
}
#t_users
if ( $action =='insert_user' ){
	
	if ( !( $authnication_user_users == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}	
	
	if ( !( isset($_POST['user']) ) ){
		$response['error'] ='7000';
		die(json_encode($response));
	}
	
	$user =json_decode($_POST['user'], true);

	$user_name=$user['user_name'];
	$user_password=$user['user_password'];
	$user_branch=$user['user_branch'];
	
	$user_view_account=$user['user_view_account'];
	$user_insert_account=$user['user_insert_account'];
	$user_update_account=$user['user_update_account'];
	$user_delete_account=$user['user_delete_account'];
	$user_export_accounts=$user['user_export_accounts'];

	$user_view_stock=$user['user_view_stock'];
	$user_insert_stock=$user['user_insert_stock'];
	$user_update_stock=$user['user_update_stock'];
	$user_delete_stock=$user['user_delete_stock'];
	$user_cost=$user['user_cost'];
	$user_all_items=$user['user_all_items'];
	$user_export_stock=$user['user_export_stock'];
	
	$user_view_sale=$user['user_view_sale'];
	$user_insert_sale=$user['user_insert_sale'];
	$user_update_sale=$user['user_update_sale'];
	$user_delete_sale=$user['user_delete_sale'];
	
	$user_view_r_sale=$user['user_view_r_sale'];
	$user_insert_r_sale=$user['user_insert_r_sale'];
	$user_update_r_sale=$user['user_update_r_sale'];
	$user_delete_r_sale=$user['user_delete_r_sale'];
	
	$user_view_purchase=$user['user_view_purchase'];
	$user_insert_purchase=$user['user_insert_purchase'];
	$user_update_purchase=$user['user_update_purchase'];
	$user_delete_purchase=$user['user_delete_purchase'];
	
	$user_view_r_purchase=$user['user_view_r_purchase'];
	$user_insert_r_purchase=$user['user_insert_r_purchase'];
	$user_update_r_purchase=$user['user_update_r_purchase'];
	$user_delete_r_purchase=$user['user_delete_r_purchase'];
	
	$user_view_income=$user['user_view_income'];
	$user_insert_income=$user['user_insert_income'];
	$user_update_income=$user['user_update_income'];
	$user_delete_income=$user['user_delete_income'];
	
	$user_view_outcome=$user['user_view_outcome'];
	$user_insert_outcome=$user['user_insert_outcome'];
	$user_update_outcome=$user['user_update_outcome'];
	$user_delete_outcome=$user['user_delete_outcome'];
	
	$user_view_receipt=$user['user_view_receipt'];
	$user_insert_receipt=$user['user_insert_receipt'];
	$user_update_receipt=$user['user_update_receipt'];
	$user_delete_receipt=$user['user_delete_receipt'];
	
	$user_view_payment=$user['user_view_payment'];
	$user_insert_payment=$user['user_insert_payment'];
	$user_update_payment=$user['user_update_payment'];
	$user_delete_payment=$user['user_delete_payment'];

	
	$user_all_branches=$user['user_all_branches'];
	$user_journal=$user['user_journal'];
	$user_export_journal=$user['user_export_journal'];
	$user_loss_profit=$user['user_loss_profit'];
	$user_users=$user['user_users'];
	$user_backup=$user['user_backup'];
	$user_restore=$user['user_restore'];
	


	if (!( $response =insert_user(  $user_name,$user_password, $user_branch, $user_view_account, $user_insert_account, $user_update_account, $user_delete_account, $user_export_accounts, $user_view_stock, $user_insert_stock, $user_update_stock, $user_delete_stock, $user_cost, $user_all_items, $user_export_stock, $user_view_sale, $user_insert_sale, $user_update_sale, $user_delete_sale, $user_view_r_sale, $user_insert_r_sale, $user_update_r_sale, $user_delete_r_sale, $user_view_purchase, $user_insert_purchase, $user_update_purchase, $user_delete_purchase, $user_view_r_purchase, $user_insert_r_purchase, $user_update_r_purchase, $user_delete_r_purchase, $user_view_income, $user_insert_income, $user_update_income, $user_delete_income, $user_view_outcome, $user_insert_outcome, $user_update_outcome, $user_delete_outcome, $user_view_receipt, $user_insert_receipt, $user_update_receipt, $user_delete_receipt, $user_view_payment, $user_insert_payment, $user_update_payment, $user_delete_payment, $user_all_branches, $user_journal, $user_export_journal, $user_loss_profit, $user_users, $user_backup, $user_restore ) )){	
	
		$response['error'] ='7001';
		die(json_encode($response));
		
	}
	
	if ( !( $response['error'] =='0' ) ){
		die(json_encode($response));
	}
	
	die(json_encode($response));

}
if ( $action =='update_user' ){
	
	if ( !( $authnication_user_users == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !( isset($_POST['id']) && isset($_POST['user']) ) ){
		$response['error'] ='7000';
		die(json_encode($response));
	}
	
	$id =$_POST['id'];
	$user =json_decode($_POST['user'], true);

	$user_password=$user['user_password'];
	$user_branch=$user['user_branch'];
	
	$user_view_account=$user['user_view_account'];
	$user_insert_account=$user['user_insert_account'];
	$user_update_account=$user['user_update_account'];
	$user_delete_account=$user['user_delete_account'];
	$user_export_accounts=$user['user_export_accounts'];

	$user_view_stock=$user['user_view_stock'];
	$user_insert_stock=$user['user_insert_stock'];
	$user_update_stock=$user['user_update_stock'];
	$user_delete_stock=$user['user_delete_stock'];
	$user_cost=$user['user_cost'];
	$user_all_items=$user['user_all_items'];
	$user_export_stock=$user['user_export_stock'];
	
	$user_view_sale=$user['user_view_sale'];
	$user_insert_sale=$user['user_insert_sale'];
	$user_update_sale=$user['user_update_sale'];
	$user_delete_sale=$user['user_delete_sale'];
	
	$user_view_r_sale=$user['user_view_r_sale'];
	$user_insert_r_sale=$user['user_insert_r_sale'];
	$user_update_r_sale=$user['user_update_r_sale'];
	$user_delete_r_sale=$user['user_delete_r_sale'];
	
	$user_view_purchase=$user['user_view_purchase'];
	$user_insert_purchase=$user['user_insert_purchase'];
	$user_update_purchase=$user['user_update_purchase'];
	$user_delete_purchase=$user['user_delete_purchase'];
	
	$user_view_r_purchase=$user['user_view_r_purchase'];
	$user_insert_r_purchase=$user['user_insert_r_purchase'];
	$user_update_r_purchase=$user['user_update_r_purchase'];
	$user_delete_r_purchase=$user['user_delete_r_purchase'];
	
	$user_view_income=$user['user_view_income'];
	$user_insert_income=$user['user_insert_income'];
	$user_update_income=$user['user_update_income'];
	$user_delete_income=$user['user_delete_income'];
	
	$user_view_outcome=$user['user_view_outcome'];
	$user_insert_outcome=$user['user_insert_outcome'];
	$user_update_outcome=$user['user_update_outcome'];
	$user_delete_outcome=$user['user_delete_outcome'];
	
	$user_view_receipt=$user['user_view_receipt'];
	$user_insert_receipt=$user['user_insert_receipt'];
	$user_update_receipt=$user['user_update_receipt'];
	$user_delete_receipt=$user['user_delete_receipt'];
	
	$user_view_payment=$user['user_view_payment'];
	$user_insert_payment=$user['user_insert_payment'];
	$user_update_payment=$user['user_update_payment'];
	$user_delete_payment=$user['user_delete_payment'];

	
	$user_all_branches=$user['user_all_branches'];
	$user_journal=$user['user_journal'];
	$user_export_journal=$user['user_export_journal'];
	$user_loss_profit=$user['user_loss_profit'];
	$user_users=$user['user_users'];
	$user_backup=$user['user_backup'];
	$user_restore=$user['user_restore'];
	

	if (!( $response =update_user( $user_password, $user_branch, $user_view_account, $user_insert_account, $user_update_account, $user_delete_account, $user_export_accounts, $user_view_stock, $user_insert_stock, $user_update_stock, $user_delete_stock, $user_cost, $user_all_items, $user_export_stock, $user_view_sale, $user_insert_sale, $user_update_sale, $user_delete_sale, $user_view_r_sale, $user_insert_r_sale, $user_update_r_sale, $user_delete_r_sale, $user_view_purchase, $user_insert_purchase, $user_update_purchase, $user_delete_purchase, $user_view_r_purchase, $user_insert_r_purchase, $user_update_r_purchase, $user_delete_r_purchase, $user_view_income, $user_insert_income, $user_update_income, $user_delete_income, $user_view_outcome, $user_insert_outcome, $user_update_outcome, $user_delete_outcome, $user_view_receipt, $user_insert_receipt, $user_update_receipt, $user_delete_receipt, $user_view_payment, $user_insert_payment, $user_update_payment, $user_delete_payment, $user_all_branches, $user_journal, $user_export_journal, $user_loss_profit, $user_users, $user_backup, $user_restore, $id ) )){	
	
		$response['error'] ='7001';
		die(json_encode($response));
		
	}
	
	if ( !( $response['error'] =='0' ) ){
		die(json_encode($response));
	}
	
	die(json_encode($response));

}
if ( $action =='delete_user' ){
	
	if ( !( $authnication_user_users == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}
	
	if ( !( isset($_POST['id']) ) ){			
		$response['error'] ='7202';
		die(json_encode($response));
	}
	
	$id =$_POST['id'];
	
	if ( !( $response =delete_user( $id ) ) ){
		$response['error'] ='7201';
		die(json_encode($response));
	}
	
	die(json_encode($response));
	
}
#backup
if ( $action == 'backup' ){
	
	if ( !( $authnication_user_backup == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}

	require 'connection.php';

	exec("mysqldump --defaults-extra-file=../../../../../.my.cnf $connection_data_base --result-file=$backup_file", $output, $result);
	
	if ( $result !=0 ){
		
		$response['error']= '500000';
		die(json_encode($response));
		
	}
	
	$response['error']= '0';
	die(json_encode($response));
	
}
if ( $action == 'restore' ){
	
	if ( !( $authnication_user_restore == 'true' ) ){
		$response['error'] ='0';
		$response['not-authnicated'] ='true';
		die(json_encode($response));
	}

	require 'connection.php';

	exec("mysql --defaults-extra-file=../../../../../.my.cnf $connection_data_base < $backup_file", $output, $result);

	 if ( $result !=0 ){
		
		 $response['error']= '510000';
		 die(json_encode($response));
		
	 }
	
	$response['error']= '0';
	die(json_encode($response));
	
}
$response['error'] ='150';
die(json_encode($response));
?>