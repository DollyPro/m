<?php

require 'php/get.php';

session_start();

if ( isset($_SESSION['name']) && isset($_SESSION['password']) ){
	
	$name =$_SESSION['name'];
	$my_password =$_SESSION['password'];
	
	if ( !( $response =check_user( $name, $my_password ) ) ){
		$response['error']= '100000';
		die(json_encode($response));
	}
	
	if ( !( $response['error']==0 ) ){

		unset($_SESSION['name']);
		unset($_SESSION['password']);
		header('Location:index.php');
		die();

	}
	
}else{
	header('Location:index.php');
}

?>