<?php

require 'get.php';
#check user
session_start();

if ( isset($_SESSION['name']) && isset($_SESSION['password']) ){
	
	$name =$_SESSION['name'];
	$my_password =$_SESSION['password'];
	
	if ( !( $response =check_user( $name, $my_password ) ) ){
		die();
	}
	
	if ( !( $response['error']==0 ) ){

		unset($_SESSION['name']);
		unset($_SESSION['password']);
		die();

	}
	
	$data =$response['data'];
	$row = $data ->fetch_assoc();
	$user = $row['c_ID'];
	
	$authnication_user_export_accounts=htmlentities($row['c_ExportAccounts']);
	$authnication_user_export_stock=htmlentities($row['c_ExportStock']);
	$authnication_user_export_journal=htmlentities($row['c_ExportJournal']);
	
}else{
	die();
}


if (isset($_GET['accounts'])){
	
	if ( !( $authnication_user_export_accounts == 'true' ) ){
		die('Not Authnicated');
	}
	
	header("Content-Type: text/csv; charset=utf-8");
	header("Content-Disposition: attachment; filename=M-Accounts-Export-".date('Y-m-d').".csv");
	
	$output = fopen('php://output', 'w');

	$response =select_accounts( '', '', '', '' );
	$data =$response['data'];

	$first=1;
	while($row =$data ->fetch_assoc()){
		
		$row['c_Balance']=($row['c_Debit']-$row['c_Credit'])+$row['c_OpeningBalance'];
		
		$firstt=1;
		$header=array();
		foreach(array_keys($row) as $array_key) {
			$array_key=substr($array_key,1);
			array_push($header, $array_key);
		}
		
		if ($first==1){
			fputcsv($output, $header );
			$first=0;
		}
		
		fputcsv($output, $row);
		
	}
	
}

if (isset($_GET['stock'])){
	
	if ( !( $authnication_user_export_stock == 'true' ) ){
		die('Not Authnicated');
	}
	
	header("Content-Type: text/csv; charset=utf-8");
	header("Content-Disposition: attachment; filename=M-Stock-Export-".date('Y-m-d').".csv");
	
	$output = fopen('php://output', 'w');

	$response =select_products( '', '', '', '', '', '', '', '', '', '', '' );
	$data =$response['data'];
	
	$first=1;
	while($row =$data ->fetch_assoc()){
		
		$row['c_Qty']= ($row['c_OpeningQty']+$row['c_PurchaseQty'])-$row['c_SaleQty'];
		
		$firstt=1;
		$header=array();
		foreach(array_keys($row) as $array_key) {
			$array_key=substr($array_key,1);
			array_push($header, $array_key);
		}
		
		if ($first==1){
			fputcsv($output, $header );
			$first=0;
		}
		
		fputcsv($output, $row);
		
	}
	
}

if (isset($_GET['journal'])){
	
	if ( !( $authnication_user_export_journal == 'true' ) ){
		die('Not Authnicated');
	}
	
	header("Content-Type: text/csv; charset=utf-8");
	header("Content-Disposition: attachment; filename=M-Journal-Export-".date('Y-m-d').".csv");
	
	$output = fopen('php://output', 'w');

	$response =select_journal( '', '', '', '', '', '' );
	$data =$response['data'];

	$first=1;
	while($row =$data ->fetch_assoc()){
		
		$firstt=1;
		$header=array();
		foreach(array_keys($row) as $array_key) {
			$array_key=substr($array_key,1);
			array_push($header, $array_key);
		}
		
		if ($first==1){
			fputcsv($output, $header );
			$first=0;
		}
		
		fputcsv($output, $row);
		
	}
	
}

die();
	
	
?>